jQuery( function( $ ) {
    if ( 'undefined' === typeof ldat_data ) {
        return false;
    }

    var activity_timeline = function() {
        if ( ! $( '.ldat-activity-timeline' ) ) {
            return;
        }

        var _this = this;

        _this.$container        = $( '.ldat-activity-timeline' );
        _this.course_id         = parseInt( _this.$container.data( 'course-id' ) );
        _this.page              = 1;
        _this.$loader           = $( '<div/>', {
            class: 'ldat-loader',
            html: '<div class="ldat-loader-content">' + ldat_data.i18n.loading_activities + '</div>'
        } );
        _this.class_doing_ajax  = 'ldat-doing-ajax';
        _this.timeout           = 300;
        _this.doing_ajax        = false;

        _this.$container.on( 'click', '.ldat-button-previous-page, .ldat-button-next-page', function() {
            _this.page = parseInt( $( this ).data( 'page' ) );
            _this.load_activities();
        } );

        _this.start_ajax = function( callback ) {
            _this.doing_ajax = true;
            _this.$container.addClass( _this.class_doing_ajax );
            _this.$loader.appendTo( _this.$container );

            if ( typeof( callback ) == 'function' ) {
                callback();
            }
        };
        
        _this.finish_ajax = function( callback ) {
            setTimeout( function() {
                _this.$loader.remove();
                _this.$container.removeClass( _this.class_doing_ajax );
                _this.doing_ajax = false;

                if ( typeof( callback ) == 'function' ) {
                    callback();
                }
            }, _this.timeout ); 
        };

        _this.load_activities = function() {
            $.ajax( {
                method: 'post',
                url: ldat_data.ajax_url,
                data: {
                    action      : ldat_data.ajax_action,
                    nonce       : ldat_data.ajax_nonce,
                    course_id   : _this.course_id,
                    page        : _this.page
                },
                beforeSend : function() {
                    _this.start_ajax();
                },
                success: function( response ) {
                    _this.finish_ajax( function() {
                        _this.$container.empty();
                        $( response.html ).appendTo( _this.$container );
                    } );

                },
                error: function( xhr, status, error ) {
                    _this.finish_ajax( function() {
                        var data = JSON.parse( xhr.responseText );
                        alert( data.message );
                    } );
                },
            } );
        }
    }

    new activity_timeline();
} );