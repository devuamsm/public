<?php

namespace LDAT;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Options;
use LDAT\Classes\Timeline;
use LDAT\Classes\Template;

class Frontend {
    use \LDAT\Traits\Trait_Singleton;

    /**
     * @var string Ajax action.
     */
    const AJAX_ACTION = 'ldat_load_activities';

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
        add_filter( 'learndash_content_tabs', array( $this, 'learndash_content_tabs' ), 99, 4 );
        add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'load_activities' ) );
        add_action( 'wp_ajax_nopriv_' . self::AJAX_ACTION, array( $this, 'load_activities' ) );
    }

    /**
     * Enqueue frontend assets.
     * 
     * @return void
     */
    public function frontend_assets() {
        global $post;

        if ( $post && $post->post_type == learndash_get_post_type_slug( 'course' ) ) {
            wp_enqueue_style( 'ldat-activity-timeline', LDAT_URL_ASSETS_CSS . '/activity-timeline' . LDAT_ASSETS_SUFFIX . '.css', array(), LDAT_VERSION );
            wp_enqueue_script( 'ldat-activity-timeline', LDAT_URL_ASSETS_JS . '/activity-timeline' . LDAT_ASSETS_SUFFIX . '.js', array( 'jquery' ), true, LDAT_VERSION );
            wp_localize_script( 'ldat-activity-timeline', 'ldat_data', array(
                'ajax_url'      => admin_url( 'admin-ajax.php' ),
                'ajax_nonce'    => wp_create_nonce( self::AJAX_ACTION ),
                'ajax_action'   => self::AJAX_ACTION,
                'i18n'          => array(
                    'loading_activities' => __( 'Loading activities...', 'learndash-activity-timeline' )
                )
            ) );
        }
    }

    /**
     * Add the new Activity timeline tab.
     * 
     * @param array $tabs Current tabs.
     * @param string $context The context where the tabs are shown like course, lesson, topic, quiz, etc.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Modified tabs.
     */
    public function learndash_content_tabs( $tabs, $context, $course_id, $user_id ) {
        if ( 
            $context == 'course' &&
            ! Timeline::is_open_course( $course_id ) &&
            ( sfwd_lms_has_access( $course_id, $user_id ) || learndash_is_group_leader_user( $user_id ) )
        ) {
            $tabs[] = array(
                'id'        => 'ldat_activity_timeline',
                'icon'      => 'ldat-icon-activity-timeline',
                'label'     => __( 'Activity', 'learndash-activity-timeline' ),
                'content'   => $this->get_tab_content( $course_id )
            );
        }

        return $tabs;
    }

    /**
     * Get content for the Activity timeline tab.
     * 
     * @param int $course_id Course ID.
     * 
     * @return string Activity timeline tab content.
     */
    public function get_tab_content( $course_id ) {
        return sprintf( 
            '<div class="ldat-activity-timeline" data-course-id="%s">%s</div>',
            esc_attr( $course_id ),
            $this->get_activities( $course_id )
        );
    }

    /**
     * Get activities for the Activity timeline tab.
     * 
     * @param int $course_id Course ID.
     * @param int $page Current page.
     * 
     * @return string HTML of Activities template.
     */
    public function get_activities( $course_id, $page = 1 ) {
        $options                = Options::get_instance();
        $count_activities       = Timeline::get_count_activities( $course_id );
        $activities_per_page    = apply_filters( 'ldat_tab_content_activities_per_page', $options->get( 'activities_per_page' ) );
        $page                   = max( 1, $page );
        $dates_offset           = ( $page - 1 ) * $activities_per_page;
        $total_pages            = ceil( $count_activities / $activities_per_page );
        $prev_page              = $page - 1 > 0 && $page <= $total_pages ? $page - 1 : null;
        $next_page              = $page + 1 <= $total_pages ? $page + 1 : null;
        $activities             = Timeline::get_activities( $course_id, $activities_per_page, $dates_offset );

        return Template::get( 'activities.php', array(
            'course_id'             => $course_id,
            'count_activities'      => $count_activities,
            'page'                  => $page,
            'total_pages'           => $total_pages,
            'prev_page'             => $prev_page,
            'next_page'             => $next_page,
            'activities'            => $activities
        ) );
    }

    /**
     * AJAX Load activities for pagination.
     * 
     * @return void.
     */
    public function load_activities() {
        $nonce = isset( $_POST['nonce'] ) ? $_POST['nonce'] : '';

        if ( ! wp_verify_nonce( $nonce, self::AJAX_ACTION ) ) {
            wp_send_json( array( 'message' => __( 'A security error has occurred. Please refresh the page and try again.', 'learndash-activity-timeline' ) ), 403 );
        }

        $course_id  = ! empty( $_POST['course_id'] ) ? ( int ) $_POST['course_id'] : 0;
        $page       = ! empty( $_POST['page'] ) ? ( int ) $_POST['page'] : 1;

        if ( ! $course_id || ! $page ) {
            wp_send_json( array( 'message' => __( 'An error has occurred. Missing some data. Please reload the page and try again.', 'learndash-activity-timeline' ) ), 404 );
        }

        $response = array(
            'html' => $this->get_activities( $course_id, $page )
        );

        wp_send_json( $response, 200 );
    }
}