<?php

namespace LDAT;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Timeline;
use LDAT\Classes\Activities\Activity_Course;
use LDAT\Classes\Activities\Activity_Course_Quiz;
use LDAT\Classes\Activities\Activity_Lesson;
use LDAT\Classes\Activities\Activity_Lesson_Quiz;
use LDAT\Classes\Activities\Activity_Topic;
use LDAT\Classes\Activities\Activity_Topic_Quiz;
use LDAT\Classes\Activities\Activity_Assignment;
use LDAT\Classes\Activities\Activity_Essay;

class Activity_Triggers {
    use \LDAT\Traits\Trait_Singleton;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'learndash_update_course_access', array( $this, 'course_enrolled' ), 10, 4 );
        add_action( 'learndash_course_completed', array( $this, 'course_completed' ) );
        add_action( 'learndash_lesson_completed', array( $this, 'lesson_completed' ) );
        add_action( 'learndash_topic_completed', array( $this, 'topic_completed' ) );
        add_action( 'learndash_quiz_submitted', array( $this, 'quiz_completed' ), 10, 2 );
        add_action( 'learndash_assignment_uploaded', array( $this, 'assignment_submitted' ), 10, 2 );
        add_action( 'learndash_assignment_approved', array( $this, 'assignment_approved' ) );
        add_action( 'comment_post', array( $this, 'assignment_commented' ), 10, 3 );
        add_action( 'learndash_essay_all_quiz_data_updated', array( $this, 'essay_updated' ), 10, 4 );
        add_action( 'comment_post', array( $this, 'essay_commented' ), 10, 3 );
    }

    /**
     * Trigger enroll into a course.
     * 
     * @param int $user_id User ID.
     * @param int $course_id Course ID.
     * @param string $course_access_list A comma-separated list of user IDs used for the course_access_list field.
     * @param boolean $remove Whether to remove course access from the user.
     * 
     * @return void
     */
    public function course_enrolled( $user_id, $course_id, $course_access_list, $remove ) {
        if ( ! Timeline::is_open_course( $course_id ) && $remove == false ) {
            Timeline::save_activity( new Activity_Course( $user_id, $course_id, $course_id, Activity_Course::STATUS_ENROLLED ) );
        }
    }

    /**
     * Trigger complete a course.
     * 
     * @param array $course_data Course data.
     * 
     * @return void
     */
    public function course_completed( $course_data ) {
        if ( ! Timeline::is_open_course( $course_data['course']->ID ) ) {
            $certificate_id = (int) learndash_get_setting( $course_data['course']->ID, 'certificate' );

            if ( $certificate_id ) {
                Timeline::save_activity( new Activity_Course( $course_data['user']->ID, $course_data['course']->ID, $course_data['course']->ID, Activity_Course::STATUS_EARNED_CERTIFICATE, array( 'certificate_id' => $certificate_id ) ) );
            }

            Timeline::save_activity( new Activity_Course( $course_data['user']->ID, $course_data['course']->ID, $course_data['course']->ID, Activity_Course::STATUS_COMPLETED ) );
        }
    }

    /**
     * Trigger complete a lesson.
     * 
     * @param array $lesson_data Lesson data.
     * 
     * @return void
     */
    public function lesson_completed( $lesson_data ) {
        if ( ! Timeline::is_open_course( $lesson_data['course']->ID ) ) {
            Timeline::save_activity( new Activity_Lesson( $lesson_data['user']->ID, $lesson_data['course']->ID, $lesson_data['lesson']->ID, Activity_Lesson::STATUS_COMPLETED ) );
        }
    }

    /**
     * Trigger complete a topic.
     * 
     * @param array $topic_data Topic data.
     * 
     * @return void
     */
    public function topic_completed( $topic_data ) {
        if ( ! Timeline::is_open_course( $topic_data['course']->ID ) ) {
            Timeline::save_activity( new Activity_Topic( $topic_data['user']->ID, $topic_data['course']->ID, $topic_data['topic']->ID, Activity_Topic::STATUS_COMPLETED, array( 'lesson_id' => $topic_data['lesson']->ID ) ) );
        }
    }

    /**
     * Trigger complete a quiz.
     * 
     * @param array $topic_data Quiz data.
     * @param object $user Instance of WP_User.
     * 
     * @return void
     */
    public function quiz_completed( $quiz_data, $user ) {
        if ( ! Timeline::is_open_course( $quiz_data['course']->ID ) ) {
            $passing_percentage = ( int ) learndash_get_setting( $quiz_data['quiz'], 'passingpercentage' );
            $quiz_passed        = $passing_percentage <= $quiz_data['percentage'];
            $activity_data      = array(
                'lesson_id'             => $quiz_data['lesson']->ID,
                'percentage'            => $quiz_data['percentage'],
                'passing_percentage'    => $passing_percentage
            );

            if ( $quiz_data['topic'] > 0 ) {
                Timeline::save_activity( new Activity_Topic_Quiz( $user->ID, $quiz_data['course']->ID, $quiz_data['quiz'], ( $quiz_passed ? Activity_Topic_Quiz::STATUS_PASSED : Activity_Topic_Quiz::STATUS_FAILED ), $activity_data ) );
            } elseif ( $quiz_data['lesson'] > 0 ) {
                Timeline::save_activity( new Activity_Lesson_Quiz( $user->ID, $quiz_data['course']->ID, $quiz_data['quiz'], ( $quiz_passed ? Activity_Lesson_Quiz::STATUS_PASSED : Activity_Lesson_Quiz::STATUS_FAILED ), $activity_data ) );
            } else {
                Timeline::save_activity( new Activity_Course_Quiz( $user->ID, $quiz_data['course']->ID, $quiz_data['quiz'], ( $quiz_passed ? Activity_Course_Quiz::STATUS_PASSED : Activity_Course_Quiz::STATUS_FAILED ), $activity_data ) );
            }
        }
    }

    /**
     * Trigger submit an assignment.
     * 
     * @param int $assignment_id Assignment ID.
     * @param array $assignment_data Assignment data.
     * 
     * @return void
     */
    public function assignment_submitted( $assignment_id, $assignment_data ) {
        if ( ! Timeline::is_open_course( $assignment_data['course_id'] ) ) {
            Timeline::save_activity( new Activity_Assignment( $assignment_data['user_id'], $assignment_data['course_id'], $assignment_id, Activity_Assignment::STATUS_SUBMITTED, array( 'lesson_id' => $assignment_data['lesson_id'] ) ) );
        }
    }

    /**
     * Trigger approve an assignment.
     * 
     * @param int $assignment_id Assignment ID.
     * 
     * @return void
     */
    public function assignment_approved( $assignment_id ) {
        $user_id        = ( int ) get_post_meta( $assignment_id, 'user_id', true );
        $course_id      = ( int ) get_post_meta( $assignment_id, 'course_id', true );
        $lesson_id      = ( int ) get_post_meta( $assignment_id, 'lesson_id', true );

        if ( $user_id && $course_id && $lesson_id && ! Timeline::is_open_course( $course_id ) ) {
            Timeline::save_activity( new Activity_Assignment( $user_id, $course_id, $assignment_id, Activity_Assignment::STATUS_APPROVED, array( 'lesson_id' => $lesson_id ) ) );
        }
    }

    /**
     * Trigger comment an assignment.
     * 
     * @param int $comment_id Comment ID.
     * @param int/string $comment_approved Comment approvement.
     * @param array $comment_data Comment data.
     * 
     * @return void
     */
    public function assignment_commented( $comment_id, $comment_approved, $comment_data ) {
        if ( get_post_type( $comment_data['comment_post_ID'] ) == learndash_get_post_type_slug( 'assignment' ) && $comment_approved === 1 ) {
            $assignment         = get_post( $comment_data['comment_post_ID'] );
            $assignment_id      = $assignment->ID;
            $user_id            = ( int ) get_post_meta( $assignment_id, 'user_id', true );
            $course_id          = ( int ) get_post_meta( $assignment_id, 'course_id', true );
            $lesson_id          = ( int ) get_post_meta( $assignment_id, 'lesson_id', true );
            $comment_user_id    = $comment_data['user_ID'];

            if ( $user_id && $course_id && $lesson_id && ! Timeline::is_open_course( $course_id ) ) {
                Timeline::save_activity( new Activity_Assignment( $user_id, $course_id, $assignment_id, Activity_Assignment::STATUS_COMMENTED, array( 'lesson_id' => $lesson_id, 'comment_id' => $comment_id, 'comment_user_id' => $comment_user_id ) ) );
            }
        }
    }

    /**
     * Trigger update an essay.
     * 
     * @param int $quiz_id Quiz ID.
     * @param int $question_id Question ID.
     * @param array $updated_scoring_data Updated scoring data.
     * @param object $essay Instance of WP_Post.
     * 
     * @return void
     */
    public function essay_updated( $quiz_id, $question_id, $updated_scoring_data, $essay ) {
        $essay_id       = $essay->ID;
        $user_id        = ( int ) $essay->post_author;
        $course_id      = ( int ) get_post_meta( $essay_id, 'course_id', true );
        $lesson_id      = ( int ) get_post_meta( $essay_id, 'lesson_id', true );

        if ( $essay->post_status == Activity_Essay::STATUS_GRADED && $user_id && $course_id && $lesson_id && ! Timeline::is_open_course( $course_id ) ) {
            Timeline::save_activity( new Activity_Essay( $user_id, $course_id, $essay_id, Activity_Essay::STATUS_GRADED, array( 'lesson_id' => $lesson_id, 'quiz_id' => $quiz_id ) ) );
        }
    }

    /**
     * Trigger comment an essay.
     * 
     * @param int $comment_id Comment ID.
     * @param int/string $comment_approved Comment approvement.
     * @param array $comment_data Comment data.
     * 
     * @return void
     */
    public function essay_commented( $comment_id, $comment_approved, $comment_data ) {
        if ( get_post_type( $comment_data['comment_post_ID'] ) == learndash_get_post_type_slug( 'essay' ) && $comment_approved === 1 ) {
            $essay              = get_post( $comment_data['comment_post_ID'] );
            $essay_id           = $essay->ID;
            $user_id            = ( int ) $essay->post_author;
            $course_id          = ( int ) get_post_meta( $essay_id, 'course_id', true );
            $lesson_id          = ( int ) get_post_meta( $essay_id, 'lesson_id', true );
            $comment_user_id    = $comment_data['user_ID'];

            if ( $user_id && $course_id && $lesson_id && ! Timeline::is_open_course( $course_id ) ) {
                Timeline::save_activity( new Activity_Essay( $user_id, $course_id, $essay_id, Activity_Essay::STATUS_COMMENTED, array( 'lesson_id' => $lesson_id, 'comment_id' => $comment_id, 'comment_user_id' => $comment_user_id ) ) );
            }
        }
    }
}