<?php

namespace LDAT;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Timeline;

class Course {
    use \LDAT\Traits\Trait_Singleton;

    /**
     * @var string Settings form nonce action.
     */
    const NONCE_ACTION = 'ldat_course_reset_activities';

    /**
     * @var string Settings form nonce name.
     */
    const NONCE_NAME = 'ldat_nonce_course_reset_activities';

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_metabox_reset_activities' ) );
        add_action( 'save_post', array( $this, 'save_course' ), 10, 3 );
        add_action( 'deleted_post', array( $this, 'delete_course' ) );
    }

    /**
     * Add the metabox to courses.
     * 
     * @return void
     */
    public function add_metabox_reset_activities() {
        add_meta_box( 'ldat_metabox_activities', 'Activity Timeline', array( $this, 'render_metabox_activities' ), learndash_get_post_type_slug( 'course' ), 'side', 'core' );
    }

    /**
     * Render the metabox.
     * 
     * @return void
     */
    public function render_metabox_activities( $post ) { ?>
        <p style="margin:0 0 5px;">
            <label style="display:inline-block;margin:6px 0 0;">
                <input type="checkbox" name="ldat_reset_activities" value="true"> <?php _e( 'Reset activities', 'learndash-activity-timeline' ); ?>
            </label>
        </p>
        <span style="font-size:12px;color:#757575;"><?php _e( 'All activities will be deleted from this course.', 'learndash-activity-timeline' ); ?> <strong><?php _e( 'This can\'t be undone.', 'learndash-activity-timeline' ); ?></strong></span>
        <?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME );
    }

    /**
     * Save a course.
     * 
     * @param int $post_id Post ID.
     * @param object $post Instance of WP_Post.
     * @param boolean $update Is a post update.
     * 
     * @return void
     */
    public function save_course( $post_id, $post, $update ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( get_post_type( $post_id ) != learndash_get_post_type_slug( 'course' ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $nonce_action = ! empty( $_POST[ self::NONCE_NAME ] ) ? $_POST[ self::NONCE_NAME ] : '';

        if ( ! wp_verify_nonce( $nonce_action, self::NONCE_ACTION ) ) {
            return;
        }

        $reset_activities = ! empty( $_POST[ 'ldat_reset_activities' ] ) && $_POST[ 'ldat_reset_activities' ] == 'true';

        if ( $reset_activities ) {
            Timeline::delete_activities_by_course_id( $post_id );
        }
    }

    /**
     * Delete a course.
     * 
     * @param int $post_id Post ID.
     * 
     * @return void
     */
    public function delete_course( $post_id ) {
        if ( get_post_type( $post_id ) != learndash_get_post_type_slug( 'course' ) ) {
            return;
        }

        Timeline::delete_activities_by_course_id( $post_id );
    }
}