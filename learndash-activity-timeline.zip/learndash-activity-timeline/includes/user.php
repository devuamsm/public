<?php

namespace LDAT;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Timeline;

class User {
    use \LDAT\Traits\Trait_Singleton;

    /**
     * @var string Settings form nonce action.
     */
    const NONCE_ACTION = 'ldat_user_reset_activities';

    /**
     * @var string Settings form nonce name.
     */
    const NONCE_NAME = 'ldat_nonce_user_reset_activities';

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'show_user_profile', array( $this, 'render_user_fields' ) );
        add_action( 'edit_user_profile', array( $this, 'render_user_fields' ) );
        add_action( 'personal_options_update', array( $this, 'save_user' ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_user' ) );
        add_action( 'delete_user', array( $this, 'delete_user' ), 999 );
    }

    /**
     * Render user fields.
     * 
     * @param object $user Instance of WP_User.
     * 
     * @return void
     */
    public function render_user_fields( $user ) {
        if ( ! current_user_can( 'edit_users' ) ) {
            return;
        } ?>

        <h3><?php echo 'Activity Timeline'; ?></h3>
        <div>
            <p style="margin:0 0 5px;">
                <label style="display:inline-block;margin:6px 0 0;">
                    <input type="checkbox" name="ldat_reset_activities" value="true"> <?php _e( 'Reset activities', 'learndash-activity-timeline' ); ?>
                </label>
            </p>
            <span style="font-size:12px;color:#757575;"><?php _e( 'All activities will be deleted for this user from all courses.', 'learndash-activity-timeline' ); ?> <strong><?php _e( 'This can\'t be undone.', 'learndash-activity-timeline' ); ?></strong></span>
            <?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
        </div>
    <?php }

    /**
     * Save a user.
     * 
     * @param int $user_id User ID.
     * 
     * @return void
     */
    public function save_user( $user_id ) {
        if ( ! current_user_can( 'edit_users' ) ) {
            return;
        }

        $nonce_action = ! empty( $_POST[ self::NONCE_NAME ] ) ? $_POST[ self::NONCE_NAME ] : '';

        if ( ! wp_verify_nonce( $nonce_action, self::NONCE_ACTION ) ) {
            return;
        }

        $reset_activities = ! empty( $_POST[ 'ldat_reset_activities' ] ) && $_POST[ 'ldat_reset_activities' ] == 'true';

        if ( $reset_activities ) {
            Timeline::delete_activities_by_user_id( $user_id );
        }
    }

    /**
     * Delete a user.
     * 
     * @param int $user_id User ID.
     * 
     * @return void
     */
    public function delete_user( $user_id ) {
        Timeline::delete_activities_by_user_id( $user_id );
    }
}