<?php

namespace LDAT\Classes\Database\Tables;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Database\DB_Table;
use LDAT\Classes\Helpers;

class Table_Activities extends DB_Table {
    /**
     * @var string DB table name.
     */
    const TABLE_NAME = 'activities';

    /**
     * Create DB table.
     * 
     * @return void
     */
    public function create_table() {
        if ( ! $this->db->query( "SHOW TABLES LIKE `" . $this->table() .  "`;" ) ) {
            dbDelta( 
                "CREATE TABLE `" . $this->table() . "` (
                    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id` bigint(20) NOT NULL,
                    `course_id` bigint(20) NOT NULL,
                    `activity_id` bigint(20) NOT NULL,
                    `activity_type` varchar(255) NOT NULL,
                    `activity_status` varchar(255) NOT NULL,
                    `activity_data` text NOT NULL,
                    `activity_date` datetime NOT NULL,
                    PRIMARY KEY (`id`)
                ) DEFAULT CHARSET=utf8;"
            );
        }
    }

    /**
     * Delete DB table.
     * 
     * @return void
     */
    public function delete_table() {
        $this->db->query( "DROP TABLE `" . $this->table() .  "`;" );
    }

    /**
     * Get enabled activities based on plugin options.
     * 
     * @return array Enabled activities.
     */
    public function get_enabled_activities() {
        $possible_statuses  = Helpers::get_activity_possible_statuses();
        $activities         = array();

        foreach ( $possible_statuses as $activity_type => $activity_statuses ) {
            foreach ( $activity_statuses as $activity_status ) {
                $activity_type_status = $activity_type . '_' . $activity_status;
                
                if ( $this->options->get( 'display_' . $activity_type_status ) ) {
                    $activities[] = $activity_type_status;
                }
            }
        }

        return $activities;
    }

    /**
     * Get MySQL conditions based on selected activities.
     * 
     * @param array Activities.
     * 
     * @return string MySQL conditions.
     */
    public function get_condition_activities( $activities ) {
        $possible_statuses  = Helpers::get_activity_possible_statuses();
        $mysql_condition    = "(`activity_type` = '%s' AND `activity_status` = '%s')";
        $conditions         = array();

        foreach ( $possible_statuses as $activity_type => $activity_statuses ) {
            foreach ( $activity_statuses as $activity_status ) {
                $activity_type_status = $activity_type . '_' . $activity_status;

                $conditions[ $activity_type_status ] = sprintf( $mysql_condition, $activity_type, $activity_status );
            }
        }

        $conditions = array_intersect_key( $conditions, array_flip( $activities ) );

        return sprintf( 'AND (%s)', $conditions ? implode( ' OR ', $conditions ) : '1 != 1' );
    }

    /**
     * Get activities from DB.
     * 
     * @param int $course_id Course ID.
     * @param int $limit Limit for pagination.
     * @param int $offset Offset for pagination.
     * 
     * @return array Activities based on MySQL response.
     */
    public function get_activities_by_course_id( $corse_id, $limit, $offset = 0 ) {
        $condition_activities = $this->get_condition_activities( $this->get_enabled_activities() );

        return $this->db->get_results( 
            $this->db->prepare( 
                "SELECT *
                FROM `" . $this->table() . "`
                WHERE 1 = 1
                AND `course_id` = %d
                " . $condition_activities . "
                ORDER BY `activity_date` DESC
                LIMIT %d, %d",
                $corse_id,
                $offset,
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Get count activity dates from DB.
     * 
     * @param int $course_id Course ID.
     * 
     * @return int Activity dates based on MySQL response.
     */
    public function get_count_activities_by_course_id( $corse_id ) {
        $condition_activities = $this->get_condition_activities( $this->get_enabled_activities() );

        return ( int ) $this->db->get_var( 
            $this->db->prepare( 
                "SELECT COUNT(`id`)
                FROM `" . $this->table() . "`
                WHERE 1 = 1
                AND `course_id` = %d
                " . $condition_activities,
                $corse_id,
            )
        );
    }

    /**
     * Save activity to DB.
     * 
     * @param object $activity Instance of activity depending on its type. See in classes/activities.
     * 
     * @return int|boolean Result of saving.
     */
    public function save_activity( $activity ) {
        return $this->db->insert( 
            $this->table(),
            array( 
                'user_id'               => $activity->get_user_id(),
                'course_id'             => $activity->get_course_id(),
                'activity_id'           => $activity->get_id(),
                'activity_type'         => $activity->get_type(),
                'activity_status'       => $activity->get_status(),
                'activity_data'         => maybe_serialize( $activity->get_data() ),
                'activity_date'         => $activity->get_date()
            ),
            array( '%d', '%d', '%d', '%s', '%s', '%s', '%s' )
        );
    }

    /**
     * Delete activities from DB by Course ID.
     * 
     * @param int $course_id Course ID.
     * 
     * @return int|boolean Result of deleting.
     */
    public function delete_activities_by_course_id( $course_id ) {
        return $this->db->delete( 
            $this->table(),
            array( 
                'course_id' => $course_id,
            ),
            array( '%d' )
        );
    }

    /**
     * Delete activities from DB by User ID.
     * 
     * @param int $user User ID.
     * 
     * @return int|boolean Result of deleting.
     */
    public function delete_activities_by_user_id( $user_id ) {
        return $this->db->delete( 
            $this->table(),
            array( 
                'user_id' => $user_id,
            ),
            array( '%d' )
        );
    }
}