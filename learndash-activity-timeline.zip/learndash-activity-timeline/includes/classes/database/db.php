<?php

namespace LDAT\Classes\Database;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Database\Tables\Table_Activities;

class DB {
    use \LDAT\Traits\Trait_Singleton;

    /**
     * @var string DB version.
     */
    const VERSION = '1.0.0';

    /**
     * @var array DB tables.
     */
    private $tables = array(
        Table_Activities::class
    );

    /**
     * @var array Table instances.
     */
    private $table_instances = array();

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        foreach ( $this->tables as $table ) {
            $table_class    = explode( '\\', $table );
            $table_id       = array_pop( $table_class );

            $this->table_instances[ $table_id ] = $table::get_instance();
        }
    }

    /**
     * Get tables.
     * 
     * @return array Table instances.
     */
    public function get_tables() {
        return $this->table_instances;
    }
}
