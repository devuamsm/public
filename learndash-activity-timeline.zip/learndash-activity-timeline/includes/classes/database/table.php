<?php

namespace LDAT\Classes\Database;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

use LDAT\Classes\Options;
use LDAT\Classes\Database\DB;

abstract class DB_Table {
    use \LDAT\Traits\Trait_Singleton;

    /**
     * @var string DB table prefix.
     */
    const PREFIX = 'ldat_';

    /**
     * @var object Instance of WPDB.
     */
    protected $db;

    /**
     * @var object Instance of plugin options.
     */
    protected $options;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        global $wpdb;

        $this->db       = $wpdb;
        $this->options  = Options::get_instance();
        $db_version     = $this->options->get( 'db_version' );

        if ( ! $db_version || $db_version != DB::VERSION ) {
            $this->create_table();
            $this->options->set( 'db_version', DB::VERSION );
            $this->options->save();
        }
    }

    /**
     * Create DB table.
     * 
     * @return void
     */
    abstract public function create_table();

    /**
     * Delete DB table.
     * 
     * @return void
     */
    abstract public function delete_table();

    /**
     * Get DB table name.
     * 
     * @return void
     */    
    final protected function table() {
        return $this->db->prefix . self::PREFIX . static::TABLE_NAME;
    }
}
