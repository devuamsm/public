<?php

namespace LDAT\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activities\Activity_Course;
use LDAT\Classes\Activities\Activity_Course_Quiz;
use LDAT\Classes\Activities\Activity_Lesson;
use LDAT\Classes\Activities\Activity_Lesson_Quiz;
use LDAT\Classes\Activities\Activity_Topic;
use LDAT\Classes\Activities\Activity_Topic_Quiz;
use LDAT\Classes\Activities\Activity_Assignment;
use LDAT\Classes\Activities\Activity_Essay;
use LDAT\Classes\Database\Tables\Table_Activities;

class Timeline {
    /**
     * Check if a course is open.
     *
     * @param int $course_id Course ID.
     * 
     * @return boolean Result of checking.
     */
    public static function is_open_course( $course_id ) {
        $is_open_course = learndash_get_setting( $course_id, 'course_price_type' ) == 'open';

        return apply_filters( 'ldat_timeline_is_open_course', $is_open_course, $course_id );
    }

    /**
     * Save activity.
     *
     * @param object $activity Instance of activity depending on its type. See in classes/activities.
     * 
     * @return int|false Result of saving.
     */
    public static function save_activity( $activity ) {
        if ( ! self::is_open_course( $activity->get_course_id() ) ) {

            if ( apply_filters( 'ldat_timeline_save_activity', true, $activity ) ) {
                $activity = apply_filters( 'ldat_timeline_before_save_activity', $activity );

                return Table_Activities::get_instance()->save_activity( $activity );
            }
        }
    }

    /**
     * Get activities.
     *
     * @param int $course_id Course ID.
     * @param int $limit Limit for pagination.
     * @param int $offset Offset for pagination.
     * 
     * @return array Activities.
     */
    public static function get_activities( $course_id, $limit, $offset = 0 ) {
        $activities             = Table_Activities::get_instance()->get_activities_by_course_id( $course_id, $limit, $offset );
        $activity_dates         = array_map( '\LDAT\Classes\Helpers::datetime_to_date', array_column( $activities, 'activity_date' ) );
        $activity_dates         = array_unique( $activity_dates );
        $activities_by_date     = array();

        if ( $activities ) {
            foreach( $activity_dates as $activity_date ) {
                foreach ( $activities as $activity ) {
                    if ( $activity_date != date( 'Y-m-d', strtotime( $activity['activity_date'] ) ) ) {
                        continue;
                    }

                    $activity_instance = null;

                    switch ( $activity['activity_type'] ) {
                        case Activity_Course::TYPE:
                            $activity_instance = new Activity_Course(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Course_Quiz::TYPE:
                            $activity_instance = new Activity_Course_Quiz(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Lesson::TYPE:
                            $activity_instance = new Activity_Lesson(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Lesson_Quiz::TYPE:
                            $activity_instance = new Activity_Lesson_Quiz(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Topic::TYPE:
                            $activity_instance = new Activity_Topic(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Topic_Quiz::TYPE:
                            $activity_instance = new Activity_Topic_Quiz(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Assignment::TYPE:
                            $activity_instance = new Activity_Assignment(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                        case Activity_Essay::TYPE:
                            $activity_instance = new Activity_Essay(
                                $activity['user_id'],
                                $activity['course_id'],
                                $activity['activity_id'],
                                $activity['activity_status'],
                                $activity['activity_data'],
                                $activity['activity_date']
                            );
                            break;
                    }

                    if ( $activity_instance ) {
                        $activities_by_date[ $activity_date ][] = $activity_instance;
                    }
                }
            }
        }

        return apply_filters( 'ldat_timeline_get_activities', $activities_by_date );
    }

    /**
     * Get count activities (for pagination).
     *
     * @param int $course_id Course ID.
     * 
     * @return int Count activities.
     */
    public static function get_count_activities( $course_id ) {
        return Table_Activities::get_instance()->get_count_activities_by_course_id( $course_id );
    }

    /**
     * Delete activities by course ID.
     *
     * @param int $course_id Course ID.
     * 
     * @return int|false Result of deleting.
     */
    public static function delete_activities_by_course_id( $course_id ) {
        return Table_Activities::get_instance()->delete_activities_by_course_id( $course_id );
    }

    /**
     * Delete activities by User ID.
     *
     * @param int $user User ID.
     * 
     * @return int|false Result of deleting.
     */
    public static function delete_activities_by_user_id( $user_id ) {
        return Table_Activities::get_instance()->delete_activities_by_user_id( $user_id );
    }
}