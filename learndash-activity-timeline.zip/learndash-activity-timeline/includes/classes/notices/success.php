<?php

namespace LDAT\Classes\Notices;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Notice;

class Success_Notice extends Notice {
    /**
     * Get CSS class.
     *
     * @return string CSS class.
     */
    public function get_css_class() {
        return 'success';
    }
}