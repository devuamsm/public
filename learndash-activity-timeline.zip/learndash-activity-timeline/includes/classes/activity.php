<?php

namespace LDAT\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

abstract class Activity {
    /**
     * @var int User ID.
     */
    protected $user_id = 0;

    /**
     * @var int Course ID.
     */
    protected $course_id = 0;

    /**
     * @var int Activity ID.
     */
    protected $id = 0;

    /**
     * @var string Activity status.
     */
    protected $status = '';

    /**
     * @var array Activity data.
     */
    protected $data = array();

    /**
     * @var string Activity date.
     */
    protected $date = '';

    /**
     * Constructor.
     *
     * @param int $user_id User ID.
     * @param int $course_id Course ID.
     * @param int $id Activity ID.
     * @param string $status Activity status. 
     * @param array $data Activity data.
     * @param string $date Activity Date.
     * 
     * @return void
     */
    public function __construct( $user_id, $course_id, $id, $status, $data = array(), $date = '' ) {
        $this->user_id      = absint( $user_id );
        $this->course_id    = absint( $course_id );
        $this->id           = absint( $id );
        $this->status       = $status;
        $this->data         = maybe_unserialize( $data );
        $this->date         = ! empty( $date ) ? $date : wp_date( 'Y-m-d H:i:s' );
    }

    /**
     * Get user ID.
     *
     * @return int User ID.
     */
    public function get_user_id() {
        return $this->user_id;
    }

    /**
     * Get course ID.
     *
     * @return int Course ID.
     */
    public function get_course_id() {
        return $this->course_id;
    }

    /**
     * Get Activity ID.
     *
     * @return int Activity ID.
     */
    public function get_id() {
        return $this->id;
    }

    /**
     * Get Activity type.
     *
     * @return string Activity type.
     */
    public function get_type() {
        return static::TYPE;
    }

    /**
     * Get Activity status.
     *
     * @return string Activity status.
     */
    public function get_status() {
        return $this->status;
    }

    /**
     * Get Activity possible statuses.
     *
     * @return array Activity possible statuses.
     */
    abstract public static function get_possible_statuses();

    /**
     * Get Activity data.
     *
     * @return array Activity data.
     */
    public function get_data() {
        return $this->data;
    }

    /**
     * Get Activity date.
     *
     * @return string Activity date.
     */
    public function get_date() {
        return $this->date;
    }

    /**
     * Get Activity time.
     *
     * @return string Activity time.
     */
    public function get_time() {
        return date( 'H:i', strtotime( $this->date ) );
    }

    /**
     * Get Activity time ago.
     *
     * @return string Activity time ago.
     */
    public function get_time_ago() {
        return Helpers::time_ago( $this->date );
    }

    /**
     * Get Activity user.
     *
     * @return object Instance of WP_User.
     */
    public function get_user() {
        return get_userdata( $this->user_id );
    }

    /**
     * Get Activity user avatar.
     *
     * @return string Activity user avatar.
     */
    public function get_user_avatar( $size = 26 ) {
        return get_avatar( $this->user_id, $size, '', $this->get_user()->display_name );
    }

    /**
     * Get Activity text statuses.
     *
     * @return array Activity text statuses.
     */
    abstract public function get_text_statuses();

    /**
     * Get Activity text status.
     *
     * @return string text status.
     */
    public function get_text_status() {
        $statuses = $this->get_text_statuses();

        return array_key_exists( $this->get_status(), $statuses ) ? $statuses[ $this->get_status() ] : '';
    }
}