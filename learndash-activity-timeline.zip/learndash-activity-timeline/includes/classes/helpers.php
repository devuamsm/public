<?php

namespace LDAT\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activities\Activity_Course;
use LDAT\Classes\Activities\Activity_Course_Quiz;
use LDAT\Classes\Activities\Activity_Lesson;
use LDAT\Classes\Activities\Activity_Lesson_Quiz;
use LDAT\Classes\Activities\Activity_Topic;
use LDAT\Classes\Activities\Activity_Topic_Quiz;
use LDAT\Classes\Activities\Activity_Assignment;
use LDAT\Classes\Activities\Activity_Essay;

class Helpers {
    /**
     * Get activity classes.
     *
     * @return array Activity classes.
     */
    public static function get_activity_classes() {
        return array(
            Activity_Course::class,
            Activity_Course_Quiz::class,
            Activity_Lesson::class,
            Activity_Lesson_Quiz::class,
            Activity_Topic::class,
            Activity_Topic_Quiz::class,
            Activity_Assignment::class,
            Activity_Essay::class
        );
    }

    /**
     * Get activity types.
     *
     * @return array Activity types.
     */
    public static function get_activity_types() {
        $activities = array();

        foreach( self::get_activity_classes() as $activity ) {
            $activities[] = $activity::TYPE;
        }

        return $activities;
    }

    /**
     * Get activity possible statuses.
     *
     * @return array Possible statuses.
     */
    public static function get_activity_possible_statuses() {
        $statuses = array();

        foreach( self::get_activity_classes() as $activity ) {
            foreach ( $activity::get_possible_statuses() as $possible_status ) {
                $statuses[ $activity::TYPE ][] = $possible_status;
            }
        }

        return $statuses;
    }

    /**
     * Format time to time ago.
     *
     * @param string $time Needed time.
     * 
     * @return string Time ago.
     */
    public static function time_ago( $time ) {
        $now        = strtotime( wp_date( 'Y-m-d H:i:s' ) );
        $ago        = strtotime( $time );
        $diff       = $now - $ago;

        $seconds    = $diff;
        $minutes    = round( $diff / 60 );
        $hours      = round( $diff / 3600 );
        $days       = round( $diff / 86400 );
        $weeks      = round( $diff / 604800 );
        $months     = round( $diff / 2600640 );
        $years      = round( $diff / 31207680 );

        if ( $seconds <= 60 ) {
            return __( 'just now', 'learndash-activity-timeline' );
        } elseif ( $minutes <= 60 ) {
            return sprintf( '%d %s', $minutes, _n( 'minute ago', 'minutes ago', $minutes, 'learndash-activity-timeline' ) );
        } elseif ( $hours <= 24 ) {
            return sprintf( '%d %s', $hours, _n( 'hour ago', 'hours ago', $hours, 'learndash-activity-timeline' ) );
        } elseif ( $days <= 7 ) {
            return sprintf( '%d %s', $days, _n( 'day ago', 'days ago', $days, 'learndash-activity-timeline' ) );
        } elseif ($weeks <= 4.3 ) {
            return sprintf( '%d %s', $weeks, _n( 'week ago', 'weeks ago', $weeks, 'learndash-activity-timeline' ) );
        } elseif ( $months <= 12 ) {
            return sprintf( '%d %s', $months, _n( 'month ago', 'months ago', $months, 'learndash-activity-timeline' ) );
        } else {
            return sprintf( '%d %s', $years, _n( 'year ago', 'years ago', $years, 'learndash-activity-timeline' ) );
        }
    }

    /**
     * Format datetime to date.
     *
     * @param string $datetime Needed datetime.
     * 
     * @return string Date.
     */
    public static function datetime_to_date( $datetime ) {
        return date( 'Y-m-d', strtotime( $datetime ) );
    }
}