<?php

namespace LDAT\Classes\Activities;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activity;

class Activity_Assignment extends Activity {
    /**
     * @var string Activity type.
     */
    const TYPE = 'assignment';

    /**
     * @var string Activity status submitted.
     */
    const STATUS_SUBMITTED = 'submitted';

    /**
     * @var string Activity status approved.
     */
    const STATUS_APPROVED = 'approved';

    /**
     * @var string Activity status commented.
     */
    const STATUS_COMMENTED = 'commented';

    /**
     * Get Activity possible statuses.
     *
     * @return array Activity possible statuses.
     */
    public static function get_possible_statuses() {
        return array(
            self::STATUS_SUBMITTED,
            self::STATUS_APPROVED,
            self::STATUS_COMMENTED
        );
    }

    /**
     * Get Activity text statuses.
     *
     * @return array Activity text statuses.
     */
    public function get_text_statuses() {
        return array(
            self::STATUS_SUBMITTED  => __( 'has submitted assignment to lesson %s', 'learndash-activity-timeline' ),
            self::STATUS_APPROVED   => __( '%s assignment has been approved', 'learndash-activity-timeline' ),
            self::STATUS_COMMENTED  => __( 'has received a comment on assignment from %s', 'learndash-activity-timeline' )
        );
    }
}