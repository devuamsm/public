<?php

namespace LDAT\Classes\Activities;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activity;

class Activity_Lesson extends Activity {
    /**
     * @var string Activity type.
     */
    const TYPE = 'lesson';

    /**
     * @var string Activity status completed.
     */
    const STATUS_COMPLETED = 'completed';

    /**
     * Get Activity possible statuses.
     *
     * @return array Activity possible statuses.
     */
    public static function get_possible_statuses() {
        return array(
            self::STATUS_COMPLETED
        );
    }

    /**
     * Get Activity text statuses.
     *
     * @return array Activity text statuses.
     */
    public function get_text_statuses() {
        return array(
            self::STATUS_COMPLETED => __( 'has completed lesson %s', 'learndash-activity-timeline' )
        );
    }
}