<?php

namespace LDAT\Classes\Activities;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activity;

class Activity_Essay extends Activity {
    /**
     * @var string Activity type.
     */
    const TYPE = 'essay';

    /**
     * @var string Activity status graded.
     */
    const STATUS_GRADED = 'graded';

    /**
     * @var string Activity status commented.
     */
    const STATUS_COMMENTED = 'commented';

    /**
     * Get Activity possible statuses.
     *
     * @return array Activity possible statuses.
     */
    public static function get_possible_statuses() {
        return array(
            self::STATUS_GRADED,
            self::STATUS_COMMENTED
        );
    }

    /**
     * Get Activity text statuses.
     *
     * @return array Activity text statuses.
     */
    public function get_text_statuses() {
        return array(
            self::STATUS_GRADED     => __( '%s essay has been graded', 'learndash-activity-timeline' ),
            self::STATUS_COMMENTED  => __( 'has received a comment on essay from instructor %s', 'learndash-activity-timeline' ),
        );
    }
}