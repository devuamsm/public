<?php

namespace LDAT\Classes\Activities;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activity;

class Activity_Lesson_Quiz extends Activity {
    /**
     * @var string Activity type.
     */
    const TYPE = 'lesson_quiz';

    /**
     * @var string Activity status passed.
     */
    const STATUS_PASSED = 'passed';

    /**
     * @var string Activity status failed.
     */
    const STATUS_FAILED = 'failed';

    /**
     * Get Activity possible statuses.
     *
     * @return array Activity possible statuses.
     */
    public static function get_possible_statuses() {
        return array(
            self::STATUS_PASSED,
            self::STATUS_FAILED
        );
    }

    /**
     * Get Activity text statuses.
     *
     * @return array Activity text statuses.
     */
    public function get_text_statuses() {
        return array(
            self::STATUS_PASSED     => __( 'has passed quiz %s with %s marks', 'learndash-activity-timeline' ),
            self::STATUS_FAILED     => __( 'has failed quiz %s with %s marks', 'learndash-activity-timeline' )
        );
    }
}