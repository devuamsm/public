<?php

namespace LDAT\Classes\Activities;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Activity;

class Activity_Course extends Activity {
    /**
     * @var string Activity type.
     */
    const TYPE = 'course';

    /**
     * @var string Activity status enrolled.
     */
    const STATUS_ENROLLED = 'enrolled';

    /**
     * @var string Activity status completed.
     */
    const STATUS_COMPLETED = 'completed';

    /**
     * @var string Activity status earned certificate.
     */
    const STATUS_EARNED_CERTIFICATE = 'earned_certificate';

    /**
     * Get Activity possible statuses.
     *
     * @return array Activity possible statuses.
     */
    public static function get_possible_statuses() {
        return array(
            self::STATUS_ENROLLED,
            self::STATUS_COMPLETED,
            self::STATUS_EARNED_CERTIFICATE
        );
    }

    /**
     * Get Activity text statuses.
     *
     * @return array Activity text statuses.
     */
    public function get_text_statuses() {
        return array(
            self::STATUS_ENROLLED                => __( 'has enrolled into course %s', 'learndash-activity-timeline' ),
            self::STATUS_COMPLETED               => __( 'has completed course %s', 'learndash-activity-timeline' ),
            self::STATUS_EARNED_CERTIFICATE      => __( 'has earned course %s certificate', 'learndash-activity-timeline' )
        );
    }
}