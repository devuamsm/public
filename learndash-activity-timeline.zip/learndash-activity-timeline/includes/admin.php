<?php

namespace LDAT;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDAT\Classes\Options;
use LDAT\Classes\License_Manager;
use LDAT\Classes\Notice_Manager;
use LDAT\Classes\Template;

class Admin {
    use \LDAT\Traits\Trait_Singleton;

    const PAGE_SLUG = 'ldat-activity-timeline';

    /**
     * @var string Settings form nonce action.
     */
    const FORM_NONCE_ACTION = 'ldat_submit_settings_form';

    /**
     * @var string Settings form nonce name.
     */
    const FORM_NONCE_NAME = 'ldat_nonce_settings_form';

    /**
     * @var string Settings form action save.
     */
    const FORM_ACTION_SAVE_SETTINGS = 'save_settings';

    /**
     * @var string Settings form action activate license key.
     */
    const FORM_ACTION_ACTIVATE_LICENSE_KEY = 'activate_license_key';

    /**
     * @var string Settings form action deactivate license key.
     */
    const FORM_ACTION_DEACTIVATE_LICENSE_KEY = 'deactivate_license_key';

    /**
     * @var string Settings form action deactivate license key.
     */
    const FORM_ACTION_CHECK_LICENSE_KEY = 'check_license_key';

    /**
     * @var object Plugin options.
     */
    private $options;

    /**
     * @var object License manager.
     */
    private $license_manager;

    /**
     * @var object Notice manager.
     */
    private $notice_manager;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        Course::get_instance();
        User::get_instance();

        $this->options              = Options::get_instance();
        $this->license_manager      = License_Manager::get_instance();
        $this->notice_manager       = new Notice_Manager;

        add_filter( 'plugin_action_links', array( $this, 'plugin_action_links' ), 10, 4 );
        add_action( 'admin_menu', array( $this, 'admin_menu' ), 11 );
    }

    /**
     * Add an item to the plugin action links.
     * 
     * @param array $actions Current plugin actions.
     * @return string $plugin_file Current plugin file.
     * @return array $plugin_data Current plugin data.
     * @return string $context Current plugins.php page tab.
     * 
     * @return array $actions Modified plugin actions.
     */
    public function plugin_action_links( $actions, $plugin_file, $plugin_data, $context ) {
        if ( plugin_basename( LDAT_FILE ) == $plugin_file ) {
            $settings_link = sprintf( '<a href="%s">%s</a>', esc_url( add_query_arg( 'page', self::PAGE_SLUG, admin_url( 'admin.php' ) ) ), __( 'Settings', 'learndash-activity-timeline' ) );
            array_unshift( $actions, $settings_link );
        }

        return $actions;
    }

    /**
     * Add an item to LearnDash admin menu.
     * 
     * @return void
     */
    public function admin_menu() {
        $admin_page = add_submenu_page( 'learndash-lms', 'Activity Timeline', 'Activity Timeline', 'manage_options', self::PAGE_SLUG, array( $this, 'render_admin_page' ) );
    }

    /**
     * Save settings.
     * 
     * @return void
     */
    public function save_settings( $data ) {
        if ( isset( $data['display_activities']['course_enrolled'] ) ) {
            $this->options->set( 'display_course_enrolled', $data['display_activities']['course_enrolled'] == 'true' );
        }

        if ( isset( $data['display_activities']['course_earned_certificate'] ) ) {
            $this->options->set( 'display_course_earned_certificate', $data['display_activities']['course_earned_certificate'] == 'true' );
        }

        if ( isset( $data['display_activities']['course_completed'] ) ) {
            $this->options->set( 'display_course_completed', $data['display_activities']['course_completed'] == 'true' );
        }

        if ( isset( $data['display_activities']['course_quiz_passed'] ) ) {
            $this->options->set( 'display_course_quiz_passed', $data['display_activities']['course_quiz_passed'] == 'true' );
        }

        if ( isset( $data['display_activities']['course_quiz_failed'] ) ) {
            $this->options->set( 'display_course_quiz_failed', $data['display_activities']['course_quiz_failed'] == 'true' );
        }

        if ( isset( $data['display_activities']['lesson_completed'] ) ) {
            $this->options->set( 'display_lesson_completed', $data['display_activities']['lesson_completed'] == 'true' );
        }

        if ( isset( $data['display_activities']['lesson_quiz_passed'] ) ) {
            $this->options->set( 'display_lesson_quiz_passed', $data['display_activities']['lesson_quiz_passed'] == 'true' );
        }

        if ( isset( $data['display_activities']['lesson_quiz_failed'] ) ) {
            $this->options->set( 'display_lesson_quiz_failed', $data['display_activities']['lesson_quiz_failed'] == 'true' );
        }

        if ( isset( $data['display_activities']['topic_completed'] ) ) {
            $this->options->set( 'display_topic_completed', $data['display_activities']['topic_completed'] == 'true' );
        }

        if ( isset( $data['display_activities']['topic_quiz_passed'] ) ) {
            $this->options->set( 'display_topic_quiz_passed', $data['display_activities']['topic_quiz_passed'] == 'true' );
        }

        if ( isset( $data['display_activities']['topic_quiz_failed'] ) ) {
            $this->options->set( 'display_topic_quiz_failed', $data['display_activities']['topic_quiz_failed'] == 'true' );
        }

        if ( isset( $data['display_activities']['assignment_submitted'] ) ) {
            $this->options->set( 'display_assignment_submitted', $data['display_activities']['assignment_submitted'] == 'true' );
        }

        if ( isset( $data['display_activities']['assignment_approved'] ) ) {
            $this->options->set( 'display_assignment_approved', $data['display_activities']['assignment_approved'] == 'true' );
        }

        if ( isset( $data['display_activities']['assignment_commented'] ) ) {
            $this->options->set( 'display_assignment_commented', $data['display_activities']['assignment_commented'] == 'true' );
        }

        if ( isset( $data['display_activities']['essay_graded'] ) ) {
            $this->options->set( 'display_essay_graded', $data['display_activities']['essay_graded'] == 'true' );
        }

        if ( isset( $data['display_activities']['essay_commented'] ) ) {
            $this->options->set( 'display_essay_commented', $data['display_activities']['essay_commented'] == 'true' );
        }

        $activities_per_page = isset( $data['activities_per_page'] ) ? absint( $data['activities_per_page'] ) : 0;
        $this->options->set( 'activities_per_page', $activities_per_page > 0 ? $activities_per_page : $this->options->get( 'activities_per_page' ) );

        $this->options->save();
        
        $this->notice_manager->success->add( 'settings_saved', sprintf( '<strong>%s</strong>', __( 'Settings saved.', 'learndash-activity-timeline' ) ) );
    }

    /**
     * Activate license key.
     * 
     * @return void
     */
    public function activate_license_key( $data ) {
        $this->license_manager->set_license_key( $data['license_key'] );
        $attempt_activate = $this->license_manager->activate();

        if ( is_wp_error( $attempt_activate ) ) {
            $this->notice_manager->error->add( 'activate_license_key', sprintf( '<strong>%s</strong>', $attempt_activate->get_error_message() ) );
        } else {
            $this->options->set( 'license_key', $this->license_manager->get_license_key() );
            $this->options->save();
            $this->notice_manager->success->add( 'activate_license_key', sprintf( '<strong>%s</strong>', __( 'License key has been activated.', 'learndash-activity-timeline' ) ) );
        }
    }

    /**
     * Deactivate license key.
     * 
     * @return void
     */
    public function deactivate_license_key( $data ) {
        $this->license_manager->set_license_key( $data['license_key'] );
        $attempt_deactivate = $this->license_manager->deactivate();

        if ( is_wp_error( $attempt_deactivate ) ) {
            $this->notice_manager->error->add( 'deactivate_license_key', sprintf( '<strong>%s</strong>', $attempt_deactivate->get_error_message() ) );
        } else {
            $this->options->set( 'license_key', '' );
            $this->options->save();
            $this->notice_manager->success->add( 'deactivate_license_key', sprintf( '<strong>%s</strong>', __( 'License key has been deactivated.', 'learndash-activity-timeline' ) ) );
        }
    }

    /**
     * Check license key.
     * 
     * @return void
     */
    public function check_license_key( $data ) {
        $this->license_manager->set_license_key( $data['license_key'] );
        $attempt_check = $this->license_manager->check();

        if ( is_wp_error( $attempt_check ) ) {
            $this->notice_manager->error->add( 'check_license_key', sprintf( '<strong>%s</strong>', $attempt_check->get_error_message() ) );
        } else {
            $this->notice_manager->success->add( 'check_license_key', sprintf( '<strong>%s</strong>', $this->license_manager->get_status() ) );
        }
    }

    /**
     * Render settings page.
     * 
     * @return void
     */
    public function render_admin_page() {
        if ( ! empty( $_POST['ldat_submit_form'] ) && check_admin_referer( self::FORM_NONCE_ACTION, self::FORM_NONCE_NAME ) ) {
            if ( $_POST['ldat_submit_form'] == self::FORM_ACTION_SAVE_SETTINGS ) {
                $this->save_settings( $_POST['ldat_settings'] );
            } elseif( $_POST['ldat_submit_form'] == self::FORM_ACTION_ACTIVATE_LICENSE_KEY ) {
                $this->activate_license_key( $_POST['ldat_license'] );
            } elseif( $_POST['ldat_submit_form'] == self::FORM_ACTION_DEACTIVATE_LICENSE_KEY ) {
                $this->deactivate_license_key( $_POST['ldat_license'] );
            } elseif( $_POST['ldat_submit_form'] == self::FORM_ACTION_CHECK_LICENSE_KEY ) {
                $this->check_license_key( $_POST['ldat_license'] );
            }
        }

        $checkboxes = array(
            'course_enrolled'               => __( 'Enrolled into a course', 'learndash-activity-timeline' ),
            'course_earned_certificate'     => __( 'Earned a course certificate', 'learndash-activity-timeline' ),
            'course_completed'              => __( 'Completed a course', 'learndash-activity-timeline' ),
            'course_quiz_passed'            => __( 'Passed a course quiz', 'learndash-activity-timeline' ),
            'course_quiz_failed'            => __( 'Failed a course quiz', 'learndash-activity-timeline' ),
            'lesson_completed'              => __( 'Completed a lesson', 'learndash-activity-timeline' ),
            'lesson_quiz_passed'            => __( 'Passed a lesson quiz', 'learndash-activity-timeline' ),
            'lesson_quiz_failed'            => __( 'Failed a lesson quiz', 'learndash-activity-timeline' ),
            'topic_completed'               => __( 'Completed a topic', 'learndash-activity-timeline' ),
            'topic_quiz_passed'             => __( 'Passed a topic quiz', 'learndash-activity-timeline' ),
            'topic_quiz_failed'             => __( 'Failed a topic quiz', 'learndash-activity-timeline' ),
            'assignment_submitted'          => __( 'Submitted an assignment', 'learndash-activity-timeline' ),
            'assignment_approved'           => __( 'Approved an assignment', 'learndash-activity-timeline' ),
            'assignment_commented'          => __( 'Commented on an assignment', 'learndash-activity-timeline' ),
            'essay_graded'                  => __( 'Graded an essay', 'learndash-activity-timeline' ),
            'essay_commented'               => __( 'Commented on an essay', 'learndash-activity-timeline' )
        );

        $page_url   = add_query_arg( array( 'page' => self::PAGE_SLUG ), admin_url( 'admin.php' ) );
        $tabs       = array(
            'general' => array(
                'title' => __( 'General', 'learndash-activity-timeline' ),
                'url'   => $page_url
            ),
            'license' => array(
                'title' => __( 'License', 'learndash-activity-timeline' ),
                'url'   => add_query_arg( array( 'tab' => 'license' ), $page_url )
            )
        );

        $active_tab         = ! empty( $_GET['tab'] ) && array_key_exists( $_GET['tab'], $tabs ) ? $_GET['tab'] : 'general';
        $current_page_url   = ! empty( $_GET['tab'] ) && array_key_exists( $_GET['tab'], $tabs ) ? add_query_arg( array( 'tab' => 'license' ), $page_url ) : $page_url;

        $options            = $this->options;
        $license_manager    = $this->license_manager;
        $notice_manager     = $this->notice_manager;

        $is_license_activated = false;
        $license_key = $this->options->get( 'license_key' );

        if ( $license_key ) {
            $license_manager->set_license_key( $license_key );
            $attempt_check = $license_manager->check();
            $is_license_activated = ! is_wp_error( $attempt_check );
        }

        $form_actions = array(
            'save_settings'             => self::FORM_ACTION_SAVE_SETTINGS,
            'activate_license_key'      => self::FORM_ACTION_ACTIVATE_LICENSE_KEY,
            'deactivate_license_key'    => self::FORM_ACTION_DEACTIVATE_LICENSE_KEY,
            'check_license_key'         => self::FORM_ACTION_CHECK_LICENSE_KEY
        );

        $nonce_field = wp_nonce_field( self::FORM_NONCE_ACTION, self::FORM_NONCE_NAME, true, false );

        Template::render( 'admin/settings-page.php', array(
            'notice_manager'            => $notice_manager,
            'options'                   => $options,
            'page_url'                  => $page_url,
            'active_tab'                => $active_tab,
            'current_page_url'          => $current_page_url,
            'tabs'                      => $tabs,
            'checkboxes'                => $checkboxes,
            'is_license_activated'      => $is_license_activated,
            'form_actions'              => $form_actions,
            'nonce_field'               => $nonce_field,
        ) );
    }
}