<?php
/**
 * Plugin Name: LearnDash Activity Timeline
 * Plugin URI: https://wooninjas.com/downloads/learndash-activity-timeline/
 * Description: Activity Timeline Add-on for LearnDash
 * Version: 1.0.0
 * Text Domain: learndash-activity-timeline
 * Author: Wooninjas
 * Author URI: https://wooninjas.com
 * Requires at least: 5.0
 * Tested up to: 5.8
 * Requires PHP: 5.6
 */

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

require_once 'vendor/autoload.php';

if ( ! function_exists( 'get_plugin_data' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$plugin_data = get_plugin_data( __FILE__ );

/* Define constants. */
! defined( 'LDAT_VERSION' )                   && define( 'LDAT_VERSION', $plugin_data['Version'] );
! defined( 'LDAT_NAME' )                      && define( 'LDAT_NAME', $plugin_data['Name'] );
! defined( 'LDAT_ASSETS_SUFFIX' )             && define( 'LDAT_ASSETS_SUFFIX', ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG === true ? '' : '.min' ) );

! defined( 'LDAT_FILE' )                      && define( 'LDAT_FILE', __FILE__ );
! defined( 'LDAT_URL' )                       && define( 'LDAT_URL', plugins_url( '', LDAT_FILE ) );
! defined( 'LDAT_URL_ASSETS' )                && define( 'LDAT_URL_ASSETS', LDAT_URL . '/assets' );
! defined( 'LDAT_URL_ASSETS_CSS' )            && define( 'LDAT_URL_ASSETS_CSS', LDAT_URL_ASSETS . '/css' );
! defined( 'LDAT_URL_ASSETS_JS' )             && define( 'LDAT_URL_ASSETS_JS', LDAT_URL_ASSETS . '/js' );
! defined( 'LDAT_URL_ASSETS_IMAGES' )         && define( 'LDAT_URL_ASSETS_IMAGES', LDAT_URL_ASSETS . '/images' );
! defined( 'LDAT_PATH' )                      && define( 'LDAT_PATH', dirname( LDAT_FILE ) );
! defined( 'LDAT_PATH_ASSETS' )               && define( 'LDAT_PATH_ASSETS', LDAT_PATH . '/assets' );
! defined( 'LDAT_PATH_ASSETS_IMAGES' )        && define( 'LDAT_PATH_ASSETS_IMAGES', LDAT_PATH_ASSETS . '/images' );
! defined( 'LDAT_PATH_INCLUDES' )             && define( 'LDAT_PATH_INCLUDES', LDAT_PATH . '/includes' );
! defined( 'LDAT_PATH_TEMPLATES' )            && define( 'LDAT_PATH_TEMPLATES', LDAT_PATH . '/templates' );

if ( ! class_exists( 'LD_Activity_Timeline' ) ) {
    class LD_Activity_Timeline {
        /**
         * Init plugin.
         *
         * @return void
         */
        public function __construct() {
            new LDAT\Init;
        }
    }
}

new LD_Activity_Timeline;