<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use \LDAT\Classes\Activities\Activity_Course;
use \LDAT\Classes\Activities\Activity_Course_Quiz;
use \LDAT\Classes\Activities\Activity_Lesson;
use \LDAT\Classes\Activities\Activity_Lesson_Quiz;
use \LDAT\Classes\Activities\Activity_Topic;
use \LDAT\Classes\Activities\Activity_Topic_Quiz;
use \LDAT\Classes\Activities\Activity_Assignment;
use \LDAT\Classes\Activities\Activity_Essay;

if ( $count_activities > 0 ) :
    if ( $prev_page ) : ?>
        <span class="ldat-button ldat-button-previous-page ld-button" data-page="<?php echo esc_attr( $prev_page ); ?>">&larr; <?php _e( 'Previous', 'learndash-activity-timeline' ) ?></span>
    <?php endif; ?>
    <ul class="ldat-dates">
        <?php foreach ( $activities as $activity_date => $activities_per_date ) : 
                if ( ! $activities_per_date ) {
                    continue;
                }
            ?>
            <li class="ldat-date">
                <div class="ldat-date-heading"><?php echo date_i18n( 'F j, Y', strtotime( $activity_date ) ); ?></div>
                <ul class="ldat-activities">
                    <?php foreach ( $activities_per_date as $activity ) : 
                        if ( $activity_date != date( 'Y-m-d', strtotime( $activity->get_date() ) ) || ! $activity->get_user() ) :
                            continue;
                        endif;

                        $activity_status = '';

                        switch ( $activity->get_type() ) :
                            case Activity_Course::TYPE:
                            case Activity_Lesson::TYPE:
                            case Activity_Topic::TYPE:
                                $activity_status = sprintf( 
                                    $activity->get_text_status(),
                                    sprintf(
                                        '<a class="ldat-activity-source" href="%2$s"><span class="ldat-activity-icon-type ldat-activity-icon-type-%1$s"></span> %3$s</a>',
                                        $activity->get_type(),
                                        esc_url( get_the_permalink( $activity->get_id() ) ),
                                        esc_html( get_the_title( $activity->get_id() ) )
                                    )
                                );
                                break;
                            case Activity_Course_Quiz::TYPE:
                            case Activity_Lesson_Quiz::TYPE:
                            case Activity_Topic_Quiz::TYPE:
                                $activity_data      = $activity->get_data();
                                $percentage         = $activity_data['percentage'];
                                $activity_status    = sprintf( 
                                    $activity->get_text_status(),
                                    sprintf(
                                        '<a class="ldat-activity-source" href="%2$s"><span class="ldat-activity-icon-type ldat-activity-icon-type-%1$s"></span> %3$s</a>',
                                        $activity->get_type(),
                                        esc_url( get_the_permalink( $activity->get_id() ) ),
                                        esc_html( get_the_title( $activity->get_id() ) )
                                    ),
                                    sprintf(
                                        '<span class="ldat-quiz-percentage">%s/100%%</span>',
                                        $percentage
                                    )
                                );
                                break;
                            case Activity_Assignment::TYPE:
                                $activity_data = $activity->get_data();

                                switch ( $activity->get_status() ) :
                                    case Activity_Assignment::STATUS_SUBMITTED:
                                    case Activity_Assignment::STATUS_APPROVED:
                                        $lesson_id          = $activity_data['lesson_id'];
                                        $activity_status    = sprintf( 
                                            $activity->get_text_status(),
                                            sprintf(
                                                '<a class="ldat-activity-source" href="%2$s"><span class="ldat-activity-icon-type ldat-activity-icon-type-%1$s"></span> %3$s</a>',
                                                $activity->get_type(),
                                                esc_url( get_the_permalink( $lesson_id ) ),
                                                esc_html( get_the_title( $lesson_id ) )
                                            )
                                        );
                                        break;
                                    case Activity_Assignment::STATUS_COMMENTED:
                                        $activity_status = sprintf( 
                                            $activity->get_text_status(),
                                            sprintf(
                                                '<span class="ldat-activity-source ldat-activity-comment-user"><span class="ldat-activity-icon-type ldat-activity-icon-type-user"></span> %1$s</span>',
                                                get_userdata( $activity_data['comment_user_id'] )->display_name
                                            )
                                        );
                                        break;
                                endswitch;
                            case Activity_Essay::TYPE:
                                $activity_data  = $activity->get_data();

                                switch ( $activity->get_status() ) :
                                    case Activity_Essay::STATUS_GRADED:
                                        $lesson_id          = $activity_data['lesson_id'];
                                        $activity_status = sprintf( 
                                            $activity->get_text_status(),
                                            sprintf(
                                                '<a class="ldat-activity-source" href="%2$s"><span class="ldat-activity-icon-type ldat-activity-icon-type-%1$s"></span> %3$s</a>',
                                                $activity->get_type(),
                                                esc_url( get_the_permalink( $lesson_id ) ),
                                                esc_html( get_the_title( $lesson_id ) )
                                            )
                                        );
                                        break;
                                    case Activity_Essay::STATUS_COMMENTED:
                                        $activity_status    = sprintf( 
                                            $activity->get_text_status(),
                                            sprintf(
                                                '<span class="ldat-activity-source ldat-activity-comment-user"><span class="ldat-activity-icon-type ldat-activity-icon-type-user"></span> %1$s</span>',
                                                get_userdata( $activity_data['comment_user_id'] )->display_name
                                            )
                                        );
                                        break;
                                endswitch;
                        endswitch;
                        ?>
                        <li class="ldat-activity ldat-activity-<?php echo esc_attr( $activity->get_type() );?> ldat-activity-<?php echo esc_attr( $activity->get_status() );?> ldat-activity-<?php echo esc_attr( $activity->get_type() );?>-<?php echo esc_attr( $activity->get_status() );?>">
                            <div class="ldat-activity-icon">
                                <span class="ldat-activity-icon-status ldat-activity-icon-status-<?php echo esc_attr( $activity->get_status() ); ?>"></span>
                            </div>
                            <div class="ldat-activity-user">
                                <div class="ldat-activity-user-avatar"><?php echo $activity->get_user_avatar(); ?></div>
                                <div class="ldat-activity-user-name"><?php echo $activity->get_user()->display_name; ?></div>
                            </div>
                            <div class="ldat-activity-status"><?php echo $activity_status; ?></div>
                            <div class="ldat-activity-date"><?php echo $activity_date == date( 'Y-m-d' ) ? $activity->get_time_ago() : $activity->get_time(); ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php if ( $next_page ) : ?>
        <div class="ldat-button ldat-button-next-page ld-button" data-page="<?php echo esc_attr( $next_page ); ?>"><?php _e( 'Next', 'learndash-activity-timeline' ) ?> &rarr;</div>
    <?php endif;
else : ?>
    <div class="ldat-no-activities"><?php echo apply_filters( 'ldat_tab_content_no_activities', __( 'No activities', 'learndash-activity-timeline' ) ); ?></div>
<?php endif; ?>