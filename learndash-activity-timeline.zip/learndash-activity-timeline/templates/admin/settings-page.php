<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

?>
<div class="wrap ldat-wrap">
<h2 class="ldat-heading"><?php echo get_admin_page_title(); ?></h2>
    <div class="ldat-notices">
        <?php 
            if ( $notice_manager->error->has_notices() ) {
                echo $notice_manager->error->get_all_html();
            } else {
                echo $notice_manager->success->get_all_html(); 
            }
        ?>
    </div>
    <nav class="nav-tab-wrapper ldat-nav-tab-wrapper">
        <?php foreach( $tabs as $tab_id => $tab ) : ?>
            <a href="<?php echo esc_url( $tab['url'] ); ?>" class="nav-tab<?php echo $tab_id == $active_tab ? ' nav-tab-active' : ''; ?>"><?php echo $tab['title']; ?></a>
        <?php endforeach; ?>
    </nav>

        <ul class="subsubsub" style="float:right;margin:15px 0;">
            <li style="vertical-align: middle;">
                <a href="#" target="_blank"><?php _e( 'Changelogs', 'learndash-activity-timeline' ); ?></a> |
            </li>
            <li style="vertical-align: middle;"><a href="#" target="_blank">
                <?php _e( 'Click here to see FAQs', 'learndash-activity-timeline' ); ?></a> |
            </li>
            <li style="vertical-align: middle;">
                <a href="#" target="_blank"><?php _e( 'View Documentation', 'learndash-activity-timeline' ); ?>
            </a> |</li>
            <li style="vertical-align: middle;">
                <a class="button button-primary" href="https://wooninjas.com/open-support-ticket/" target="_blank"><?php _e( 'Open a Support Ticket', 'learndash-activity-timeline' ); ?></a>
            </li>
        </ul>
    <form method="post" action="<?php echo esc_url( $current_page_url ); ?>">
        <?php if ( $active_tab == 'general' ) : ?>
            <table class="form-table">
                <tbody>
                    <tr valign="top">
                        <th scope="row"><?php _e( 'Enable activities', 'ld-activiti-timeline' ); ?></th>
                        <td>
                            <?php foreach( $checkboxes as $activity_id => $label ) : ?>
                                <fieldset>
                                    <label>
                                        <input type="hidden" name="ldat_settings[display_activities][<?php echo $activity_id; ?>]" value="false">
                                        <input type="checkbox" name="ldat_settings[display_activities][<?php echo $activity_id; ?>]" value="true" <?php checked( $options->get( 'display_' . $activity_id ) ); ?>> <?php echo $label; ?>
                                    </label>
                                </fieldset>
                            <?php endforeach; ?>
                            <p class="description" style="margin: 20px 0 0;font-style:italic;"><?php _e( 'The following activities wil be displayed in the Activity Timeline tab', 'ld-activiti-timeline' ); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e( 'Activities per page', 'ld-activiti-timeline' ); ?></th>
                        <td><input type="number" name="ldat_settings[activities_per_page]" min="1" step="1" value="<?php echo esc_attr( $options->get( 'activities_per_page' ) ); ?>"></td>
                    </tr>
                </tbody>
            </table>
            <p class="submit">
                <button class="button button-primary" type="submit" name="ldat_submit_form" value="<?php echo esc_attr( $form_actions['save_settings'] ); ?>"><?php _e( 'Save Settings', 'ld-active-timeline' ); ?></button>
            </p>
        <?php elseif ( $active_tab == 'license' ) : ?>
            <table class="form-table">
                <tbody>
                    <tr valign="top">
                        <th scope="row"><?php _e( 'Status', 'ld-activiti-timeline' ); ?></th>
                        <td>
                            <strong style="color:<?php echo $is_license_activated ? '#32ac96' : '#f15a5a'; ?>;"><?php echo $is_license_activated ? __( 'Active', 'learndash-activity-timeline' ) : __( 'Inactive', 'learndash-activity-timeline' ); ?></strong>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" valign="top"><?php _e( 'License key', 'ld-activiti-timeline' ); ?></th>
                        <td valign="top">
                            <div class="<?php echo $is_license_activated ? ' ldat-hidden' : ''; ?>">
                                <input class="regular-text" type="text" name="ldat_license[license_key]" value="<?php echo esc_attr( $options->get( 'license_key' ) ); ?>" placeholder="<?php _e( 'Enter your license key here', 'ld-active-timeline' ); ?>">
                                <p class="description" style="margin: 20px 0 0;font-style:italic;"><?php printf( __( 'You can find the license key for LearnDash Focus Mode Pro add-on in %s page.', 'ld-active-timeline' ), sprintf( '<a href="https://wooninjas.com/my-account/" class="ldat-link" target="_blank">%s</a>', __( 'My account', 'ld-active-timeline' ) ) ); ?></p>
                            </div>
                            <p class="submit">
                                <?php if ( ! $is_license_activated ) : ?>
                                    <button class="button button-primary" type="submit" name="ldat_submit_form" value="<?php echo esc_attr( $form_actions['activate_license_key'] ); ?>"><?php _e( 'Activate license', 'ld-active-timeline' ); ?></button>
                                <?php else : ?>
                                    <button class="button button-secondary" type="submit" name="ldat_submit_form" value="<?php echo esc_attr( $form_actions['check_license_key'] ); ?>"><?php _e( 'Check license', 'ld-active-timeline' ); ?></button>
                                    <button class="button button-primary" type="submit" name="ldat_submit_form" value="<?php echo esc_attr( $form_actions['deactivate_license_key'] ); ?>"><?php _e( 'Deactivate license', 'ld-active-timeline' ); ?></button>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
        <?php echo $nonce_field; ?>
    </form>
</div>