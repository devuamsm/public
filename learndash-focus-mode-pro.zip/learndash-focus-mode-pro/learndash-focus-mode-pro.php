<?php
/**
 * Plugin Name: LearnDash Focus Mode Pro
 * Plugin URI: https://wooninjas.com/downloads/learndash-focus-mode-pro/
 * Description: LearnDash Focus Mode Pro
 * Version: 1.0.0
 * Text Domain: learndash-focus-mode-pro
 * Author: Wooninjas
 * Author URI: https://wooninjas.com
 * Requires at least: 5.0
 * Tested up to: 5.8.1
 * Requires PHP: 5.6
 */

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

require_once 'vendor/autoload.php';

if( ! function_exists( 'get_plugin_data' ) ){
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$plugin_data = get_plugin_data( __FILE__ );

/* Define constants. */
! defined( 'LDFMP_VERSION' )                && define( 'LDFMP_VERSION', $plugin_data['Version'] );
! defined( 'LDFMP_NAME' )                   && define( 'LDFMP_NAME', $plugin_data['Name'] );
! defined( 'LDFMP_FILE' )                   && define( 'LDFMP_FILE', __FILE__ );
! defined( 'LDFMP_ASSETS_SUFFIX' )          && define( 'LDFMP_ASSETS_SUFFIX', ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG === true ? '' : '.min' ) );
! defined( 'LDFMP_URL_ASSETS' )             && define( 'LDFMP_URL_ASSETS', plugins_url( 'assets', LDFMP_FILE ) );
! defined( 'LDFMP_URL_ASSETS_CSS' )         && define( 'LDFMP_URL_ASSETS_CSS', LDFMP_URL_ASSETS . '/css' );
! defined( 'LDFMP_URL_ASSETS_JS' )          && define( 'LDFMP_URL_ASSETS_JS', LDFMP_URL_ASSETS . '/js' );
! defined( 'LDFMP_URL_ASSETS_IMAGES' )      && define( 'LDFMP_URL_ASSETS_IMAGES', LDFMP_URL_ASSETS . '/images' );
! defined( 'LDFMP_PATH' )                   && define( 'LDFMP_PATH', dirname( LDFMP_FILE ) );
! defined( 'LDFMP_PATH_TEMPLATES' )         && define( 'LDFMP_PATH_TEMPLATES', LDFMP_PATH . '/templates' );

if ( ! class_exists( 'LearnDash_Focus_Mode_Pro' ) ) {
    class LearnDash_Focus_Mode_Pro {
        /**
         * Init plugin.
         *
         * @return void
         */
        public function __construct() {
            new LDFMP\Init;
        }
    }
}

new LearnDash_Focus_Mode_Pro;