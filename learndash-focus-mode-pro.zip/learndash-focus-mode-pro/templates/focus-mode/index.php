<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

if ( have_posts() ) :
    while ( have_posts() ) :
    the_post();

    $course_id  = ldfmp_learndash_get_course_id();
    $user       = wp_get_current_user();
    $user_id    = ( is_user_logged_in() ? $user->ID : false );

    ldfmp_get_template_part( 'focus-mode/header.php', array( 
        'course_id' => $course_id,
        'user_id'   => $user_id
    ) );

    ldfmp_get_template_part( 'focus-mode/sidebar.php', array( 
        'course_id' => $course_id,
        'user_id'   => $user_id
    ) );

    ldfmp_get_template_part( 'focus-mode/content.php', array( 
        'course_id' => $course_id,
        'user_id'   => $user_id
    ) );

    ldfmp_get_template_part( 'focus-mode/footer.php', array( 
        'course_id' => $course_id,
        'user_id'   => $user_id
    ) );
    endwhile;
endif;