<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

$quizzes_settings = apply_filters( 'ldfmp_template_sidebar_quizzes_settings', array(
    'show_course_quizzes' => true,
    'show_topic_quizzes'  => true,
    'show_lesson_quizzes' => true
) );

$course_lessons     = ldfmp_learndash_get_course_lessons( $course_id, $user_id );
$course_quizzes     = ldfmp_learndash_get_course_quizzes( $course_id, $user_id );

if ( ldfmp_display_course_instructors() ) :
    $course_instructors = ldfmp_get_course_instructors( $course_id );

    if ( $course_instructors ) :
        do_action( 'ldfmp_template_sidebar_before_course_instructors', $course_instructors, $course_id, $user_id );
        ?>
        <div class="ldfmp-sidebar-course-instructors">
            <?php
            foreach ( $course_instructors as $course_instructor ) :
            ?>
                <div class="ldfmp-sidebar-course-instructor">
                    <div class="ldfmp-sidebar-course-instructor-avatar">
                        <?php echo $course_instructor['avatar']; ?>
                    </div>
                    <div class="ldfmp-sidebar-course-instructor-data">
                        <div class="ldfmp-sidebar-course-instructor-name"><?php echo $course_instructor['name']; ?></div>
                        <div class="ldfmp-sidebar-course-instructor-position"><?php _e( 'Instructor', 'learndash-focus-mode-pro' ); ?></div>
                    </div>
                </div>
            <?php
            endforeach;
            ?>
        </div>
        <?php
        do_action( 'ldfmp_template_sidebar_after_course_instructors', $course_instructors, $course_id, $user_id );
    endif;
endif;

do_action( 'ldfmp_template_sidebar_before_course_lessons', $course_id, $user_id );
?>
<div class="ldfmp-sidebar-course-lessons">
    <?php
    if ( ! empty( $course_lessons ) ) :
        $i = 0;

        foreach ( $course_lessons as $course_lesson ) :
            ldfmp_get_template_part(
                'focus-mode/parts/sidebar-lesson.php',
                array(
                    'count'             => $i,
                    'course_lesson'     => $course_lesson,
                    'course_id'         => $course_id,
                    'user_id'           => $user_id,
                    'quizzes_settings'  => $quizzes_settings
                )
            );

            $i++;
        endforeach;
    endif;

    if ( ! empty( $course_quizzes ) && $quizzes_settings['show_course_quizzes'] !== false ) :
    ?>
        <div class="ldfmp-sidebar-course-section ldfmp-sidebar-course-section-quizzes"><?php echo __( 'Quizzes', 'learndash-focus-mode-pro' ) ; ?></div>
        <div class="ldfmp-sidebar-course-quizzes">
            <?php
            foreach ( $course_quizzes as $course_quiz ) :
                ldfmp_get_template_part(
                    'focus-mode/parts/sidebar-quiz.php',
                    array(
                        'quiz'      => $course_quiz,
                        'course_id' => $course_id,
                        'user_id'   => $user_id,
                        'context'   => ''
                    )
                );
            endforeach;
            ?>
        </div>
    <?php
    endif;
    ?>
</div>
<?php
do_action( 'ldfmp_template_sidebar_after_course_lessons', $course_id, $user_id );