<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

global $post;

$quiz_status        = $quiz['status'] == 'completed' ? 'completed' : 'incompleted';
$is_current_quiz    = $post && $post->post_type == ldfmp_learndash_get_post_types( 'quiz' ) && get_the_ID() == $quiz['post']->ID;
$base_action        = 'ldfmp_template_sidebar_after_course' . ( ! empty( $context ) ? '_' . str_replace( '-', '_', $context ) : '' ) . '_quiz';
$base_class         = 'ldfmp-sidebar-course' . ( ! empty( $context ) ? '-' . $context : '' ) . '-quiz';

$quiz_class = array(
    $base_class,
    $base_class . '-' . $quiz['post']->ID,
);

if ( $is_current_quiz ) {
    $quiz_class[] = $base_class . '-current';
}

$quiz_class[] = $base_class . '-' . $quiz_status;

do_action( $base_action, $course_id, $user_id, $quiz, $quiz_status, $is_current_quiz );
?>

<div class="<?php echo esc_attr( implode( ' ', $quiz_class ) ); ?>">
    <a class="<?php echo esc_attr( $base_class . '-link' ); ?>" href="<?php echo esc_url( ldfmp_learndash_get_step_permalink( $quiz['post']->ID, $course_id ) ); ?>">
        <div class="<?php echo esc_attr( $base_class . '-icon' ); ?>">
            <span class="<?php echo esc_attr( $base_class . '-status' ); ?> <?php echo esc_attr( $base_class . '-icon-status-' ) . $quiz_status; ?>-<?php echo esc_attr( $quiz_status ); ?>"></span>
        </div>
        <div class="<?php echo esc_attr( $base_class . '-title' ); ?>">
            <?php echo wp_kses_post( apply_filters( 'the_title', $quiz['post']->post_title, $quiz['post']->ID ) ); ?>
        </div>
    </a>
</div>
<?php
do_action( $base_action, $course_id, $user_id, $quiz, $quiz_status, $is_current_quiz );