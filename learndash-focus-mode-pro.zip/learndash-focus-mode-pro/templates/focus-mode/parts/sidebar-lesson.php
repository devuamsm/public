<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

global $post, $course_pager_results;

$lesson_topics          = ldfmp_learndash_get_lesson_topics( $course_lesson['post']->ID, $course_id );
$lesson_quizzes         = ldfmp_learndash_get_lesson_quizzes( $course_lesson['post']->ID, $user_id, $course_id );
$lesson_status          = $course_lesson['status'] == 'completed' ? 'completed' : 'incompleted';
$lesson_content_count   = ldfmp_learndash_get_lesson_content_count( $course_lesson, $course_id );
$is_lesson_expandable   = $lesson_content_count['topics'] > 0 || $lesson_content_count['quizzes'] > 0;

$is_current_lesson      = false;

if ( $post && isset( $post->post_type ) && in_array( $post->post_type, array( ldfmp_learndash_get_post_types( 'lesson' ), ldfmp_learndash_get_post_types( 'topic' ), ldfmp_learndash_get_post_types( 'quiz' ) ) ) ) {
    if ( $post->post_type == ldfmp_learndash_get_post_types( 'lesson' ) && get_the_ID() == $course_lesson['post']->ID ) {
        $is_current_lesson = true;
    } else if ( 
        in_array( $post->post_type, array( ldfmp_learndash_get_post_types( 'topic' ), ldfmp_learndash_get_post_types( 'quiz' ) ) ) && 
        ldfmp_learndash_get_course_single_parent_step( $course_id, $post->ID, ldfmp_learndash_get_post_types( 'lesson' ) ) == $course_lesson['post']->ID
    ) {
        $is_current_lesson = true;
    }
}

ldfmp_get_template_part(
    'focus-mode/parts/sidebar-section.php',
    array(
        'course_id'         => $course_id,
        'user_id'           => $user_id,
        'course_lesson'     => $course_lesson
    )
);

$lesson_class = array( 
    'ldfmp-sidebar-course-lesson',
    'ldfmp-sidebar-course-lesson-' . $course_lesson['post']->ID,
    'ldfmp-sidebar-course-lesson-' . $lesson_status
);

if ( $is_current_lesson ) {
    $lesson_class[] = 'ldfmp-sidebar-course-lesson-current';
}

if ( $is_lesson_expandable ) {
    $lesson_class[] = 'ldfmp-sidebar-course-lesson-expandable';
}

if ( $is_current_lesson ) {
    $lesson_class[] = 'ldfmp-sidebar-course-lesson-expanded';
}

do_action( 'ldfmp_template_sidebar_before_course_lesson', $course_id, $user_id, $course_lesson, $lesson_topics, $lesson_quizzes, $lesson_status, $is_current_lesson );
?>

<div class="<?php echo esc_attr( implode( ' ', $lesson_class ) ); ?>">
    <a class="ldfmp-sidebar-course-lesson-link" href="<?php echo esc_url( ldfmp_learndash_get_step_permalink( $course_lesson['post']->ID, $course_id ) ); ?>">
        <div class="ldfmp-sidebar-course-lesson-icon">
            <span class="ldfmp-sidebar-course-lesson-status ldfmp-sidebar-course-lesson-status-<?php echo esc_attr( $lesson_status ); ?>"></span>
        </div>
        <div class="ldfmp-sidebar-course-lesson-title">
            <?php echo wp_kses_post( apply_filters( 'the_title', $course_lesson['post']->post_title, $course_lesson['post']->ID ) ); ?>
        </div>
        <?php if ( $is_lesson_expandable ) : ?>
            <div class="ldfmp-sidebar-course-lesson-toggle">
                <span class="ldfmp-sidebar-course-lesson-toggle-button"></span>
            </div>
        <?php endif; ?>
    </a>
    <div class="ldfmp-sidebar-course-lesson-expand-content">
        <?php if ( $is_lesson_expandable ) : 
            do_action( 'ldfmp_template_sidebar_before_course_lesson_content', $course_id, $user_id, $course_lesson, $lesson_topics, $lesson_quizzes, $lesson_status, $is_current_lesson );
            ?>
            <div class="ldfmp-sidebar-course-lesson-content">
                <?php
                if ( ! empty( $lesson_topics ) ) :
                    foreach ( $lesson_topics as $lesson_topic ) :
                        ldfmp_get_template_part(
                            'focus-mode/parts/sidebar-topic.php',
                            array(
                                'lesson_topic'      => $lesson_topic,
                                'course_id'         => $course_id,
                                'user_id'           => $user_id,
                                'quizzes_settings'  => $quizzes_settings
                            )
                        );
                    endforeach;
                endif;

                if ( ! empty( $lesson_quizzes ) && $quizzes_settings['show_lesson_quizzes'] !== false ) :
                    foreach ( $lesson_quizzes as $lesson_quiz ) :
                        ldfmp_get_template_part(
                            'focus-mode/parts/sidebar-quiz.php',
                            array(
                                'quiz'      => $lesson_quiz,
                                'course_id' => $course_id,
                                'user_id'   => $user_id,
                                'context'   => 'lesson'
                            )
                        );
                    endforeach;
                endif;
                ?>
            </div>
            <?php
            do_action( 'ldfmp_template_sidebar_after_course_lesson_content', $course_id, $user_id, $course_lesson, $lesson_topics, $lesson_quizzes, $lesson_status, $is_current_lesson );
        endif; ?>
    </div>
</div>
<?php
do_action( 'ldfmp_template_sidebar_after_course_lesson', $course_id, $user_id, $course_lesson, $lesson_topics, $lesson_quizzes, $lesson_status, $is_current_lesson );