<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

$course_sections = ldfmp_learndash_get_course_sections( $course_id );

if ( isset( $course_sections[ $course_lesson['post']->ID ] ) ) :
    $course_section = $course_sections[ $course_lesson['post']->ID ];

    do_action( 'ldfmp_template_sidebar_before_course_section', $course_id, $user_id );
    ?>
    <div class="ldfmp-sidebar-course-section ldfmp-sidebar-course-section-<?php echo esc_attr( $course_section->ID ); ?>"><?php echo esc_html( $course_section->post_title ); ?></div>
    <?php 
    do_action( 'ldfmp_template_sidebar_after_course_section', $course_id, $user_id );
endif;