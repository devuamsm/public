<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

global $post;

$topic_quizzes      = ldfmp_learndash_get_topic_quizzes( $lesson_topic->ID, null, $course_id );
$topic_status       = $lesson_topic->completed ? 'completed' : 'incompleted';
$is_current_topic   = $post && $post->post_type == ldfmp_learndash_get_post_types( 'topic' ) && get_the_ID() == $lesson_topic->ID;

$topic_class = array(
    'ldfmp-sidebar-course-lesson-topic',
    'ldfmp-sidebar-course-lesson-topic-' . $lesson_topic->ID,
    'ldfmp-sidebar-course-lesson-topic-' . $topic_status
);

if ( $is_current_topic ) {
    $topic_class[] = 'ldfmp-sidebar-course-lesson-topic-current';
}
do_action( 'ldfmp_template_sidebar_before_course_lesson_topic', $lesson_topic, $topic_status, $is_current_topic, $course_id, $user_id );
?>

<div class="<?php echo esc_attr( implode( ' ', $topic_class ) ); ?>">
    <a class="ldfmp-sidebar-course-lesson-topic-link" href="<?php echo esc_url( ldfmp_learndash_get_step_permalink( $lesson_topic->ID, $course_id ) ); ?>">
        <div class="ldfmp-sidebar-course-lesson-topic-icon">
            <span class="ldfmp-sidebar-course-lesson-topic-status ldfmp-sidebar-course-lesson-topic-status-<?php echo esc_attr( $topic_status ); ?>"></span>
        </div>
        <div class="ldfmp-sidebar-course-lesson-topic-title">
            <?php echo wp_kses_post( get_the_title( $lesson_topic->ID ) ); ?>
        </div>
    </a>
</div>
<?php
if ( ! empty( $topic_quizzes ) && $quizzes_settings['show_topic_quizzes'] !== false ) :
    foreach ( $topic_quizzes as $topic_quiz ) :
        ldfmp_get_template_part(
            'focus-mode/parts/sidebar-quiz.php',
            array(
                'quiz'      => $topic_quiz,
                'course_id' => $course_id,
                'user_id'   => $user_id,
                'context'   => 'lesson-topic'
            )
        );
    endforeach;
endif;

do_action( 'ldfmp_template_sidebar_after_course_lesson_topic', $lesson_topic, $topic_status, $is_current_topic, $course_id, $user_id );