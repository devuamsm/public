<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

$course_progress = ldfmp_learndash_get_course_progress( $course_id, $user_id );

if ( ! $course_progress ) {
    $course_progress = array( 
        'percentage'    => 0,
        'completed'     => 0,
        'total'         => 0
    );
}

do_action( 'ldfmp_template_before_sidebar', $course_id, $user_id );
?>
<div class="ldfmp-sidebar">
    <div class="ldfmp-sidebar-inner">
        <div class="ldfmp-sidebar-header">
            <?php
            do_action( 'ldfmp_template_sidebar_before_course', $course_id, $user_id );
            ?>
            <div class="ldfmp-sidebar-course">
                <a href="<?php echo esc_url( get_the_permalink( $course_id ) ); ?>" class="ldfmp-sidebar-course-link">
                    <h2 class="ldfmp-sidebar-course-title">
                        <?php echo esc_html( get_the_title( $course_id ) ); ?>
                    </h2>
                </a>
            </div>
            <?php
            do_action( 'ldfmp_template_sidebar_after_course', $course_id, $user_id );
            ?>
            <span class="ldfmp-sidebar-toggle-button"></span>
        </div>
        <div class="ldfmp-sidebar-body">
            <?php
            ldfmp_get_template_part( 'focus-mode/parts/sidebar-lessons.php', array( 
                'course_id'     => $course_id,
                'user_id'       => $user_id
            ) );
            ?>
        </div>
        <?php 
        if ( ldfmp_display_course_progress() ) :
        ?>
            <div class="ldfmp-sidebar-footer">
                <?php
                do_action( 'ldfmp_template_sidebar_before_course_progress', $course_id, $user_id );
                ?>
                <div class="ldfmp-course-progress">
                    <div class="ldfmp-course-progress-info">
                        <div class="ldfmp-course-progress-status"><?php printf( __( '%s%% complete', 'learndash-focus-mode-pro' ), $course_progress['percentage'] ); ?></div>
                        <div class="ldfmp-course-progress-total">
                            <?php
                            if ( ! is_rtl() ) :
                                printf( '%s/%s', $course_progress['completed'], $course_progress['total'] );
                            else:
                                printf( '%s\%s', $course_progress['completed'], $course_progress['total'] );
                            endif;
                            ?>
                        </div>
                    </div>
                    <div class="ldfmp-course-progress-bar">
                        <div class="ldfmp-course-progress-line" style="width: <?php echo esc_attr( $course_progress['percentage'] ); ?>%;"></div>
                    </div>
                </div>
                <?php
                do_action( 'ldfmp_template_sidebar_after_course_progress', $course_id, $user_id );
                ?>
            </div>
        <?php 
        endif;
        ?>
    </div>
</div>
<?php 
do_action( 'ldfmp_template_after_sidebar', $course_id, $user_id );