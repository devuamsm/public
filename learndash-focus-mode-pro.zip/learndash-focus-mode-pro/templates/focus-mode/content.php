<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

$header_buttons = array( 'sidebar_toggle', 'feedback_button' );

if ( ( ! is_rtl() && ldfmp_get_sidebar_position() == 'right' ) || ( is_rtl() && ldfmp_get_sidebar_position() == 'left' ) ) {
    $header_buttons = array_reverse( $header_buttons );
}

$nav_post_links = array(
    array(
        'type'  => 'previous',
        'link'  => ''
    ),
    array(
        'type'  => 'next',
        'link'  => ''
    )
);

if ( get_post_type() == ldfmp_learndash_get_post_types( 'lesson' ) || get_post_type() == ldfmp_learndash_get_post_types( 'topic' ) ) {
    $next_step_id       = ldfmp_learndash_get_next_post_link( null, 'id', get_post() );
    $previous_step_id   = ldfmp_learndash_get_previous_post_link( null, 'id', get_post() );

    if ( $previous_step_id ) {
        $previous_step_permalink    = ldfmp_learndash_get_step_permalink( $previous_step_id, $course_id );
        $previous_post_link_title   = get_post_type() == ldfmp_learndash_get_post_types( 'lesson' ) ? __( 'Previous lesson', 'learndash-focus-mode-pro' ) : __( 'Previous topic', 'learndash-focus-mode-pro' );

        if ( ! is_rtl() ) {
            $previous_post_link_title = '&larr; ' . $previous_post_link_title;
        } else {
            $previous_post_link_title = $previous_post_link_title  . ' &larr;';
        }

        $nav_post_links[0]['link'] = sprintf( '<a href="%s" class="ldfmp-content-post-link">%s</a>', esc_url( $previous_step_permalink ), $previous_post_link_title );
    }

    if ( $next_step_id ) {
        $next_step_permalink    = ldfmp_learndash_get_step_permalink( $next_step_id, $course_id );
        $next_post_link_title   = get_post_type() == ldfmp_learndash_get_post_types( 'lesson' ) ? __( 'Next lesson', 'learndash-focus-mode-pro' ) : __( 'Next topic', 'learndash-focus-mode-pro' );

        if ( ! is_rtl() ) {
            $next_post_link_title = $next_post_link_title . ' &rarr;';
        } else {
            $next_post_link_title = '&rarr; ' . $next_post_link_title;
        }

        $nav_post_links[1]['link'] = sprintf( '<a href="%s" class="ldfmp-content-post-link">%s</a>', esc_url( $next_step_permalink ), $next_post_link_title );
    }

    if ( is_rtl() ) {
        $nav_post_links = array_reverse( $nav_post_links );
    }
}

$tab_title = '';

if ( get_post_type() == ldfmp_learndash_get_post_types( 'lesson' ) ) {
    $tab_title = __( 'Lesson', 'learndash-focus-mode-pro' );
} elseif ( get_post_type() == ldfmp_learndash_get_post_types( 'topic' ) ) {
    $tab_title = __( 'Topic', 'learndash-focus-mode-pro' );
} elseif ( get_post_type() == ldfmp_learndash_get_post_types( 'quiz' ) ) {
    $tab_title = __( 'Quiz', 'learndash-focus-mode-pro' );
}

$tabs = array(
    array(
        'id'        => 'content',
        'title'     => $tab_title,
        'content'   => apply_filters( 'the_content', get_the_content() )
    )
);

$materials = '';

if ( in_array( get_post_type(), array( ldfmp_learndash_get_post_types( 'lesson' ), ldfmp_learndash_get_post_types( 'topic' ) ) ) ) {
    $setting = ldfmp_learndash_get_setting( get_the_id() );

    if ( get_post_type() == ldfmp_learndash_get_post_types( 'lesson' ) ) {
        if ( isset( $setting['lesson_materials_enabled'] ) && $setting['lesson_materials_enabled'] == 'on' && ! empty( $setting['lesson_materials'] ) ) {
            $materials = $setting['lesson_materials'];
        }
    } elseif ( get_post_type() == ldfmp_learndash_get_post_types( 'topic' ) ) {
        if ( isset( $setting['topic_materials_enabled'] ) && $setting['topic_materials_enabled'] == 'on' && ! empty( $setting['topic_materials'] ) ) {
            $materials = $setting['topic_materials'];
        }
    }
}

if ( $materials ) {
    $tabs[] = array(
        'id'        => 'materials',
        'title'     => __( 'Materials', 'learndash-focus-mode-pro' ),
        'content'   => apply_filters( 'the_content', $materials )
    );
}
?>

<div class="ldfmp-content">
    <div class="ldfmp-content-inner">
        <div class="ldfmp-content-header">
            <?php 
            do_action( 'ldfmp_template_before_content_header_buttons', $course_id, $user_id );
            ?>
            <div class="ldfmp-content-header-buttons">
                <?php
                foreach( $header_buttons as $header_button ) :
                    if ( $header_button == 'feedback_button' ) :
                        if ( ! ldfmp_display_feedback_button() ) :
                            continue;
                        endif;
                        ?>
                        <div class="ldfmp-content-header-button">
                            <span class="ldfmp-feedback-button"><?php _e( 'Send feedback', 'learndash-focus-mode-pro' ); ?></span>
                        </div>
                    <?php
                    endif;
                    if ( $header_button == 'sidebar_toggle' ) :
                    ?>
                        <div class="ldfmp-content-header-button">
                            <span class="ldfmp-sidebar-toggle-button"></span>
                        </div>
                    <?php
                    endif;
                endforeach;
                ?>
            </div>
            <?php 
            do_action( 'ldfmp_template_after_content_header_buttons', $course_id, $user_id );

            if ( $nav_post_links ) :
                do_action( 'ldfmp_template_before_content_post_links', $course_id, $user_id ); ?>
                <div class="ldfmp-content-post-links">
                    <?php
                    foreach( $nav_post_links as $nav_post_link ) :
                    ?>
                        <div class="ldfmp-content-post-link-<?php echo esc_attr( $nav_post_link['type'] ); ?>">
                            <?php echo $nav_post_link['link']; ?>
                        </div>
                    <?php
                    endforeach;
                    ?>
                </div>
                <?php
                do_action( 'ldfmp_template_after_content_post_links', $course_id, $user_id );
            endif;

            do_action( 'ldfmp_template_before_content_title', $course_id, $user_id );
            ?>
            <h2 class="ldfmp-content-title"><?php the_title(); ?></h2>
            <?php
            do_action( 'ldfmp_template_after_content_title', $course_id, $user_id );
            ?>
        </div>
        <div class="ldfmp-content-body">
            <?php
            do_action( 'ldfmp_template_before_content', $course_id, $user_id );

            the_content();

            do_action( 'ldfmp_template_after_content', $course_id, $user_id );
            ?>
        </div>
    </div>
</div>