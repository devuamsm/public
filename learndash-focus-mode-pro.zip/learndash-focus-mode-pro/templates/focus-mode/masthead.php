<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit; 

$header_logo        = ldfmp_learndash_get_header_logo( $course_id, $user_id );
$header_user        = ldfmp_learndash_get_header_user( $user_id );
$header_user_menu   = ldfmp_learndash_get_header_user_menu( $course_id, $user_id );

do_action( 'ldfmp_template_before_masthead', $course_id, $user_id );
?>

<header class="ldfmp-header">
    <?php if ( ldfmp_display_header_logo() ) :
        do_action( 'ldfmp_template_before_header_logo', $course_id, $user_id );
        ?>
        <div class="ldfmp-header-logo">
            <?php if ( isset( $header_logo['image'] ) ) : ?>
                <a href="<?php echo esc_url( $header_logo['image']['url'] ); ?>" class="ldfmp-header-logo-image">
                    <img src="<?php echo esc_url( $header_logo['image']['src'] ); ?>" alt="<?php echo esc_url( $header_logo['image']['alt'] ); ?>">
                </a>
            <?php else : ?>
                <a href="<?php echo esc_url( $header_logo['text']['url'] ); ?>" class="ldfmp-header-logo-text"><?php echo $header_logo['text']['title']; ?></a>
            <?php endif; ?>
        </div>
        <?php
        do_action( 'ldfmp_template_after_header_logo', $course_id, $user_id );
    endif;
    ?>
    <div class="ldfmp-header-section">
        <div class="ldfmp-header-controls<?php echo ! $header_user ? ' ldfmp-header-controls-no-user' : ''; ?>">
            <span class="ldfmp-controls">
                <span class="ldfmp-control-button ldfmp-control-button-theme"></span>
            </span>
            <?php if ( ! wp_is_mobile() ) : ?>
                <span class="ldfmp-controls">
                    <span class="ldfmp-control-button ldfmp-control-button-fullscreen"></span>
                </span>
            <?php endif; ?>
        </div>
        <?php
        if ( $header_user ) :
        ?>
            <div class="ldfmp-header-user">
                <a href="#" class="ldfmp-user-link">
                    <div class="ldfmp-user-name"><?php echo $header_user['name']; ?></div>
                    <div class="ldfmp-user-arrow"></div>
                    <div class="ldfmp-user-avatar"><?php echo $header_user['avatar']; ?></div>
                </a>
                <div class="ldfmp-user-menu">
                    <nav class="ldfmp-user-menu-nav">
                        <?php foreach( $header_user_menu as $header_user_menu_item ) : ?>
                            <a href="<?php echo esc_url( $header_user_menu_item['url'] ); ?>"
                                class="ldfmp-user-menu-link<?php echo ! empty( $header_user_menu_item['classes'] ) ? ' ' . esc_attr( $header_user_menu_item['classes'] ) : ''; ?>"
                                <?php if ( ! empty( $header_user_menu_item['target'] ) ) : ?>
                                    target="<?php echo esc_attr( $header_user_menu_item['target'] ); ?>"
                                <?php elseif ( ! empty( $header_user_menu_item['xfn'] ) ) : ?>
                                    rel="<?php echo esc_attr( $header_user_menu_item['xfn'] ); ?>"
                                <?php elseif ( ! empty( $header_user_menu_item['attr_title'] ) ) : ?>
                                    title="<?php echo esc_attr( $header_user_menu_item['attr_title'] ); ?>"
                                <?php endif; ?>
                            ><?php echo apply_filters( 'the_title', $header_user_menu_item['label'], 0 ); ?></a>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>
        <?php
        endif; 
        ?>
    </div>
</header>
<?php
do_action( 'ldfmp_template_after_masthead', $course_id, $user_id );