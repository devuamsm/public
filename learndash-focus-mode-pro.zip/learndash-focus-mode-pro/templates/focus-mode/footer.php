<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;
?>

        <?php wp_footer(); ?>
    </body>
</html>