<div id="ldfmp-feedback-button-modal" class="ldfmp-feedback-button-modal">
    <div class="ldfmp-feedback-button-modal-box ldfmp-feedback-button-modal-box-vcenter">
        <div class="ldfmp-feedback-button-modal-box-inner">
            <div class="ldfmp-feedback-button-modal-box-header">
                <span class="ldfmp-feedback-button-modal-box-close">&times;</span>
            </div>
            <div class="ldfmp-feedback-button-modal-box-content"><?php echo $template; ?></div>
        </div>
    </div>
</div>