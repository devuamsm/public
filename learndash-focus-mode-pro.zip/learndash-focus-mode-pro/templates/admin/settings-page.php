<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit; ?>

<div class="wrap ldfmp">
    <h2 class="ldfmp-notice-hook"></h2>
    <div class="ldfmp-notices">
        <?php 
            if ( $notice_manager->error->has_notices() ) {
                echo $notice_manager->error->get_all_html();
            } else {
                echo $notice_manager->success->get_all_html(); 
            }
        ?>
    </div>
    <div class="ldfmp-settings">
        <form class="ldfmp-settings__form ldfmp-form" method="post">
            <div class="ldfmp-form__header">
                <div class="ldfmp-form__header-column ldfmp-form__header-column--logo">
                    <img src="<?php echo LDFMP_URL_ASSETS_IMAGES . '/admin/logo.svg';  ?>" alt="">
                </div>
                <div class="ldfmp-form__header-column ldfmp-form__header-column--content">
                    <div class="ldfmp-form__header-plugin">
                        <div class="ldfmp-plugin-info">
                            <?php echo $plugin['name']; ?> <small>v<?php echo $plugin['version']; ?></small>
                        </div>
                    </div>
                    <div class="ldfmp-form__header-save">
                        <button class="ldfmp-button" type="submit" name="ldfmp_submit_form" value="<?php echo esc_attr( $form_actions['save_settings'] ); ?>"><?php _e( 'Save Settings', 'learndash-focus-mode-pro' ); ?></button>
                    </div>
                </div>
            </div>
            <div class="ldfmp-form__body">
                <div class="ldfmp-form__sidebar">
                    <ul class="ldfmp-tabs">
                        <?php foreach( $tabs as $tab_key => $tab ): ?>
                            <li class="ldfmp-tabs__tab ldfmp-tab<?php echo $tab['id'] == $tab_active ? ' ldfmp-tab--active' : ''; ?>" data-tab-id="<?php echo $tab['id']; ?>">
                                <a class="ldfmp-tab__link" href="<?php echo $tab_key != 0 ? esc_url( add_query_arg( 'tab', $tab['id'], $page_url ) ) : esc_url( $page_url ); ?>">
                                    <span class="ldfmp-tab__icon material-icons"><?php echo $tab['icon']; ?></span>
                                    <span class="ldfmp-tab__title"><?php echo $tab['title']; ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="ldfmp-form__main">
                    <div class="ldfmp-form__content">
                        <?php foreach ( $tabs as $tab_key => $tab ) : ?>
                            <div id="<?php echo $tab['id']; ?>" class="ldfmp-tab-content<?php echo $tab['id'] != $tab_active ? ' hide-if-js' : ''; ?>" data-tab-content-id="<?php echo $tab['id']; ?>">
                                <h2 class="ldfmp-tab-content__title"><?php echo $tab['title']; ?></h2>
                                <div class="ldfmp-tab-content__content">
                                    <?php if ( $tab['id'] == 'general' ) : ?>
                                        <div class="ldfmp-tab-content__setting ldfmp-setting">
                                            <div class="ldfmp-setting__title"><?php _e( 'Header logo', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__description"><?php _e( 'Show or hide logotype in the header of Focus mode.', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__content">
                                                <span class="ldfmp-setting-control">
                                                    <span class="ldfmp-setting-control__container">
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_header_logo]" value="true" <?php checked( $options->get( 'display_header_logo' ), true ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--green"><?php _ex( 'On', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_header_logo]" value="false" <?php checked( $options->get( 'display_header_logo' ), false ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--red"><?php _ex( 'Off', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="ldfmp-tab-content__setting ldfmp-setting">
                                            <div class="ldfmp-setting__title"><?php _e( 'Course progress bar', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__description"><?php _e( 'Show or hide course progress bar from the Focus Mode.', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__content">
                                                <span class="ldfmp-setting-control">
                                                    <span class="ldfmp-setting-control__container">
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_course_progress]" value="true" <?php checked( $options->get( 'display_course_progress' ), true ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--green"><?php _ex( 'On', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_course_progress]" value="false" <?php checked( $options->get( 'display_course_progress' ), false ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--red"><?php _ex( 'Off', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="ldfmp-tab-content__setting ldfmp-setting">
                                            <div class="ldfmp-setting__title"><?php _e( 'Instructor’s info', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__description"><?php _e( 'Show or hide instructor’s info from the Focus Mode.', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__content">
                                                <?php 
                                                    $plugin_description = $required_plugins->LearnDash_Instructors->get_setting_description();

                                                    if ( $plugin_description ) {
                                                        printf( '<p class="ldfmp-setting__plugin-description"><span>%s - </span>%s</p>', __( 'You need', 'learndash-focus-mode-pro' ), $plugin_description );
                                                    }
                                                ?>
                                                <span class="ldfmp-setting-control<?php echo ! ( $required_plugins->LearnDash_Instructors->is_installed() && $required_plugins->LearnDash_Instructors->is_activated() ) ? ' ldfmp-setting-control--disabled' : ''; ?>">
                                                    <span class="ldfmp-setting-control__container">
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_course_instructors]" value="true" <?php checked( $required_plugins->LearnDash_Instructors->is_activated() && $options->get( 'display_course_instructors' ), true ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--green"><?php _ex( 'On', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_course_instructors]" value="false" <?php checked( $required_plugins->LearnDash_Instructors->is_activated() && $options->get( 'display_course_instructors' ), false ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--red"><?php _ex( 'Off', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="ldfmp-tab-content__setting ldfmp-setting">
                                            <div class="ldfmp-setting__title"><?php _e( 'Feedback button', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__description"><?php _e( 'Show or hide feedback button from the Focus Mode.', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__content">
                                                <?php 
                                                    $plugin_description = $required_plugins->LearnDash_Feedback->get_setting_description();

                                                    if ( $plugin_description ) {
                                                        printf( '<p class="ldfmp-setting__plugin-description"><span>%s - </span>%s</p>', __( 'You need', 'learndash-focus-mode-pro' ), $plugin_description );
                                                    }
                                                ?>
                                                <span class="ldfmp-setting-control<?php echo ! ( $required_plugins->LearnDash_Feedback->is_installed() && $required_plugins->LearnDash_Feedback->is_activated() ) ? ' ldfmp-setting-control--disabled' : ''; ?>">
                                                    <span class="ldfmp-setting-control__container">
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_feedback_button]" value="true" <?php checked( $required_plugins->LearnDash_Feedback->is_activated() && $options->get( 'display_feedback_button' ), true ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--green"><?php _ex( 'On', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[display_feedback_button]" value="false" <?php checked( $required_plugins->LearnDash_Feedback->is_activated() && $options->get( 'display_feedback_button' ), false ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--red"><?php _ex( 'Off', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="ldfmp-tab-content__setting ldfmp-setting">
                                            <div class="ldfmp-setting__title"><?php _e( 'Sidebar position', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__description"><?php _e( 'Select a side for showing a list of lessons/topics/quizzes assigned to the course.', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__content">
                                                <span class="ldfmp-setting-control">
                                                    <span class="ldfmp-setting-control__container">
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[sidebar_position]" value="left" <?php checked( $options->get( 'sidebar_position' ), 'left' ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--green"><?php _ex( 'Left', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                        <label class="ldfmp-setting-control__option">
                                                            <input class="ldfmp-setting-control__input" type="radio" name="ldfmp_settings[sidebar_position]" value="right" <?php checked( $options->get( 'sidebar_position' ), 'right' ); ?>>
                                                            <span class="ldfmp-setting-control__placeholder ldfmp-setting-control__placeholder--green"><?php _ex( 'Right', 'Option value', 'learndash-focus-mode-pro' ); ?></span>
                                                        </label>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    <?php elseif ( $tab['id'] == 'license-key' ) : ?>
                                        <div class="ldfmp-tab-content__setting ldfmp-setting">
                                            <div class="ldfmp-setting__title"><?php _e( 'LearnDash Focus Mode Pro activation form', 'learndash-focus-mode-pro' ); ?></div>
                                            <div class="ldfmp-setting__description"><?php printf( __( 'You can find the license key for LearnDash Focus Mode Pro add-on in %s page.', 'learndash-focus-mode-pro' ), sprintf( '<a href="https://wooninjas.com/my-account/" class="ldfmp-link" target="_blank">%s</a>', __( 'My account', 'learndash-focus-mode-pro' ) ) ); ?></div>
                                            <div class="ldfmp-setting__content">
                                                <div class="ldfmp-license-form">
                                                    <div class="ldfmp-license-form__status"><?php _e( 'Status', 'learndash-focus-mode-pro' ); ?>: <span class="ldfmp-color-<?php echo $plugin['activated'] ? 'green' : 'red'; ?>"><?php echo $plugin['activated'] ? __( 'Active', 'learndash-focus-mode-pro' ) : __( 'Inactive', 'learndash-focus-mode-pro' ); ?></span></div>
                                                    <div class="ldfmp-license-form__input<?php echo $plugin['activated'] ? ' ldfmp-hidden' : ''; ?>">
                                                        <input class="ldfmp-input" type="text" name="ldfmp_license[license_key]" value="<?php echo esc_attr( $options->get( 'license_key' ) ); ?>" placeholder="<?php _e( 'Enter your license key here', 'learndash-focus-mode-pro' ); ?>">
                                                    </div>
                                                    <div class="ldfmp-license-form__button">
                                                        <?php if ( ! $plugin['activated'] ) : ?>
                                                            <button class="ldfmp-button ldfmp-button--green" type="submit" name="ldfmp_submit_form" value="<?php echo esc_attr( $form_actions['activate_license_key'] ); ?>"><?php _e( 'Activate License', 'learndash-focus-mode-pro' ); ?></button>
                                                        <?php else : ?>
                                                            <button class="ldfmp-button ldfmp-button--green" type="submit" name="ldfmp_submit_form" value="<?php echo esc_attr( $form_actions['check_license_key'] ); ?>"><?php _e( 'Check License', 'learndash-focus-mode-pro' ); ?></button>
                                                            <button class="ldfmp-button ldfmp-button--red" type="submit" name="ldfmp_submit_form" value="<?php echo esc_attr( $form_actions['deactivate_license_key'] ); ?>"><?php _e( 'Deactivate License', 'learndash-focus-mode-pro' ); ?></button>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="ldfmp-form__save">
                        <button class="ldfmp-button" type="submit" name="ldfmp_submit_form" value="<?php echo esc_attr( $form_actions['save_settings'] ); ?>"><?php _e( 'Save Settings', 'learndash-focus-mode-pro' ); ?></button>
                    </div>
                </div>
            </div>
            <?php echo $nonce_field; ?>
        </form>
        <div class="ldfmp-settings__sidebar ldfmp-sidebar">
            <div class="ldfmp-metabox">
                <div class="ldfmp-metabox__header">
                    <div class="ldfmp-metabox__title"><?php _e( 'Quick Links', 'learndash-focus-mode-pro' ); ?></div>
                </div>
                <div class="ldfmp-metabox__body">
                    <div class="ldfmp-metabox__content">
                        <div class="ldfmp-metabox__section ldfmp-metabox-section">
                            <div class="ldfmp-metabox-section__title"><?php _e( 'Download required plugins', 'learndash-focus-mode-pro' ); ?>:</div>
                            <ul class="ldfmp-metabox-section__list ldfmp-metabox-list">
                                <li class="ldfmp-metabox-list__item">
                                    <a href="https://wooninjas.com/downloads/learndash-instructors-tab/" class="ldfmp-metabox-list__link ldfmp-link" target="_blank"><?php echo $required_plugins->LearnDash_Instructors->get_name(); ?></a> - <span class="ldfmp-color-grey"><?php _e( 'free', 'learndash-focus-mode-pro' ); ?></span>
                                </li>
                                <li class="ldfmp-metabox-list__item">
                                    <a href="https://wooninjas.com/downloads/learndash-feedback/" class="ldfmp-metabox-list__link ldfmp-link" target="_blank"><?php echo $required_plugins->LearnDash_Feedback->get_name(); ?></a> - <span class="ldfmp-color-grey"><?php _e( 'free', 'learndash-focus-mode-pro' ); ?></span>
                                </li>
                            </ul>
                        </div>
                        <div class="ldfmp-metabox__section ldfmp-metabox-section">
                            <div class="ldfmp-metabox-section__title"><?php echo $plugin['name']; ?>:</div>
                            <ul class="ldfmp-metabox-section__list ldfmp-metabox-list">
                                <li class="ldfmp-metabox-list__item">
                                    <a href="https://docs.wooninjas.com/article/240-learndash-focus-mode-pro-overview" class="ldfmp-metabox-list__link ldfmp-link" target="_blank"><?php _e( 'View Documentation', 'learndash-focus-mode-pro' ); ?></a>
                                </li>
                                <li class="ldfmp-metabox-list__item">
                                    <a href="https://docs.wooninjas.com/category/239-learndash-focus-mode-pro" class="ldfmp-metabox-list__link ldfmp-link" target="_blank"><?php _e( 'Changelogs', 'learndash-focus-mode-pro' ); ?></a>
                                </li>
                                <li class="ldfmp-metabox-list__item">
                                    <a href="https://docs.wooninjas.com/article/241-learndash-focus-mode-pro-faqs" class="ldfmp-metabox-list__link ldfmp-link" target="_blank"><?php _e( 'Click here to see FAQs', 'learndash-focus-mode-pro' ); ?></a>
                                </li>
                            </ul>
                        </div>
                        <div class="ldfmp-metabox__section ldfmp-metabox-section">
                            <a href="https://wooninjas.com/open-support-ticket/" class="ldfmp-button" target="_blank"><?php _e( 'Open a Support Ticket', 'learndash-focus-mode-pro' ); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>