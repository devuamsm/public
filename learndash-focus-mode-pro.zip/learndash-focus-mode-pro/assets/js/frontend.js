jQuery( function( $ ) {
    $( document ).ready( function() {
        $( document ).on( 'ldfmp.set_cookie', function( e, data ) {
            var date = new Date();

            if ( 'name' in data && 'value' in data && 'expires' in data ) {
                date.setTime( date.getTime() + ( data.expires * 24 * 60 * 60 * 1000 ) );
                document.cookie = data.name + "=" + data.value + "; expires=" + date.toUTCString() + "; path=/";
            }
        } );

        $( '.ldfmp-header-user' ).on( 'ldfmp.user_menu.init', function() {
            var $user       = $( this ),
                $user_link  = $user.find( '.ldfmp-user-link' ),
                $user_menu  = $user.find( '.ldfmp-user-menu' );

            $user_link.on( 'click', function( e ) {
                e.preventDefault();

                $user_menu.toggleClass( 'ldfmp-user-menu-expanded', ! $user_menu.is( '.ldfmp-user-menu-expanded' ) );
            } );

            $( document ).on( 'click', function( e ) {
                if ( ! $( e.target ).closest( $user_link ).length ) {
                    $user_menu.removeClass( 'ldfmp-user-menu-expanded' );
                }
            } );
        } ).trigger( 'ldfmp.user_menu.init' );

        $( '.ldfmp-header-controls' ).on( 'ldfmp.controls.init', function() {
            var $controls = $( this ),
                $button_theme           = $controls.find( '.ldfmp-control-button-theme' ),
                $button_fullscreen      = $controls.find( '.ldfmp-control-button-fullscreen' );

            $button_theme.on( 'click', function() {
                var theme = ! $( 'body' ).is( '.ldfmp-focus-mode-theme-dark' ) ? 'dark' : 'light';

                $( 'body' )
                    .removeClass( 'ldfmp-focus-mode-theme-light ldfmp-focus-mode-theme-dark' )
                    .addClass( 'ldfmp-focus-mode-theme-' + theme );

                $( document ).trigger( 'ldfmp.set_cookie', { name: 'ldfmp_theme', value: theme, expires: 365 } );
            } );

            $button_fullscreen.on( 'click', function() {
                var documentElement = document.documentElement,
                    enterFullscreen = documentElement.requestFullscreen || documentElement.webkitRequestFullscreen || documentElement.mozRequestFullscreen || documentElement.msRequestFullscreen,
                    exitFullscreen  = document.exitFullscreen || document.webkitExitFullscreen || document.webkitCancelFullScreen || document.mozCancelFullScreen || document.mozExitFullscreen || document.msExitFullscreen;

                if ( ! document.fullscreenElement ) {
                    if ( enterFullscreen ) {
                        enterFullscreen.call( documentElement );
                    }
                } else {
                    if ( exitFullscreen ) {
                        exitFullscreen.call( document );
                    }
                }
            } );

            var fullscreenDetect = function() {
                $( 'body' ).toggleClass( 'ldfmp-focus-mode-fullscreen', document.fullscreenElement );
            }

            $( document )
                .on( 'fullscreenchange', fullscreenDetect )
                .on( 'webkitfullscreenchange', fullscreenDetect )
                .on( 'mozfullscreenchange', fullscreenDetect )
                .on( 'msfullscreenchange', fullscreenDetect );

        } ).trigger( 'ldfmp.controls.init' );
    } );

    $( '.ldfmp-sidebar' ).on( 'ldfmp.sidebar.init', function() {
        var $sidebar            = $( this ),
            $toggle_buttons     = $( '.ldfmp-sidebar-toggle-button' ),
            $body               = $( 'body' ),
            $window             = $( window ),
            breakpoint          = 962,
            is_mobile           = $window.width() <= breakpoint;

        $toggle_buttons.on( 'click', function() {
            var toggle_class = is_mobile ? 'ldfmp-focus-mode-sidebar-device-visible' : 'ldfmp-focus-mode-sidebar-desktop-hidden';

            $body.toggleClass( toggle_class, ! $body.is( '.' + toggle_class ) );

            if ( ! is_mobile ) {
                var new_status = $body.is( '.ldfmp-focus-mode-sidebar-desktop-hidden' ) ? 'hidden' : 'visible';

                $( document ).trigger( 'ldfmp.set_cookie', { name: 'ldfmp_sidebar', value: new_status, expires: 365 } );

                $window.trigger( 'ldfmp.sidebar.visibility' );
            }
        } );

        $window.on( 'ldfmp.sidebar.visibility resize', function() {
            is_mobile = $window.width() <= breakpoint;

            if ( ! is_mobile ) {
                $body.removeClass( 'ldfmp-focus-mode-sidebar-device-visible' );
            }
        } ).trigger( 'ldfmp.sidebar.visibility' );
    } ).trigger( 'ldfmp.sidebar.init' );

    $( '.ldfmp-sidebar-course-lessons' ).on( 'ldfmp.sidebar_course_lessons.init', function() {
        var $sidebar_lessons = $( this );

        $sidebar_lessons.on( 'click', '.ldfmp-sidebar-course-lesson-toggle-button', function( e ) {
            e.preventDefault();
            e.stopPropagation();

            var $lesson = $( this ).closest( '.ldfmp-sidebar-course-lesson' );

            if ( $lesson.is( '.ldfmp-sidebar-course-lesson-expandable' ) ) {
                $lesson.toggleClass( 'ldfmp-sidebar-course-lesson-expanded', ! $lesson.is( '.ldfmp-sidebar-course-lesson-expanded' ) );
            }
        } );
    } ).trigger( 'ldfmp.sidebar_course_lessons.init' );

    $( '.ldfmp-feedback-button' ).on( 'ldfmp.feedback_button_modal.init', function() {
        var $button         = $( this ),
            $modal          = $( '#ldfmp-feedback-button-modal' ),
            $modal_box      = $modal.find( '.ldfmp-feedback-button-modal-box' ),
            $modal_close    = $modal_box.find( '.ldfmp-feedback-button-modal-box-close' ),
            $window         = $( window );

            $modal
                .on( 'ldfmp.feedback_button_modal.reset', function() {
                    var $master             = $modal_box.find( '.master' ),
                        $button_box         = $master.find( '.button-box' ),
                        $submitted_box      = $master.find( '.submited-box' ),
                        $status_msg         = $master.find( '.status-msg' ),
                        $rating_component   = $master.find( '.rating-component' ),
                        $star               = $master.find( '.star' ),
                        $gr_rating_value    = $master.find( '#gr_rating_value' ),
                        $feedback_tags      = $master.find( '.feedback-tags' ),
                        $tags_container     = $master.find( '.tags-container' ),
                        $textarea           = $master.find( 'textarea' ),
                        $submit             = $master.find( 'input[type="submit"]' );

                    $button_box.removeAttr( 'style' );
                    $submitted_box.removeAttr( 'style' );
                    $status_msg.html( '' );
                    $rating_component.removeAttr( 'style' );
                    $star.removeClass( 'selected' );
                    $gr_rating_value.val( '' );
                    $feedback_tags
                        .removeClass( 'choosed' )
                        .removeAttr( 'style' );
                    $tags_container.hide();
                    $textarea.val( '' );
                    $submit
                        .attr( 'disabled', true )
                        .removeAttr( 'style' );
                } )
                .on( 'ldfmp.feedback_button_modal.show', function() {
                    $( 'body' ).addClass( 'ldfmp-focus-mode-modal-visible' );

                    $modal.addClass( 'ldfmp-feedback-button-modal-visible' );

                    setTimeout( function() {
                        $window.trigger( 'ldfmp.feedback_button_modal.resize' );
                    }, 1 );
                } )
                .on( 'ldfmp.feedback_button_modal.hide', function() {
                    $( 'body' ).removeClass( 'ldfmp-focus-mode-modal-visible' );

                    $modal
                        .removeClass( 'ldfmp-feedback-button-modal-visible' )
                        .trigger( 'ldfmp.feedback_button_modal.reset' );
                } );

        /* Fix */
        $modal_box.on( 'click', '.master .star, input[type="submit"]', function() {
            $modal.trigger( 'ldfmp.feedback_button_modal.resize' );
        } );

        $button.on( 'click', function() {
            $modal.trigger( 'ldfmp.feedback_button_modal.show' );
        } );

        $modal_close.on( 'click', function() {
            $modal.trigger( 'ldfmp.feedback_button_modal.hide' );
        } );

        $window.on( 'ldfmp.feedback_button_modal.resize resize', function() {
            var window_height       = $window.height(),
                modal_box_height    = $modal_box.outerHeight();

            $modal_box.toggleClass( 'ldfmp-feedback-button-modal-box-vcenter', window_height > modal_box_height );
        } ).trigger( 'ldfmp.feedback_button_modal.resize' );
    } ).trigger( 'ldfmp.feedback_button_modal.init' );

    $( '.ldfmp-content-tabs' ).on( 'ldfmp.content_tabs.init', function() {
        var $container   = $( this ),
            $tabs        = $container.find( '.ldfmp-content-tab' ),
            $contents    = $container.find( '.ldfmp-content-tab-content' );

        $tabs.on( 'click', function() {
            var $tab        = $( this ),
                tab_id      = $tab.data( 'tab-id' ),
                $content    = $contents.filter( '[data-tab-content-id="' +  tab_id + '"]' );

            $tabs.removeClass( 'ldfmp-content-tab-active' );
            $tab.addClass( 'ldfmp-content-tab-active' );
            $contents.removeClass( 'ldfmp-content-tab-content-active' );
            $content.addClass( 'ldfmp-content-tab-content-active' );
        } );
    } ).trigger( 'ldfmp.content_tabs.init' );
} );