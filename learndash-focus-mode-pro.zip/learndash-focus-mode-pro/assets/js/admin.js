jQuery( function( $ ) {
    $( document ).ready( function() {
        $( '.ldfmp-form' ).on( 'ldfmp.settings_form.init', function() {
            var $settings_form  = $( this ),
                $tabs           = $settings_form.find( '.ldfmp-tab' ),
                $tabs_content   = $settings_form.find( '.ldfmp-tab-content' );

            $tabs.each( function() {
                var $tab = $( this );

                $tab
                    .on( 'ldfmp.settings_form.show_tab', function( e, data ) {
                        $tabs
                            .removeClass( 'ldfmp-tab--active' )
                            .filter( '[data-tab-id="' + data.tab_id + '"]' )
                                .addClass( 'ldfmp-tab--active' );

                        $tabs_content
                            .addClass( 'hide-if-js' )
                            .filter( '[data-tab-content-id="' + data.tab_id + '"]' )
                                .removeClass( 'hide-if-js' );
                    } )
                    .on( 'click', 'a', function( e ) {
                        e.preventDefault();

                        var tab_id  = $( this ).parent().data( 'tab-id' ),
                            href    = $( this ).attr( 'href' );

                        $tab.trigger( 'ldfmp.settings_form.show_tab', { tab_id: tab_id } );

                        window.history.replaceState( {}, '', href );
                    } );
            } );
        } ).trigger( 'ldfmp.settings_form.init' );
    } );
} );