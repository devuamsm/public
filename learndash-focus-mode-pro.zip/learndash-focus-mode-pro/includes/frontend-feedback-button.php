<?php

namespace LDFMP;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Options;
use LDFMP\Classes\Required_Plugins;
use LDFMP\Classes\Template;

class Frontend_Feedback_Button {
    use \LDFMP\Traits\Singleton;

    /**
     * @var object Plugin options.
     */
    private $options;

    /**
     * @var object Required plugins.
     */
    private $required_plugins;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        $this->options              = Options::get_instance();
        $this->required_plugins     = Required_Plugins::get_instance();

        if ( $this->options->get( 'display_course_instructors' ) && $this->required_plugins->LearnDash_Feedback->is_activated() ) {
            add_action( 'wp_enqueue_scripts', array( $this, 'focus_mode_feedback_button_js_css' ) );
            add_action( 'wp_footer', array( $this, 'focus_mode_feedback_button_template' ) );
        }
    }

    /**
     * Enqueue feedback button assets.
     * 
     * @return void
     */
    public function focus_mode_feedback_button_js_css() {
        if ( $this->required_plugins->LearnDash->is_focus_mode() ) {
            $assets_css     = $this->required_plugins->LearnDash_Feedback->get_assets_css();
            $assets_js      = $this->required_plugins->LearnDash_Feedback->get_assets_js();

            foreach ( $assets_css as $css ) {
                wp_enqueue_style( $css['id'], $css['url'], $css['dependencies'], $css['version'] );
            }

            foreach ( $assets_js as $js ) {
                wp_enqueue_script( $js['id'], $js['url'], $js['dependencies'], $js['version'], $js['in_footer'] );

                if ( ! empty( $js['localize_script'] ) ) {
                    wp_localize_script( $js['id'], $js['localize_script']['name'], $js['localize_script']['data'] );
                }
            }
        }
    }

    /**
     * Render feedback button template.
     * 
     * @return void
     */
    public function focus_mode_feedback_button_template() {
        if ( $this->required_plugins->LearnDash->is_focus_mode() ) {
            $course_id  = $this->required_plugins->LearnDash->get_course_id();
            $template   = $this->required_plugins->LearnDash_Feedback->get_template( $course_id );

            if ( $template ) {
                Template::render( 'modal-feedback-button.php', array( 
                    'template' => $template
                ) );
            }
        }
    }
}