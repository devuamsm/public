<?php

namespace LDFMP\Required_Plugins;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Required_Plugin;
use LDFMP\Classes\Required_Plugins;

class LearnDash_Instructors extends Required_Plugin {
    use \LDFMP\Traits\Singleton;

    /**
     * Get plugin slug.
     *
     * @return string Plugin slug.
     */
    public function get_slug() {
        return 'learndash-course-instructor/learndash-course-instructor.php';
    }

    /**
     * Get plugin name.
     *
     * @return string Plugin name.
     */
    public function get_name() {
        return 'LearnDash Instructors Tab';
    }

    /**
     * Get plugin url.
     *
     * @return string Plugin url.
     */
    public function get_public_url() {
        return 'https://wooninjas.com/downloads/learndash-instructors-tab/';
    }

    /**
     * Get course instructors.
     *
     * @param int $course_id Course ID.
     * 
     * @return array Data of course instructors.
     */
    public function get_course_instructors( $course_id ) {
        $course_instructors = array();

        if ( $this->is_activated() ) {
            $course_settings = Required_Plugins::get_instance()->LearnDash->get_setting( $course_id );

            if ( 
                isset( $course_settings['ldcii_course_settings_enabled'] ) && 
                (bool) $course_settings['ldcii_course_settings_enabled'] &&
                ! empty( $course_settings['ldcii_select_instructors'] )
            ) {
                $course_instructor_ids = $course_settings['ldcii_select_instructors'];
                $course_instructor_ids = array_map( 'absint', $course_instructor_ids );

                foreach ( $course_instructor_ids as $course_instructor_id ) {
                    $user_data = get_userdata( $course_instructor_id );

                    $course_instructors[] = array(
                        'name'      => apply_filters( 'ldfmp_instructor_display_name', $user_data->display_name, $user_data, $course_id ),
                        'avatar'    => get_avatar( $course_instructor_id )
                    );
                }
            }
        }

        return $course_instructors;
    }
}