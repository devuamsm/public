<?php

namespace LDFMP\Required_Plugins;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Required_Plugin;

class LearnDash_Feedback extends Required_Plugin {
    use \LDFMP\Traits\Singleton;

    /**
     * Get plugin slug.
     *
     * @return string Plugin slug.
     */
    public function get_slug() {
        return 'learndash-feedback/learndash-feedback.php';
    }

    /**
     * Get plugin name.
     *
     * @return string Plugin name.
     */
    public function get_name() {
        return 'LearnDash Feedback';
    }

    /**
     * Get plugin url.
     *
     * @return string Plugin url.
     */
    public function get_public_url() {
        return 'https://wooninjas.com/downloads/learndash-feedback/';
    }

    /**
     * Get plugin styles.
     *
     * @return array Plugin styles.
     */
    public function get_assets_css() {
        return array(
            array(
                'id'            => 'font-awesome-free',
                'url'           => '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css',
                'dependencies'  => '',
                'version'       => ''
            ),
            array(
                'id'            => 'wn-learndash-feedback',
                'url'           => $this->get_url( 'public/css/wn-learndash-feedback-public.css' ),
                'dependencies'  => array(),
                'version'       => $this->get_data( 'Version' )
            )
        );
    }

    /**
     * Get plugin scripts.
     *
     * @return array Plugin scripts.
     */
    public function get_assets_js() {
        return array(
            array(
                'id'                => 'wn-learndash-feedback',
                'url'               => $this->get_url( 'public/js/wn-learndash-feedback-public.js' ),
                'dependencies'      => array( 'jquery' ),
                'version'           => $this->get_data( 'Version' ),
                'in_footer'         => true,
                'localize_script'   => array(
                    'name'  =>  'ajax_feedback',
                    'data'  => array(
                        'url'       => admin_url( 'admin-ajax.php' ),
                        'nonce'     => wp_create_nonce( 'ajax-nonce' )
                    )
                )
            )
        );
    }

    /**
     * Get pop-up template.
     *
     * @return string HTML of pop-up template.
     */
    public function get_template( $course_id ) {
        $template = '';

        if ( $this->is_activated() ) {
            $template_file = $this->get_path( 'public/partials/wn-learndash-feedback-public-display.php' );

            if ( file_exists( $template_file ) ) {
                ob_start();
                include $template_file;
                $template = ob_get_clean();
            }
        }

        return $template;
    }
}