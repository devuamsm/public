<?php

namespace LDFMP\Required_Plugins;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use \LDFMP\Classes\Required_Plugin;

class LearnDash extends Required_Plugin {
    use \LDFMP\Traits\Singleton;

    /**
     * Get plugin slug.
     *
     * @return string Plugin slug.
     */
    public function get_slug() {
        return 'sfwd-lms/sfwd_lms.php';
    }

    /**
     * Get plugin slug.
     *
     * @return string Plugin slug.
     */
    public function get_name() {
        return 'LearnDash LMS';
    }

    /**
     * Get plugin url.
     *
     * @return string Plugin url.
     */
    public function get_public_url() {
        return 'https://www.learndash.com';
    }

    /**
     * Get LearnDash post types.
     * 
     * @param string $type Post type.
     *
     * @return array LearnDash post types.
     */
    public function get_post_types( $type = '' ) {
        $post_types = array(
            'lesson'        => learndash_get_post_type_slug( 'lesson' ),
            'topic'         => learndash_get_post_type_slug( 'topic' ),
            'quiz'          => learndash_get_post_type_slug( 'quiz' )
        );

        if ( $type ) {
            return array_key_exists( $type, $post_types ) ? $post_types[ $type ] : '';
        }

        return $post_types;
    }

    /**
     * Get LearnDash setting.
     *
     * @param int $object_id Object ID.
     * @param string $setting Setting key.
     *
     * @return string|void Value for requested setting.
     */
    public function get_setting( $object_id, $setting = '' ) {
        return learndash_get_setting( $object_id, $setting );
    }

    /**
     * Get LearnDash section setting value.
     *
     * @param string $section setting section.
     * 
     * @return mixed setting section value.
     */
    public function get_settings_section( $section ) {
        return \LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Theme_LD30', $section );
    }

    /**
     * Get LearnDash status of focus mode.
     * 
     * @return boolean Status of focus mode.
     */
    public function is_focus_mode_enabled() {
        return (bool) $this->get_settings_section( 'focus_mode_enabled' );
    }

    /**
     * Check if a page is in focus mode.
     * 
     * @return boolean Status of focus mode.
     */
    public function is_focus_mode() {
        return $this->is_focus_mode_enabled() && in_array( get_post_type(), array_values( $this->get_post_types() ) );
    }

    /**
     * Get LearnDash header logo for focus mode.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Data of header logo.
     */
    public function get_header_logo( $course_id, $user_id ) {
        $header_logo    = array();
        $image_id       = $this->get_settings_section( 'login_logo' );

        if ( ! empty( $image_id ) ) {
            $header_logo['image']['id']     = (int) $image_id;
            $header_logo['image']['url']    = apply_filters( 'learndash_focus_header_logo_url', get_home_url(), $course_id, $user_id );
            $header_logo['image']['src']    = wp_get_attachment_image_url( $image_id, 'medium' );
            $header_logo['image']['alt']    = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
        } else {
            $header_logo['text']['title']   = apply_filters( 'learndash_focus_header_text', get_bloginfo( 'name' ), $course_id, $user_id );
            $header_logo['text']['url']     = apply_filters( 'learndash_focus_header_text_url', get_home_url(), $course_id, $user_id );
        }

        return $header_logo;
    }

    /**
     * Get LearnDash header user for focus mode.
     * 
     * @param int $user_id User ID.
     * 
     * @return array Data of header user.
     */
    public function get_header_user( $user_id ) {
        $header_user = false;

        if ( is_user_logged_in() ) {
            $user_data = get_userdata( $user_id );
            $header_user = array(
                'name'      => apply_filters( 'ld_focus_mode_welcome_name', $user_data->user_nicename, $user_data ),
                'avatar'    => get_avatar( $user_id )
            );
        }

        return $header_user;
    }

    /**
     * Get LearnDash header user menu for focus mode.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Data of header user menu.
     */
    public function get_header_user_menu( $course_id, $user_id ) {
        $custom_menu_items = learndash_30_get_custom_focus_menu_items();

        if ( $custom_menu_items ) {
            foreach ( $custom_menu_items as $menu_item ) {
                $menu_items[ $menu_item->post_name ] = array(
                    'url'        => $menu_item->url,
                    'label'      => $menu_item->title,
                    'classes'    => esc_attr( 'ld-focus-menu-link ld-focus-menu-' . $menu_item->post_name ),
                    'target'     => '',
                    'attr_title' => '',
                    'xfn'        => '',
                );

                if ( ( property_exists( $menu_item, 'classes' ) ) && ( is_array( $menu_item->classes ) ) ) {
                    $classes = array_filter( $menu_item->classes, 'strlen' );
                    if ( ! empty( $classes ) ) {
                        $menu_items[ $menu_item->post_name ]['classes'] .= ' ' . implode( ' ', $classes );
                    }
                }

                if ( ( property_exists( $menu_item, 'target' ) ) && ( ! empty( $menu_item->target ) ) ) {
                    $menu_items[ $menu_item->post_name ]['target'] = esc_attr( $menu_item->target );
                }

                if ( ( property_exists( $menu_item, 'attr_title' ) ) && ( ! empty( $menu_item->attr_title ) ) ) {
                    $menu_items[ $menu_item->post_name ]['attr_title'] = esc_attr( $menu_item->attr_title );
                }
                if ( ( property_exists( $menu_item, 'xfn' ) ) && ( ! empty( $menu_item->xfn ) ) ) {
                    $menu_items[ $menu_item->post_name ]['xfn'] = esc_attr( $menu_item->xfn );
                }
            }
        }

        $menu_items['logout'] = array(
            'url'   => wp_logout_url( get_the_permalink( $course_id ) ),
            'label' => __( 'Logout', 'learndash-focus-mode-pro' )
        );

        $menu_items = apply_filters( 'learndash_focus_header_user_dropdown_items', $menu_items, $course_id, $user_id );

        return $menu_items;
    }

    /**
     * Get LearnDash course id.
     * 
     * @return int Current course id.
     */
    public function get_course_id() {
        return learndash_get_course_id();
    }

    /**
     * Get LearnDash course sections.
     * 
     * @param int $course_id Course ID.
     * 
     * @return array Course sections.
     */
    public function get_course_sections( $course_id ) {
        return learndash_30_get_course_sections( $course_id );
    }

    /**
     * Get LearnDash course lessons.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Course lessons.
     */
    public function get_course_lessons( $course_id, $user_id ) {
        return learndash_get_course_lessons_list( $course_id, $user_id, array( 'num' => -1 ) );
    }

    /**
     * Get LearnDash lesson topics.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Lesson topics.
     */
    public function get_lesson_topics( $lesson_id, $course_id ) {
        return learndash_get_topic_list( $lesson_id, $course_id );
    }

    /**
     * Get LearnDash topic quizzes.
     * 
     * @param int $object_id Object ID.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Topic quizzes.
     */
    public function get_topic_quizzes( $object_id, $user_id, $course_id ) {
        return learndash_get_lesson_quiz_list( $object_id, $user_id, $course_id );
    }

    /**
     * Get LearnDash lesson quizzes.
     * 
     * @param int $object_id Object ID.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Lesson quizzes.
     */
    public function get_lesson_quizzes( $object_id, $user_id, $course_id ) {
        return learndash_get_lesson_quiz_list( $object_id, $user_id, $course_id );
    }

    /**
     * Get LearnDash course quizzes.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Course quizzes.
     */
    public function get_course_quizzes( $course_id, $user_id ) {
        return learndash_get_course_quiz_list( $course_id, $user_id );
    }

    /**
     * Get LearnDash single parent step ID for a given step ID in a course.
     *
     * @param int $course_id Course ID.
     * @param int $object_id Step ID.
     * @param string $step_type The type of the step.
     *
     * @return int The parent step ID.
     */
    public function get_course_single_parent_step( $course_id = 0, $object_id = 0, $step_type = '' ) {
        return learndash_course_get_single_parent_step( $course_id, $object_id, $step_type );
    }

    /**
     * Get LearnDash nested permalink of the course step within in the course.
     *
     * @param int $object_id Course Step Post ID.
     * @param int $course_id Course ID.
     *
     * @return string Step permalink.
     */
    public function get_step_permalink( $object_id, $course_id ) {
        return learndash_get_step_permalink( $object_id, $course_id );
    }

    /**
     * Get LearnDash next post link for lesson or topic.
     *
     * @param  string $prevlink Default next post link.
     * @param  boolean $url Whether to return URL instead of HTML output.
     * @param  WP_Post|null $post The `WP_Post` object.
     *
     * @return string Next post link URL or HTML output.
     */
    public function get_next_post_link( $prevlink = '', $url = false, $post = null ) {
        return learndash_next_post_link( $prevlink, $url, $post );
    }

    /**
     * Get LearnDash previous post link for lesson or topic.
     *
     * @param  string $prevlink Default next post link.
     * @param  boolean $url Whether to return URL instead of HTML output.
     * @param  WP_Post|null $post The `WP_Post` object.
     *
     * @return string Previous post link URL or HTML output.
     */
    public function get_previous_post_link( $prevlink = '', $url = false, $post = null ) {
        return learndash_previous_post_link( $prevlink, $url, $post );
    }

    /**
     * Gets LearnDash count of the number of topics and quizzes for a lesson.
     *
     * Counts the number of topics, topic quizzes and lesson quizzes, and returns them as an array.
     *
     * @param int|WP_Post $lesson Lesson `WP_Post` object.
     * @param int $course_id The course ID of the lesson.
     *
     * @return array Count of topics and quizzes.
     */
    public function get_lesson_content_count( $lesson, $course_id ) {
        return learndash_get_lesson_content_count( $lesson, $course_id );
    }

    /**
     * Get LearnDash course progress.
     *
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     *
     * @return array Course progress.
     */
    public function get_course_progress( $course_id, $user_id ) {
        return learndash_course_progress( array(
            'array'     => true,
            'course_id' => $course_id,
            'user_id'   => $user_id,
        ) );
    }

    /**
     * Get LearnDash content templates.
     *
     * @param string $template.
     *
     * @return array Content templates.
     */
    public function get_content_templates( $template = '' ) {
        $template_path  = 'themes/ld30/templates';
        $templates      = array(
            'lesson'        => $this->get_path( $template_path . '/' . 'lesson.php' ),
            'topic'         => $this->get_path( $template_path . '/' . 'topic.php' ),
            'quiz'          => $this->get_path( $template_path . '/' . 'quiz.php' )
        );

        if ( $template ) {
            return array_key_exists( $template, $templates ) ? $templates[ $template ] : '';
        }

        return $templates;
    }

    /**
     * Check if LearnDash content template exists.
     *
     * @param string $template.
     *
     * @return boolean Result of checking.
     */
    public function is_content_template_exists( $template ) {
        return ! empty( $this->get_content_templates( $template ) );
    }
}