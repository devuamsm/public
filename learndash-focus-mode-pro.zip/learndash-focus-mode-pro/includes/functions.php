<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Options;
use LDFMP\Classes\Required_Plugins;
use LDFMP\Classes\Template;

if ( ! function_exists( 'ldfmp_get_template_part' ) ) {
    /**
     * Get template part.
     * 
     * @param string $template Template name.
     * @param array $template_data Template data.
     * 
     * @return string HTML of template part.
     */
    function ldfmp_get_template_part( $template, $template_data = '' ) {
        Template::render( $template, $template_data );
    }
}

if ( ! function_exists( 'ldfmp_get_option' ) ) {
    /**
     * Get option.
     * 
     * @param string $option Option name.
     * 
     * @return mixed Option value.
     */
    function ldfmp_get_option( $option = '' ) {
        return Options::get_instance()->get( $option );
    }
}

if ( ! function_exists( 'ldfmp_display_header_logo' ) ) {
    /**
     * Display header logo.
     * 
     * @return boolean Display header logo.
     */
    function ldfmp_display_header_logo() {
        return ldfmp_get_option( 'display_header_logo' );
    }
}

if ( ! function_exists( 'ldfmp_display_course_progress' ) ) {
    /**
     * Display course progress.
     * 
     * @return boolean Display course progress.
     */
    function ldfmp_display_course_progress() {
        return ldfmp_get_option( 'display_course_progress' );
    }
}

if ( ! function_exists( 'ldfmp_display_course_instructors' ) ) {
    /**
     * Display course instructors.
     * 
     * @return boolean Display course instructors.
     */
    function ldfmp_display_course_instructors() {
        return ldfmp_get_option( 'display_course_instructors' ) && Required_Plugins::get_instance()->LearnDash_Instructors->is_activated();
    }
}

if ( ! function_exists( 'ldfmp_get_course_instructors' ) ) {
    /**
     * Get course instructors.
     *
     * @param int $course_id Course ID.
     * 
     * @return array Data of course instructors.
     */
    function ldfmp_get_course_instructors( $course_id ) {
        return Required_Plugins::get_instance()->LearnDash_Instructors->get_course_instructors( $course_id );
    }
}

if ( ! function_exists( 'ldfmp_display_feedback_button' ) ) {
    /**
     * Display feedback button.
     * 
     * @return boolean Display feedback button.
     */
    function ldfmp_display_feedback_button() {
        return ldfmp_get_option( 'display_feedback_button' ) && Required_Plugins::get_instance()->LearnDash_Feedback->is_activated();
    }
}

if ( ! function_exists( 'ldfmp_get_sidebar_position' ) ) {
    /**
     * Get sidebar position.
     * 
     * @return string Sidebar position.
     */
    function ldfmp_get_sidebar_position() {
        return ldfmp_get_option( 'sidebar_position' );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_post_types' ) ) {
    /**
     * Get LearnDash post types.
     * 
     * @param string $type Post type.
     *
     * @return array LearnDash post types.
     */
    function ldfmp_learndash_get_post_types( $type = '' ) {
        return Required_Plugins::get_instance()->LearnDash->get_post_types( $type );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_setting' ) ) {
    /**
     * Get LearnDash setting.
     *
     * @param int $object_id Object ID.
     * @param string $setting Setting key.
     *
     * @return string|void Value for requested setting.
     */
    function ldfmp_learndash_get_setting( $object_id, $setting = '' ) {
        return Required_Plugins::get_instance()->LearnDash->get_setting( $object_id, $setting );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_header_logo' ) ) {
    /**
     * Get LearnDash header logo for focus mode.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Data of header logo.
     */
    function ldfmp_learndash_get_header_logo( $course_id, $user_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_header_logo( $course_id, $user_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_header_user' ) ) {
    /**
     * Get LearnDash header user for focus mode.
     * 
     * @param int $user_id User ID.
     * 
     * @return array Data of header user.
     */
    function ldfmp_learndash_get_header_user( $user_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_header_user( $user_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_header_user_menu' ) ) {
    /**
     * Get LearnDash header user menu for focus mode.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Data of header user menu.
     */
    function ldfmp_learndash_get_header_user_menu( $course_id, $user_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_header_user_menu( $course_id, $user_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_course_id' ) ) {
    /**
     * Get LearnDash course id.
     * 
     * @return int Current course id.
     */
    function ldfmp_learndash_get_course_id() {
        return Required_Plugins::get_instance()->LearnDash->get_course_id(); 
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_course_sections' ) ) {
    /**
     * Get LearnDash course sections.
     * 
     * @param int $course_id Course ID.
     * 
     * @return array Course sections.
     */
    function ldfmp_learndash_get_course_sections( $course_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_course_sections( $course_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_course_lessons' ) ) {
    /**
     * Get LearnDash course lessons.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Course lessons.
     */
    function ldfmp_learndash_get_course_lessons( $course_id, $user_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_course_lessons( $course_id, $user_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_lesson_topics' ) ) {
    /**
     * Get LearnDash lesson quizzes.
     * 
     * @param int $object_id Object ID.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Lesson quizzes.
     */
    function ldfmp_learndash_get_lesson_topics( $lesson_id, $course_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_lesson_topics( $lesson_id, $course_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_topic_quizzes' ) ) {
    /**
     * Get LearnDash topic quizzes.
     * 
     * @param int $object_id Object ID.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Topic quizzes.
     */
    function ldfmp_learndash_get_topic_quizzes( $object_id, $user_id, $course_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_topic_quizzes( $object_id, $user_id, $course_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_lesson_quizzes' ) ) {
    /**
     * Get LearnDash lesson quizzes.
     * 
     * @param int $object_id Object ID.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Lesson quizzes.
     */
    function ldfmp_learndash_get_lesson_quizzes( $object_id, $user_id, $course_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_lesson_quizzes( $object_id, $user_id, $course_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_course_quizzes' ) ) {
    /**
     * Get LearnDash course quizzes.
     * 
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array Course quizzes.
     */
    function ldfmp_learndash_get_course_quizzes( $course_id, $user_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_course_quizzes( $course_id, $user_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_course_single_parent_step' ) ) {
    /**
     * Get LearnDash single parent step ID for a given step ID in a course.
     *
     * @param int $course_id Course ID.
     * @param int $object_id Step ID.
     * @param string $step_type The type of the step.
     *
     * @return int The parent step ID.
     */
    function ldfmp_learndash_get_course_single_parent_step( $course_id, $object_id, $step_type ) {
        return Required_Plugins::get_instance()->LearnDash->get_course_single_parent_step( $course_id, $object_id, $step_type );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_step_permalink' ) ) {
    /**
     * Get LearnDash nested permalink of the course step within in the course.
     *
     * @param int $object_id Course Step Post ID.
     * @param int $course_id Course ID.
     *
     * @return string Step permalink.
     */
    function ldfmp_learndash_get_step_permalink( $object_id, $course_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_step_permalink( $object_id, $course_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_next_post_link' ) ) {
    /**
     * Get LearnDash next post link for lesson or topic.
     *
     * @param  string $prevlink Default next post link.
     * @param  boolean $url Whether to return URL instead of HTML output.
     * @param  WP_Post|null $post The `WP_Post` object.
     *
     * @return string Next post link URL or HTML output.
     */
    function ldfmp_learndash_get_next_post_link( $prevlink = '', $url = false, $post = null ) {
        return Required_Plugins::get_instance()->LearnDash->get_next_post_link( $prevlink, $url, $post );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_previous_post_link' ) ) {
    /**
     * Get LearnDash previous post link for lesson or topic.
     *
     * @param  string $prevlink Default next post link.
     * @param  boolean $url Whether to return URL instead of HTML output.
     * @param  WP_Post|null $post The `WP_Post` object.
     *
     * @return string Previous post link URL or HTML output.
     */
    function ldfmp_learndash_get_previous_post_link( $prevlink = '', $url = false, $post = null ) {
        return Required_Plugins::get_instance()->LearnDash->get_previous_post_link( $prevlink, $url, $post );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_lesson_content_count' ) ) {
    /**
     * Gets LearnDash count of the number of topics and quizzes for a lesson.
     *
     * Counts the number of topics, topic quizzes and lesson quizzes, and returns them as an array.
     *
     * @param int|WP_Post $lesson Lesson `WP_Post` object.
     * @param int $course_id The course ID of the lesson.
     *
     * @return array Count of topics and quizzes.
     */
    function ldfmp_learndash_get_lesson_content_count( $lesson, $course_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_lesson_content_count( $lesson, $course_id );
    }
}

if ( ! function_exists( 'ldfmp_learndash_get_course_progress' ) ) {
    /**
     * Get LearnDash course progress.
     *
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     *
     * @return array Course progress.
     */
    function ldfmp_learndash_get_course_progress( $course_id, $user_id ) {
        return Required_Plugins::get_instance()->LearnDash->get_course_progress( $course_id, $user_id );
    }
}