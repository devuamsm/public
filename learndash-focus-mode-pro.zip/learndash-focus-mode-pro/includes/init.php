<?php

namespace LDFMP;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Options;
use LDFMP\Classes\Required_Plugins;
use LDFMP\Notices\Notice_Error;

class Init {
    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        if ( ! \LDFMP\Required_Plugins\LearnDash::get_instance()->is_activated() ) {
            add_action( 'admin_notices', array( $this, 'admin_notices' ) );
            do_action( 'ldfmp_abort_init' );

            return;
        }

        $this->plugin_init();

        add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );

        do_action( 'ldfmp_loaded' );
    }

    /**
     * Init plugin instances.
     * 
     * @return void
     */
    public function plugin_init() {
        do_action( 'ldfmp_init' );

        Options::get_instance();
        Required_Plugins::get_instance()->add( 
            array(
                'LearnDash'                 => \LDFMP\Required_Plugins\LearnDash::get_instance(),
                'LearnDash_Instructors'     => \LDFMP\Required_Plugins\LearnDash_Instructors::get_instance(),
                'LearnDash_Feedback'        => \LDFMP\Required_Plugins\LearnDash_Feedback::get_instance(),
            )
        );

        Plugin::get_instance();
        Admin::get_instance();
        Frontend::get_instance();

        require_once LDFMP_PATH . '/includes/functions.php';
    }

    /**
     * Admin notices.
     * 
     * @return void
     */
    public function admin_notices() {
        $error = new Notice_Error;
        $error->add( 'missing_required_plugin', sprintf( __( '%s plugin requires %s plugin to be activated.', 'learndash-focus-mode-pro' ), '<strong>' . LDFMP_NAME . '</strong>', '<a href="https://www.learndash.com" target="_blank"><strong>LearnDash LMS</strong></a>' ) );

        echo $error->get_html( 'missing_required_plugin' );
    }

    /**
     * Plugin localization.
     * 
     * @return void
     */
    public function load_plugin_textdomain() {
        $wp_lang_dir    = untrailingslashit( WP_LANG_DIR );
        $locale         = apply_filters( 'plugin_locale', get_locale(), 'learndash-focus-mode-pro' );
        $load           = load_textdomain( 'learndash-focus-mode-pro', $wp_lang_dir . '/plugins/' . 'learndash-focus-mode-pro' . '-' . $locale . '.mo' );

        if ( ! $load ) {
            load_plugin_textdomain( 'learndash-focus-mode-pro', FALSE, basename( dirname( LDFMP_FILE ) ) . '/languages/' );
        };
    }
}