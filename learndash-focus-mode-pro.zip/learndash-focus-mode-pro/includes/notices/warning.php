<?php

namespace LDFMP\Notices;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Notice;

class Notice_Warning extends Notice {
    /**
     * Get CSS class.
     *
     * @return string CSS class.
     */
    public function get_css_class() {
        return 'warning';
    }
}