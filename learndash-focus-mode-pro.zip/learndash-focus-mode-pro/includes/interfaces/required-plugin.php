<?php

namespace LDFMP\Interfaces;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

interface Interface_Required_Plugin {
    /**
     * Get plugin slug.
     */
    public function get_slug();
    /**
     * Get plugin name.
     */
    public function get_name();
    /**
     * Get plugin url.
     */
    public function get_public_url();
}