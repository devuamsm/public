<?php

namespace LDFMP\Interfaces;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

interface Interface_Notice {
    /**
     * Get CSS class.
     */
    public function get_css_class();
}