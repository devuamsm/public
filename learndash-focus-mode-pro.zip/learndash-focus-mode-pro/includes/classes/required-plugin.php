<?php

namespace LDFMP\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Interfaces\Interface_Required_Plugin;

require_once ABSPATH . '/wp-admin/includes/plugin.php';

abstract class Required_Plugin implements Interface_Required_Plugin {
    /**
     * Get plugin slug.
     */
    abstract public function get_slug();

    /**
     * Get plugin name.
     */
    abstract public function get_name();

    /**
     * Get plugin url.
     */
    abstract public function get_public_url();

    /**
     * Check if plugin is installed.
     * 
     * @return boolean Result of checking.
     */
    final public function is_installed() {
        return array_key_exists( $this->get_slug(), get_plugins() );
    }

    /**
     * Check if plugin is activated.
     * 
     * @return boolean Result of checking.
     */
    final public function is_activated() {
        return is_plugin_active( $this->get_slug() );
    }

    /**
     * Get the url of the admin plugins page.
     * 
     * @return string Url.
     */
    final public function get_plugins_url() {
        return admin_url( 'plugins.php' );
    }

    /**
     * Get plugin file.
     * 
     * @return string Path to main plugin file.
     */
    final public function get_file() {
        return WP_PLUGIN_DIR . '/' . $this->get_slug();
    }

    /**
     * Get plugin dir.
     * 
     * @return string Path to plugin dir.
     */
    final public function get_dir() {
        return dirname( $this->get_file() );
    }

    /**
     * Get plugin dir.
     * 
     * @return string Path to plugin folder.
     */
    final public function get_path( $path ) {
        return $this->get_dir() . '/' . trim( $path, '/' );
    }

    /**
     * Get plugin url.
     * 
     * @return string Url to plugin folder.
     */
    final public function get_url( $url = '' ) {
        return plugins_url( $url, $this->get_file() );
    }

    /**
     * Get plugin data.
     * 
     * @return string|array Plugin data.
     */
    final public function get_data( $key = '' ) {
        $data = get_plugin_data( $this->get_file() );

        if ( ! empty( $key ) ) {
            return array_key_exists( $key, $data ) ? $data[ $key ] : '';
        }

        return $data;
    }

    /**
     * Get plugin setting description.
     * 
     * @return string Plugin setting description.
     */
    final public function get_setting_description() {
        $description = '';
        $action      = '';
        $action_url  = '';

        if ( ! $this->is_installed() ) {
            $action      = _x( 'Install', 'Plugin status', 'learndash-focus-mode-pro' );
            $action_url  = $this->get_public_url();
        } elseif ( ! $this->is_activated() ) {
            $action      = _x( 'Activate', 'Plugin status', 'learndash-focus-mode-pro' );
            $action_url  = $this->get_plugins_url();
        }

        if ( $action ) {
            $description = sprintf( '<a href="%s" target="_blank">%s %s</a>', $action_url, $action, $this->get_name() );
        }

        return $description;
    }
}