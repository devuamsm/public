<?php

namespace LDFMP\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Notices\Notice_Error;
use LDFMP\Notices\Notice_Success;
use LDFMP\Notices\Notice_Warning;
use LDFMP\Notices\Notice_Info;

class Notice_Manager {
    /**
     * @var object instance of Notice_Error.
     */
    private $error;

    /**
     * @var object instance of Notice_Success.
     */
    private $success;

    /**
     * @var object instance of Notice_Warning.
     */
    private $warning;

    /**
     * @var object instance of Notice_Info.
     */
    private $info;

    /**
     * Constructor.
     */
    public function __construct() {
        $this->error        = new Notice_Error;
        $this->success      = new Notice_Success;
        $this->warning      = new Notice_Warning;
        $this->info         = new Notice_Info;
    }

    /**
     * Get notices by type.
     *
     * @param string $type Notice type.
     * 
     * @return object|null Instance of Notice_Error|Notice_Success|Notice_Warning|Notice_Info.
     */
    public function __get( $type ) {
        return property_exists( $this, $type ) ? $this->$type : null;
    }
}