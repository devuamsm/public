<?php

namespace LDFMP\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

class License_Manager {
    use \LDFMP\Traits\Singleton;

    /**
     * @var string API url.
     */
    const API_URL = 'https://wooninjas.com/';

    /**
     * @var int Request timeout.
     */
    const REQUEST_TIMEOUT = 30;

    /**
     * @var string API param for activation a license key.
     */
    const PARAM_LICENSE_ACTIVATE = 'activate_license';

    /**
     * @var string API param for deactivation a license key.
     */
    const PARAM_LICENSE_DEACTIVATE = 'deactivate_license';

    /**
     * @var string API param for checking a license key.
     */
    const PARAM_LICENSE_CHECK = 'check_license';

    /**
     * @var string Plugin name.
     */
    private $plugin_name = '';

    /**
     * @var string License key.
     */
    private $license_key = '';

    /**
     * @var string Status code.
     */
    private $status_code = '';

    /**
     * @var string Status.
     */
    private $status = '';

    /**
     * @var string API response.
     */
    private $response = null;

    /**
     * Set plugin name.
     *
     * @param string $plugin_name Plugin name.
     * 
     * @return object Instance of this class.
     */
    public function set_plugin_name( $plugin_name ) {
        $this->plugin_name = $plugin_name;

        return $this;
    }

    /**
     * Get plugin name.
     *
     * @return string Plugin name.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * Set license key.
     *
     * @param string $license_key License key.
     * 
     * @return object Instance of this class.
     */
    public function set_license_key( $license_key ) {
        $this->license_key = trim( $license_key );

        return $this;
    }

    /**
     * Get license key.
     *
     * @return string License key.
     */
    public function get_license_key() {
        return $this->license_key;
    }

    /**
     * Activate license key.
     * 
     * @return boolean|WP_Error Result of activating.
     */
    public function activate() {
        $api_params     = wp_parse_args( $this->get_default_api_params(), array( 'edd_action' => self::PARAM_LICENSE_ACTIVATE ) );
        $license_data   = $this->api_request( $api_params );

        if ( is_wp_error( $license_data ) ) {
            return $license_data;
        }

        $code = ! empty( $license_data['error'] ) ? $license_data['error'] : $license_data['license'];

        $this->set_status_code( $code );
        $this->set_status( $code );

        if ( $license_data['license'] !== 'valid' ) {
            return new \WP_Error( $this->get_status_code(), $this->get_status() );
        }

        return true;
    }

    /**
     * Deactivate license key.
     * 
     * @return boolean|WP_Error Result of deactivating.
     */
    public function deactivate() {
        $api_params     = wp_parse_args( $this->get_default_api_params(), array( 'edd_action' => self::PARAM_LICENSE_DEACTIVATE ) );
        $license_data   = $this->api_request( $api_params );

        if ( is_wp_error( $license_data ) ) {
            return $license_data;
        }

        $code = ! empty( $license_data['error'] ) ? $license_data['error'] : $license_data['license'];

        $this->set_status_code( $code );
        $this->set_status( $code );

        if ( ! in_array( $license_data['license'], array( 'deactivated', 'failed' ) ) ) {
            return new \WP_Error( $this->get_status_code(), $this->get_status() );
        }

        return true;
    }

    /**
     * Check license key.
     * 
     * @return boolean|WP_Error Result of checking.
     */
    public function check() {
        $api_params     = wp_parse_args( $this->get_default_api_params(), array( 'edd_action' => self::PARAM_LICENSE_CHECK ) );
        $license_data   = $this->api_request( $api_params );

        if ( is_wp_error( $license_data ) ) {
            return $license_data;
        }

        $code = ! empty( $license_data['error'] ) ? $license_data['error'] : $license_data['license'];

        $this->set_status_code( $code );
        $this->set_status( $code );

        if ( $license_data['license'] != 'valid' ) {
            return new \WP_Error( $this->get_status_code(), $this->get_status() );
        }

        return true;
    }

    /**
     * Get default API params.
     * 
     * @return array Default API params.
     */
    private function get_default_api_params() {
        return array(
            'license'    => $this->get_license_key(),
            'item_name'  => urlencode( $this->get_plugin_name() ),
            'url'        => urlencode( home_url() ),
            'time'       => current_time( 'timestamp' )
        );
    }

    /**
     * Execute an API request.
     * 
     * @param array $api_params API params.
     * 
     * @return array|WP_Error API response.
     */
    private function api_request( $api_params ) {
        $this->reset_status_code();
        $this->reset_status();

        if ( empty( $api_params['license'] ) ) {
            $this->set_status_code( 'missing' );
            $this->set_status( 'missing' );

            $this->response = new \WP_Error( $this->get_status_code(), $this->get_status() ); 
        } else {
            $response = wp_remote_post( self::API_URL, array( 
                'sslverify'     => false,
                'timeout'       => self::REQUEST_TIMEOUT,
                'body'          => $api_params
            ) );

            if ( is_wp_error( $response ) ) {
                $this->set_status_code( $response->get_error_code() );
                $this->set_status( $response->get_error_code(), $response->get_error_message() );
                $this->response = $response;
            } elseif ( wp_remote_retrieve_response_code( $response ) !== 200 ) {
                $this->set_status_code( 'unknown' );
                $this->set_status( 'unknown' );
                $this->response = new \WP_Error( $this->get_status_code(), $this->get_status() );
            } else {
                $this->response = json_decode( wp_remote_retrieve_body( $response ), true );
            }
        }

        return $this->response;
    }

    /**
     * Set status code.
     * 
     * @param string $code Status code.
     * 
     * @return object Instance of this class.
     */
    private function set_status_code( $code ) {
        $this->status_code = $code;

        return $this;
    }

    /**
     * Get status code.
     * 
     * @return string Status code.
     */
    public function get_status_code() {
        return $this->status_code;
    }

    /**
     * Reset status code.
     * 
     * @return object Instance of this class.
     */
    private function reset_status_code() {
        $this->status_code = '';

        return $this;
    }

    /**
     * Set status.
     * 
     * @param string $code Status.
     * @param string $status Custom status.
     * 
     * @return object Instance of this class.
     */
    private function set_status( $code, $status = '' ) {
        if ( $status ) {
            $this->status = $status;
        } else {
            switch( $code ) {
                case 'valid':
                    $this->status = __( 'License key is valid.', 'learndash-focus-mode-pro' );
                        break;
                case 'invalid':
                    $this->status = __( 'License key is invalid.', 'learndash-focus-mode-pro' );
                    break;
                case 'expired':
                    $this->status = __( 'License key has expired.', 'learndash-focus-mode-pro' );
                    break;
                case 'disabled':
                    $this->status = __( 'License key has been disabled.', 'learndash-focus-mode-pro' );
                    break;
                case 'revoked':
                    $this->status = __( 'License key has been revoked.', 'learndash-focus-mode-pro' );
                    break;
                case 'missing':
                    $this->status = __( 'License key is missing.', 'learndash-focus-mode-pro' );
                    break;
                case 'site_inactive':
                    $parse_url      = parse_url( home_url() );
                    $this->status   = sprintf( __( 'License is not active for %s', 'learndash-focus-mode-pro' ), $parse_url['host'] );
                    break;
                case 'item_name_mismatch':
                    $this->status = sprintf( __( 'License key is invalid for %s.', 'learndash-focus-mode-pro' ), $this->get_plugin_name() );
                    break;
                case 'no_activations_left':
                    $this->status = __( 'License key has reached its activation limit.', 'learndash-focus-mode-pro' );
                    break;
                case 'unknown':
                default:
                    $this->status = __( 'An error occurred, please try again.', 'learndash-focus-mode-pro' );
                    break;
            }
        }

        return $this;
    }

    /**
     * Get status.
     * 
     * @return string Status.
     */
    public function get_status() {
        return $this->status;
    }

    /**
     * Reset status.
     * 
     * @return object Instance of this class.
     */
    private function reset_status() {
        $this->status = '';

        return $this;
    }
}