<?php

namespace LDFMP\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

class Required_Plugins {
    use \LDFMP\Traits\Singleton;

    /**
     * @var array Required plugins.
     */
    private $plugins = array();

    /**
     * Add required plugin to array.
     *
     * @param object $plugin Instance of LDFMP\Required_Plugins\*
     * 
     * @return object Instance of this class.
     */
    public function add( $plugin ) {
        if ( is_array( $plugin ) ) {
            $this->plugins = array_merge( $this->plugins, $plugin );
        }

        return $this;
    }

    /**
     * Get required plugin instance.
     *
     * @param string $plugin Plugin ID.
     * 
     * @return object|null Instance of required plugin.
     */
    public function __get( $plugin ) {
        return ( array_key_exists( $plugin, $this->plugins ) ) ? $this->plugins[ $plugin ] : null;
    }

    /**
     * Get all instances of required plugins.
     * 
     * @return array Array of all instances of required plugins.
     */
    public function get() {
        return $this->plugins;
    }
}