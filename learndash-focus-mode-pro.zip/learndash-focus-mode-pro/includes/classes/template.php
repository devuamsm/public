<?php

namespace LDFMP\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

class Template {
    /**
     * Render template.
     *
     * @param string $template Template name.
     * @param array $template_data Template data.
     * @return void
     */
    public static function render( $template, $template_data = array() ) {
        $template_data  = apply_filters( 'ldfmp_render_template_data', $template_data, $template );
        $template_file  = apply_filters( 'ldfmp_render_template_file', LDFMP_PATH_TEMPLATES . '/' . trim( $template, '/' ), $template, $template_data );

        if ( file_exists( $template_file ) ) {
            do_action( 'ldfmp_before_render_template', $template, $template_file, $template_data );
            extract( $template_data );
            require $template_file;
            do_action( 'after_before_render_template', $template, $template_file, $template_data );
        }
    }

    /**
     * Get template template.
     *
     * @param string $template Template name.
     * @return string Template path.
     */
    public static function get_path( $template ) {
        $template_file = apply_filters( 'ldfmp_get_template_file', LDFMP_PATH_TEMPLATES . '/' . trim( $template, '/' ), $template );

        return file_exists( $template_file ) ? $template_file : '';
    }
}