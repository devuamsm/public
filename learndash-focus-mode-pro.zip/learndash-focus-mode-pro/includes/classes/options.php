<?php

namespace LDFMP\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

class Options {
    use \LDFMP\Traits\Singleton;

    /**
     * @var string Options key.
     */
    const OPTIONS_KEY = 'ldfmp_options';

    /**
     * @var null|array Current options.
     */
    private $options = null;

    /**
     * Constructor.
     * 
     * @return void
     */
    protected function __construct() {
        $this->init();
    }

    /**
     * Init options.
     * 
     * @return void
     */
    private function init() {
        $this->options = apply_filters( 'ldfmp_get_options', get_option( self::OPTIONS_KEY, null ) );

        if ( is_null( $this->options ) ) {
            $this->set_default();
        } else {
            $this->check_upgrade();
        }
    }

    /**
     * Get default options.
     * 
     * @return array Default options.
     */
    public function get_default() {
        return apply_filters( 'ldfmp_get_default_options', array(
            'version'                       => LDFMP_VERSION,
            'display_header_logo'           => true,
            'display_course_progress'       => true,
            'display_course_instructors'    => true,
            'display_feedback_button'       => true,
            'sidebar_position'              => 'left',
            'license_key'                   => ''
        ) );
    }

    /**
     * Set default options.
     * 
     * @return void
     */
    public function set_default() {
        $this->set_all( $this->get_default() );
        $this->save();
    }

    /**
     * Check if options need upgrade.
     * 
     * @return object Instance of this class.
     */
    public function check_upgrade() {
        if ( version_compare( LDFMP_VERSION, $this->get( 'version' ), '>' ) ) {
            $upgrade = array(
                'default_options'   => $this->get_default(),
                'options'           => $this->options
            );
            do_action_ref_array( 'ldfmp_before_upgrade_options', array( &$upgrade ) );
            $this->options = array_merge( $upgrade['default_options'], $upgrade['options'] );
            $this->save();
        }

        return $this;
    }

    /**
     * Get option by key.
     * 
     * @param string $key Option key.
     * 
     * @return object Instance of this class.
     */
    public function get( $key ) {
        return array_key_exists( $key, $this->options ) ? $this->options[ $key ] : null;
    }

    /**
     * Get all options.
     * 
     * @return null|array Options.
     */
    public function get_all() {
        return $this->options;
    }

    /**
     * Set option by key.
     *
     * @param string $key Option key.
     * @param mixed $data Option value.
     * 
     * @return object Instance of this class.
     */
    public function set( $key, $data ) {
        if ( array_key_exists( $key, $this->options ) ) {
            $this->options[ $key ] = $data;
        }

        return $this;
    }

    /**
     * Set all options.
     *
     * @param null|array $data
     * 
     * @return object Instance of this class.
     */
    public function set_all( $data ) {
        $this->options = $data;

        return $this;
    }

    /**
     * Save options.
     * 
     * @return object Instance of this class.
     */
    public function save() {
        $this->options = apply_filters( 'ldfmp_save_options', $this->options );
        update_option( self::OPTIONS_KEY, $this->options );

        return $this;
    }

    /**
     * Delete options.
     * 
     * @return object Instance of this class.
     */
    public function delete() {
        delete_option( self::OPTIONS_KEY );

        return $this;
    }
}