<?php

namespace LDFMP;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Options;
use LDFMP\Classes\Required_Plugins;
use LDFMP\Classes\Template;
use LDFMP\Classes\Notice_Manager;
use LDFMP\Classes\License_Manager;

class Admin {
    use \LDFMP\Traits\Singleton;

    /**
     * @var string Settings page slug.
     */
    const PAGE_SLUG = 'ldfmp-focus-mode-pro';

    /**
     * @var string Settings form nonce action.
     */
    const FORM_NONCE_ACTION = 'ldfmp_submit_settings_form';

    /**
     * @var string Settings form nonce name.
     */
    const FORM_NONCE_NAME = 'ldfmp_nonce_settings_form';

    /**
     * @var string Settings form action save.
     */
    const FORM_ACTION_SAVE_SETTINGS = 'save_settings';

    /**
     * @var string Settings form action activate license key.
     */
    const FORM_ACTION_ACTIVATE_LICENSE_KEY = 'activate_license_key';

    /**
     * @var string Settings form action deactivate license key.
     */
    const FORM_ACTION_DEACTIVATE_LICENSE_KEY = 'deactivate_license_key';

    /**
     * @var string Settings form action deactivate license key.
     */
    const FORM_ACTION_CHECK_LICENSE_KEY = 'check_license_key';

    /**
     * @var object Notice manager.
     */
    private $notice_manager;

    /**
     * @var object License manager.
     */
    private $license_manager;

    /**
     * @var object Plugin options.
     */
    private $options;

    /**
     * @var object Required plugins.
     */
    private $required_plugins;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        $this->notice_manager       = new Notice_Manager;
        $this->license_manager      = License_Manager::get_instance();
        $this->options              = Options::get_instance();
        $this->required_plugins     = Required_Plugins::get_instance();

        add_filter( 'plugin_action_links', array( $this, 'plugin_action_links' ), 10, 4 );
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_filter( 'learndash_settings_fields', array( $this, 'learndash_hide_setting_focus_mode_content_width' ), 10, 2 );
    }

    /**
     * Add an item to the plugin action links.
     * 
     * @param array $actions Current plugin actions.
     * @return string $plugin_file Current plugin file.
     * @return array $plugin_data Current plugin data.
     * @return string $context Current plugins.php page tab.
     * 
     * @return array $actions Modified plugin actions.
     */
    public function plugin_action_links( $actions, $plugin_file, $plugin_data, $context ) {
        if ( plugin_basename( LDFMP_FILE ) == $plugin_file ) {
            $settings_link = sprintf( '<a href="%s">%s</a>', esc_url( add_query_arg( 'page', self::PAGE_SLUG, admin_url( 'admin.php' ) ) ), __( 'Settings', 'learndash-focus-mode-pro' ) );
            array_unshift( $actions, $settings_link );
        }

        return $actions;
    }

    /**
     * Render admin menu.
     * 
     * @return void
     */
    public function admin_menu() {
        $settings_page = add_submenu_page( 'learndash-lms', 'Focus Mode Pro', 'Focus Mode Pro', 'manage_options', self::PAGE_SLUG, array( $this, 'render_settings_page' ) );
        add_action( 'load-' . $settings_page, array( $this, 'settings_page_hooks' ) );
    }

    /**
     * Settings page hooks.
     * 
     * @return void
     */
    public function settings_page_hooks() {
        add_action( 'admin_enqueue_scripts', array( $this, 'settings_page_assets' ) );
    }

    /**
     * Enqueue settings page assets.
     * 
     * @return void
     */
    public function settings_page_assets() {
        wp_enqueue_style( 'ldfmp-font-icons', LDFMP_URL_ASSETS_CSS . '/MaterialIcons' .  LDFMP_ASSETS_SUFFIX .  '.css', array(), LDFMP_VERSION );
        wp_enqueue_style( 'ldfmp-settings-page', LDFMP_URL_ASSETS_CSS . '/admin' .  LDFMP_ASSETS_SUFFIX .  '.css', array( 'ldfmp-font-icons' ), LDFMP_VERSION );
        wp_enqueue_script( 'ldfmp-settings-page', LDFMP_URL_ASSETS_JS . '/admin' .  LDFMP_ASSETS_SUFFIX .  '.js', array( 'jquery' ), LDFMP_VERSION, true );
    }

    /**
     * Save settings.
     * 
     * @return void
     */
    public function save_settings( $data ) {
        if ( isset( $data['display_header_logo'] ) ) {
            $this->options->set( 'display_header_logo', $data['display_header_logo'] == 'true' );
        }

        if ( isset( $data['display_course_progress'] ) ) {
            $this->options->set( 'display_course_progress', $data['display_course_progress'] == 'true' );
        }

        if ( isset( $data['display_course_instructors'] ) && $this->required_plugins->LearnDash_Instructors->is_activated() ) {
            $this->options->set( 'display_course_instructors', $data['display_course_instructors'] == 'true' );
        }

        if ( isset( $data['display_feedback_button'] ) && $this->required_plugins->LearnDash_Feedback->is_activated() ) {
            $this->options->set( 'display_feedback_button', $data['display_feedback_button'] == 'true' );
        }

        if ( isset( $data['sidebar_position'] ) ) {
            $this->options->set( 'sidebar_position', in_array( $data['sidebar_position'], array( 'left', 'right' ) ) ? $data['sidebar_position'] : 'left' );
        }

        $this->options->save();

        $this->notice_manager->success->add( 'settings_saved', sprintf( '<strong>%s</strong>', __( 'Settings saved.', 'learndash-focus-mode-pro' ) ) );
    }

    /**
     * Activate license key.
     * 
     * @return void
     */
    public function activate_license_key( $data ) {
        $this->license_manager->set_license_key( $data['license_key'] );
        $attempt_activate = $this->license_manager->activate();

        if ( is_wp_error( $attempt_activate ) ) {
            $this->notice_manager->error->add( 'activate_license_key', sprintf( '<strong>%s</strong>', $attempt_activate->get_error_message() ) );
        } else {
            $this->options->set( 'license_key', $this->license_manager->get_license_key() );
            $this->options->save();
            $this->notice_manager->success->add( 'activate_license_key', sprintf( '<strong>%s</strong>', __( 'License key has been activated.', 'learndash-focus-mode-pro' ) ) );
        }
    }

    /**
     * Deactivate license key.
     * 
     * @return void
     */
    public function deactivate_license_key( $data ) {
        $this->license_manager->set_license_key( $data['license_key'] );
        $attempt_deactivate = $this->license_manager->deactivate();

        if ( is_wp_error( $attempt_deactivate ) ) {
            $this->notice_manager->error->add( 'deactivate_license_key', sprintf( '<strong>%s</strong>', $attempt_deactivate->get_error_message() ) );
        } else {
            $this->options->set( 'license_key', '' );
            $this->options->save();
            $this->notice_manager->success->add( 'deactivate_license_key', sprintf( '<strong>%s</strong>', __( 'License key has been deactivated.', 'learndash-focus-mode-pro' ) ) );
        }
    }

    /**
     * Check license key.
     * 
     * @return void
     */
    public function check_license_key( $data ) {
        $this->license_manager->set_license_key( $data['license_key'] );
        $attempt_check = $this->license_manager->check();

        if ( is_wp_error( $attempt_check ) ) {
            $this->notice_manager->error->add( 'check_license_key', sprintf( '<strong>%s</strong>', $attempt_check->get_error_message() ) );
        } else {
            $this->notice_manager->success->add( 'check_license_key', sprintf( '<strong>%s</strong>', $this->license_manager->get_status() ) );
        }
    }

    /**
     * Render settings page.
     * 
     * @return void
     */
    public function render_settings_page() {
        if ( ! empty( $_POST['ldfmp_submit_form'] ) && check_admin_referer( self::FORM_NONCE_ACTION, self::FORM_NONCE_NAME ) ) {
            if ( $_POST['ldfmp_submit_form'] == self::FORM_ACTION_SAVE_SETTINGS ) {
                $this->save_settings( $_POST['ldfmp_settings'] );
            } elseif( $_POST['ldfmp_submit_form'] == self::FORM_ACTION_ACTIVATE_LICENSE_KEY ) {
                $this->activate_license_key( $_POST['ldfmp_license'] );
            } elseif( $_POST['ldfmp_submit_form'] == self::FORM_ACTION_DEACTIVATE_LICENSE_KEY ) {
                $this->deactivate_license_key( $_POST['ldfmp_license'] );
            } elseif( $_POST['ldfmp_submit_form'] == self::FORM_ACTION_CHECK_LICENSE_KEY ) {
                $this->check_license_key( $_POST['ldfmp_license'] );
            }
        }

        $notice_manager     = $this->notice_manager;
        $license_manager    = $this->license_manager;
        $options            = $this->options;
        $required_plugins   = $this->required_plugins;

        $page_url           = add_query_arg( 'page', self::PAGE_SLUG, admin_url( 'admin.php' ) );

        $tabs = array(
            array(
                'id'            => 'general',
                'title'         => __( 'General', 'learndash-focus-mode-pro' ),
                'icon'          => '&#xe8b8;',
            ),
            array(
                'id'            => 'license-key',
                'title'         => __( 'License key', 'learndash-focus-mode-pro' ),
                'icon'          => '&#xe73c;',
            )
        );

        $tab_active = isset( $_REQUEST['tab'] ) && array_search( $_REQUEST['tab'], array_column( $tabs, 'id' ) ) !== false ? $_REQUEST['tab'] : $tabs[0]['id'];

        $is_plugin_activated = false;
        $license_key = $this->options->get( 'license_key' );

        if ( $license_key ) {
            $license_manager->set_license_key( $license_key );
            $attempt_check = $license_manager->check();
            $is_plugin_activated = ! is_wp_error( $attempt_check );
        }

        $plugin = array(
            'name'      => LDFMP_NAME,
            'version'   => LDFMP_VERSION,
            'activated' => $is_plugin_activated
        );

        $form_actions = array(
            'save_settings'             => self::FORM_ACTION_SAVE_SETTINGS,
            'activate_license_key'      => self::FORM_ACTION_ACTIVATE_LICENSE_KEY,
            'deactivate_license_key'    => self::FORM_ACTION_DEACTIVATE_LICENSE_KEY,
            'check_license_key'         => self::FORM_ACTION_CHECK_LICENSE_KEY
        );

        $nonce_field = wp_nonce_field( self::FORM_NONCE_ACTION, self::FORM_NONCE_NAME, true, false );

        Template::render( 'admin/settings-page.php', array( 
            'notice_manager'    => $notice_manager,
            'options'           => $options,
            'required_plugins'  => $required_plugins,
            'page_url'          => $page_url,
            'tabs'              => $tabs,
            'tab_active'        => $tab_active,
            'plugin'            => $plugin,
            'form_actions'      => $form_actions,
            'nonce_field'       => $nonce_field
        ) );
    }

    /**
     * Filters learndash setting fields.
     *
     * @param array $option_fields Current data of settings fields.
     * @param string $section_key Used within the Settings API to uniquely identify this section.
     *
     * @return array $option_fields Modified data of settings fields.
     */
    public function learndash_hide_setting_focus_mode_content_width( $option_fields, $section_key ) {
        if ( $section_key == 'settings_theme_ld30' ) {
            unset( $option_fields[ 'focus_mode_content_width' ] );
        }
        return $option_fields;
    }
}