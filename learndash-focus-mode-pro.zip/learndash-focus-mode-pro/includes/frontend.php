<?php

namespace LDFMP;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDFMP\Classes\Options;
use LDFMP\Classes\Required_Plugins;
use LDFMP\Classes\Template;

class Frontend {
    use \LDFMP\Traits\Singleton;

    /**
     * @var object Plugin options.
     */
    private $options;

    /**
     * @var object Required plugins.
     */
    private $required_plugins;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        $this->options              = Options::get_instance();
        $this->required_plugins     = Required_Plugins::get_instance();

        Frontend_Feedback_Button::get_instance();

        add_filter( 'body_class', array( $this, 'focus_mode_body_class' ), PHP_INT_MAX );
        add_action( 'wp_head', array( $this, 'focus_mode_frontend_inline_css' ), PHP_INT_MAX );
        add_action( 'wp_enqueue_scripts', array( $this, 'focus_mode_frontend_assets_js_css' ), PHP_INT_MAX );
        add_filter( 'template_include', array( $this, 'focus_mode_template_include' ), PHP_INT_MAX );
        add_action( 'the_post', array( $this, 'focus_mode_the_post' ), PHP_INT_MAX, 2 );
    }

    /**
     * Body classes.
     *
     * @param array $classes Current body classes.
     *
     * @return array $classes Modified body classes.
     */
    public function focus_mode_body_class( $classes ) {
        if ( $this->required_plugins->LearnDash->is_focus_mode() ) {
            $classes[] = 'ldfmp-focus-mode';

            if ( ! empty( $_COOKIE['ldfmp_theme'] ) && $_COOKIE['ldfmp_theme'] == 'dark' ) {
                $classes[] = 'ldfmp-focus-mode-theme-dark';
            }

            $classes[] = 'ldfmp-focus-mode-sidebar-' . ( $this->options->get('sidebar_position' ) !== 'right' ? 'left' : 'right' );

            if ( ! empty( $_COOKIE['ldfmp_sidebar'] ) && $_COOKIE['ldfmp_sidebar'] == 'hidden' ) {
                $classes[] = 'ldfmp-focus-mode-sidebar-desktop-hidden';
            }
        }

        return $classes;
    }

    /**
     * Inline styles.
     *
     * @return void
     */
    public function focus_mode_frontend_inline_css() {
        if ( $this->required_plugins->LearnDash->is_focus_mode() ) {
            if ( is_admin_bar_showing() ) {
                echo '<style media="screen">
                    html { min-height: calc(100% - 32px) !important; height: calc(100% - 32px) !important; }
                    @media screen and ( max-width: 782px ) {
                        html { min-height: calc(100% - 46px) !important; height: calc(100% - 46px) !important; }
                    }
                </style>';
            }
        }
    }

    /**
     * Enqueue frontend assets.
     * 
     * @return void
     */
    public function focus_mode_frontend_assets_js_css() {
        if ( $this->required_plugins->LearnDash->is_focus_mode() ) {
            wp_enqueue_style( 'ldfmp-frontend', LDFMP_URL_ASSETS_CSS . '/frontend' .  LDFMP_ASSETS_SUFFIX .  '.css', array(), LDFMP_VERSION );
            wp_enqueue_script( 'ldfmp-frontend', LDFMP_URL_ASSETS_JS . '/frontend' .  LDFMP_ASSETS_SUFFIX .  '.js', array( 'jquery' ), LDFMP_VERSION, true );
        }
    }

    /**
     * Overwrite custom mode default template.
     *
     * @param string $template Current template.
     *
     * @return array string $template Modified template.
     */
    public function focus_mode_template_include( $template ) {
        if ( $this->required_plugins->LearnDash->is_focus_mode() )  {
            return Template::get_path( 'focus-mode/index.php' );
        }

        return $template;
    }

    /**
     * Focus mode template filters.
     *
     * @return void
     */
    public function focus_mode_the_post( $post, $query ) {
        if ( ! is_admin() && $this->required_plugins->LearnDash->is_focus_mode() )  {
            add_filter( 'learndash_template', array( $this, 'focus_mode_get_template_content' ), PHP_INT_MAX, 5 );
            add_filter( 'learndash_template_filename', array( $this, 'focus_mode_remove_infobar' ), PHP_INT_MAX, 5 );
            add_filter( 'learndash_content_tabs', array( $this, 'remove_content_tabs' ), PHP_INT_MAX, 4 );
        }
    }

    /**
     * Filters file path for the learndash template being called.
     *
     * @param string $filepath Current template file path.
     * @param string $name Template name.
     * @param array $args Template data.
     * @param boolean $echo Whether to echo the template output or not.
     * @param boolean $return_file_path Whether to return file or path or not.
     * 
     * @return string $filepath Modified template file path.
     */
    public function focus_mode_get_template_content( $filepath, $name, $args, $echo, $return_file_path ) {
        if ( $this->required_plugins->LearnDash->is_content_template_exists ( $name ) ) {
            $filepath = $this->required_plugins->LearnDash->get_content_templates( $name );
        }

        return $filepath;
    }

    /**
     * Filters template file name.
     *
     * @param string $template_filename Current template file name.
     * @param string $name Template name.
     * @param array $args Template data.
     * @param boolean $echo Whether to echo the template output or not.
     * @param boolean $return_file_path Whether to return file or path or not.
     * 
     * @return string $template_filename Modified template file name.
     */
    public function focus_mode_remove_infobar( $template_filename, $name, $args, $echo, $return_file_path ) {
        if ( $template_filename == 'modules/infobar.php' && ( isset( $args['context'] ) && $this->required_plugins->LearnDash->is_content_template_exists ( $args['context'] ) ) ) {
            $template_filename = '';
        }

        return $template_filename;
    }

    /**
     * Filters LearnDash content Tabs.
     *
     * @param array $tabs Current tabs array data. The tabs array data can contain keys for id, icon, label, content.
     * @param string $context The context where the tabs are shown like course, lesson, topic, quiz, etc.
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return array $tabs Modified tabs array data.
     */
    public function remove_content_tabs( $tabs, $context, $course_id, $user_id ) {
        if ( array_key_exists( $context, $this->required_plugins->LearnDash->get_post_types() ) ) {
            $tab_keys               = array();
            $tab_key_content        = array_search( 'content', array_column( $tabs, 'id' ) );
            $tab_key_materials      = array_search( 'materials', array_column( $tabs, 'id' ) );

            if ( $tab_key_content !== false ) {
                $tab_keys[] = $tab_key_content;
            }

            if ( $tab_key_materials !== false ) {
                $tab_keys[] = $tab_key_materials;
            }

            if ( $tab_keys ) {
                $tabs = array_intersect_key( $tabs, array_flip( $tab_keys ) );
            }
        }

        return $tabs;
    }
}