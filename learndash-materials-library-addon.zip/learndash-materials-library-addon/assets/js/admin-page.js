jQuery( function( $ ) {
    $( document ).ready( function() {
        var $shortcode                      = $( '.js-ldmla-shortcode' ),
            $filter_by_course_categories    = $( '.js-ldmla-filter-by-course-categories' ),
            $setting_course_categories      = $( '.js-ldmla-setting-course-categories' ),
            $course_categories              = $( '.js-ldmla-course-categories' ),
            $materials_per_page             = $( '.js-ldmla-materials-per-page' ),
            $copy_button                    = $( '.js-ldmla-copy-button' ),
            $copy_notice                    = $( '.js-ldmla-copy-notice' ),
            $copy_shortcode                 = $( '.js-ldmla-copy-shortcode' ),
            prev_course_category_id         = 0;

        $filter_by_course_categories.on( 'change', function() {
            $course_categories.trigger( 'ldmla.course_categories.select_all' );
            $setting_course_categories.toggleClass( 'hidden', ! $filter_by_course_categories.is( ':checked' ) );
            $shortcode.trigger( 'ldmla_generate' );
        } );

        /* On change and select all Course categories. */
        $course_categories
            .on( 'change', function() {
                var selected_course_categories_ids = $course_categories.val();

                if ( selected_course_categories_ids.length == 1 ) {
                    prev_course_category_id = selected_course_categories_ids[0];
                }

                if ( selected_course_categories_ids.length == 0 ) {
                    $course_categories.find( 'option[value="' + prev_course_category_id + '"]' ).prop( 'selected', true );
                }

                $shortcode.trigger( 'ldmla_generate' );
            } )
            .on( 'ldmla.course_categories.select_all', function() {
                $course_categories.find( 'option' ).prop( 'selected', true );
            } );

        /* On change Materials per page. */
        $materials_per_page.on( 'change', function() {
            $shortcode.trigger( 'ldmla_generate' );
        } );

        /* Generate shortcode. */
        $shortcode.on( 'ldmla_generate', function() {
            var shortcode                   = $shortcode.data( 'shortcode' ),
                attr_course_category_id     = $course_categories.attr( 'name' ),
                course_category_id          = $course_categories.val().join( ',' ),
                attr_materials_per_page     = $materials_per_page.attr( 'name' ),
                materials_per_page          = Number( $materials_per_page.val() );

            if ( 
                ! $course_categories.is( ':disabled' ) &&
                $filter_by_course_categories.is( ':checked' )
            ) {
                shortcode = shortcode + ' ' + attr_course_category_id + '="' + course_category_id + '"';
            }

            if ( materials_per_page != 10 ) {
                shortcode = shortcode + ' ' + attr_materials_per_page + '="' + materials_per_page + '"';
            }

            shortcode = '[' + shortcode + ']';

            $shortcode.html( shortcode );
            $copy_shortcode.val( shortcode );
        } );

        /* On click Copy button. */
        $copy_button.on( 'click', function() {
            $copy_shortcode.select();
            document.execCommand( 'copy' );
            $copy_notice.show();

            setTimeout( function() {
                $copy_notice.hide();
            }, 1000 );
        } );
    } );
} );