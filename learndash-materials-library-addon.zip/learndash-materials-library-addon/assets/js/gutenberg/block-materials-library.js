import apiFetch from '@wordpress/api-fetch';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, SelectControl, TextControl, Disabled, ToggleControl } from '@wordpress/components';
import { useEffect } from '@wordpress/element';
import ServerSideRender from '@wordpress/server-side-render';

const courseCategories = [];

apiFetch( {
    method: 'GET',
    url: '/wp-json/ldma/v1/course_categories'
} ).then( data => {
    data.map( courseCategory => {
        courseCategories.push( {
            label: courseCategory.title,
            value: courseCategory.id
        } );
    } );
} );

const CourseCategoriesControlHelp = () => {
    return (
        <span>
            <span
                style={ { display: 'inline-block', margin: '0 0 5px' } }
            >
                { ldmlaBlockData.i18n.course_category_help_1 }
            </span>
            <br />
            <span
                style={ { display: 'inline-block' } }
            >
                { ldmlaBlockData.i18n.course_category_help_2 }
            </span>
        </span>
    )
}

const CourseCategoriesControl = props => {
    let { filterByCourseCategories, courseCategories, courseCategoryId, setAttributes } = props;
    let isDisabled = courseCategories.length == 0;
    let noCourseCategories = [];

    if ( isDisabled ) {
        noCourseCategories.push( { value: 0, label: ldmlaBlockData.i18n.no_course_categories } );
    }

    return (
        <div
            style={ { display: filterByCourseCategories == 'no' ? 'none' : 'block' } }
        >
            <Disabled isDisabled={ isDisabled }>
                <SelectControl
                    multiple
                    label={ ldmlaBlockData.i18n.course_category }
                    help={ <CourseCategoriesControlHelp /> }
                    options={ isDisabled ? noCourseCategories : courseCategories }
                    value={ courseCategoryId.length > 0 ? courseCategoryId : courseCategories.map( category => category.value.toString() ) }
                    onChange={ ( courseCategoryId ) => courseCategoryId.length > 0 ? setAttributes( { courseCategoryId } ) : false }
                    style={ { minHeight: '200px', paddingTop: '8px', paddingBottom: '8px' , paddingRight: '8px' } }
                />
            </Disabled>
        </div>
    )
}

registerBlockType( 'ldmla/materials-library', {
    apiVersion      : ldmlaBlockData.api_version,
    title           : ldmlaBlockData.title,
    description     : ldmlaBlockData.i18n.description,
    icon            : ldmlaBlockData.icon,
    category        : ldmlaBlockData.category,
    attributes      : ldmlaBlockData.attributes,
    example         : ldmlaBlockData.example,
    edit            : ( { attributes, setAttributes } ) => {
        const { filterByCourseCategories, courseCategoryId, materialsPerPage } = attributes;

        useEffect(() => {
            if ( ! filterByCourseCategories ) {
                setAttributes( { filterByCourseCategories : courseCategoryId.length > 0 ? 'yes' : 'no' } );
            }
        });

        return [
            <InspectorControls key="settings">
                <PanelBody
                    title={ ldmlaBlockData.i18n.settings }
                >

                    <ToggleControl
                        label={ ldmlaBlockData.i18n.filter_by_course_categories }
                        checked={ filterByCourseCategories == 'yes' }
                        onChange={ state => {
                            setAttributes( { filterByCourseCategories: state ? 'yes' : 'no'  } );
                            setAttributes( { courseCategoryId: state ? courseCategories.map( category => category.value.toString() ) : [] } );
                        } }
                    />

                    <CourseCategoriesControl
                        filterByCourseCategories={ filterByCourseCategories }
                        courseCategories={ courseCategories }
                        courseCategoryId={ courseCategoryId }
                        setAttributes={ setAttributes }
                    />

                    <TextControl
                        label={ ldmlaBlockData.i18n.materials_per_page }
                        value={ materialsPerPage }
                        autoComplete="off"
                        type="number"
                        min="1"
                        onChange={ materialsPerPage => setAttributes( { materialsPerPage: Number( materialsPerPage ) } ) }
                    />
                </PanelBody>
            </InspectorControls>,
            <div { ...useBlockProps() } key="form">
                <ServerSideRender
                    block="ldmla/materials-library"
                    attributes={ attributes }
                    key="ldmla/materials-library"
                />
            </div>
        ];
    }
} )