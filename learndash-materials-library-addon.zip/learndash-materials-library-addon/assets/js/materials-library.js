/* Custom select. */
jQuery( function( $ ) {
    var ldmla_select = function ( original_select, settings ) {
        /* Check if this is <select>. */
        if ( ! $( original_select ).is( 'select' ) ) {
            return;
        }

        /* Define vars. */
        var _this = this;
        _this.settings = $.extend( {
            no_matches : 'No matches found'
        }, settings );

        _this.$original_select          = $( original_select );
        _this.$original_select.$options = _this.$original_select.find( 'option' );
        _this.selected                  = _this.$original_select.$options.filter( ':selected' ).index();
        _this.data                      = [];
        _this.$select                   = null;
        _this.did_search                = false;
        _this.keydown_timeout           = null;

        /* Init. */
        _this.init = function() {
            _this.$original_select.$options.each( function( index ) {
                _this.data.push( { 
                    index: index, 
                    value: Number( $( this ).attr( 'value' ) ), 
                    title: $( this ).text() 
                } );
            } );

            _this.render();
        }

        /* Render custom select. */
        _this.render = function() {
            _this.$select               = $( '<div class="ldmla-select"></div>' );
            _this.$select.$display      = $( '<div class="ldmla-select__display"></div>' );
            _this.$select.$text         = $( '<div class="ldmla-select__text">' + _this.data[ _this.selected ].title + '</div>' );
            _this.$select.$dropdown     = $( '<div class="ldmla-select__dropdown"></div>' );
            _this.$select.$search       = $( '<div class="ldmla-select__search"></div>' );
            _this.$select.$input        = $( '<input class="ldmla-select__input" type="text">' );
            _this.$select.$list         = $( '<ul class="ldmla-select__list"></ul>' );
            _this.$select.$no_matches   = $( '<li class="ldmla-select__item ldmla-select__item--no-matches">' + _this.settings.no_matches + '</li>' );

            /* Add options to custom select. */
            _this.data.forEach( function( item, index ) {
                var $option = $( '<li/>', {
                        class   : 'ldmla-select__item' + ( _this.selected == item.index ? ' ldmla-select__item--selected' : '' ),
                        html    : item.title
                    } ).on( 'click', function() {
                        if ( _this.$original_select.$options.filter( ':selected' ).index() != index ) {
                            _this.selected = index;

                            _this.$select.$text.html( item.title );
                            _this.$select.$list.find( 'li.ldmla-select__item--selected' ).removeClass( 'ldmla-select__item--selected' );

                            $option
                                .addClass( 'ldmla-select__item--selected' )
                                .$ref.prop( 'selected', true );

                            _this.$original_select.trigger( 'change' );
                            _this.$original_select.trigger( 'ldmla_select:selected', item );
                        }
                    } );
                
                $option.$ref = _this.$original_select.$options.eq( index );

                _this.$select.$list.append( $option );
            } );

            _this.$select
                .append( _this.$select.$display.append( _this.$select.$text ) )
                .append( _this.$select.$dropdown.append( _this.$select.$search.append( _this.$select.$input ) ).append( _this.$select.$list ) )
                .insertAfter( _this.$original_select );

            /* Custom select actions. */
            _this.$select
                .on( 'click', function( e ) {
                    if ( ! _this.$select.is( '.ldmla-select--expanded' ) ) {
                        _this.$select.trigger( 'ldmla_select:show_dropdown' );
                    } else {
                        if ( ! $( e.target ).closest( _this.$select.$list ).length ) {
                            return;
                        }

                        _this.$select.trigger( 'ldmla_select:hide_dropdown' );
                    }
                } )
                .on( 'ldmla_select:show_dropdown', function() {
                    _this.$select
                        .addClass( 'ldmla-select--expanded' )
                        .$input.trigger( 'focus' );
                } )
                .on( 'ldmla_select:hide_dropdown', function() {
                    _this.$select
                        .removeClass( 'ldmla-select--expanded' )
                        .$input
                            .val( '' );

                        _this.reset_search();
                } );

            $( document ).on( 'click', function( e ) {
                if ( $( e.target ).closest( _this.$select ).length ) {
                    return;
                }

                _this.$select.trigger( 'ldmla_select:hide_dropdown' );
            } );

            _this.$select.$input.on( 'keyup paste', function() {
                _this.do_search();
            } );

            _this.$original_select.hide();
        }

        /* Search for options by a text. */
        _this.do_search = function() {
            clearTimeout( _this.keydown_timeout );

            _this.keydown_timeout = setTimeout( function() {
                var text            = _this.$select.$input.val().trim(),
                    found_matches   = 0;

                _this.reset_search();

                _this.data.map( function( item ) {
                    if ( item.title.toLowerCase().indexOf( text.toLowerCase() ) == -1 ) {
                        _this.$select.$list.find( 'li' ).eq( item.index ).addClass( 'ldmla-select__item--hidden' );
                    } else {
                        found_matches++;
                    }
                } );

                if ( ! found_matches ) {
                    _this.$select
                        .$no_matches.on( 'click', function( e ) {
                            e.preventDefault();
                            e.stopPropagation();
                        } )
                        .appendTo( _this.$select.$list );
                }

                _this.did_search = true;
            }, 300 );
        }

        /* Reset search results. */
        _this.reset_search = function() {
            if ( _this.did_search ) {
                _this.$select.$list.find( 'li.ldmla-select__item--hidden' ).removeClass( 'ldmla-select__item--hidden' );
                _this.$select.$list.find( 'li.ldmla-select__item--no-matches' ).remove();

                _this.did_search = false;
            }
        }

        _this.init();
    }

    var methods = {
        init: function( options ) {
            return this.each(function() {
                new ldmla_select( this, options );
            });
        }
    };

    $.fn.ldmla_select = function( method ) {
        if ( methods[ method ] ) {
            return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ) );
        } else if ( typeof method === 'object' || ! method ) {
            return methods.init.apply( this, arguments );
        } else {
            $.error( 'There is no method with name ' +  method );
        }
    };
} );

/* Materials form. */
jQuery( function( $ ) {
    if ( 'undefined' === typeof ldmla_data ) {
        return false;
    }

    var materials_library = function( container, settings ) {
        /* Check if this is Materials form. */
        if ( ! $( container ).is( '.js-ldmla-materials-library' ) ) {
            return;
        }

        /* Define vars. */
        var _this = this;
        _this.$container            = $( container );
        _this.$course               = _this.$container.find( '.js-ldmla-materials-library-course' );
        _this.$search               = _this.$container.find( '.js-ldmla-materials-library-search' );
        _this.$course_category_id   = _this.$container.find( '.js-ldmla-materials-library-course-category-id' );
        _this.$page                 = _this.$container.find( '.js-ldmla-materials-library-page' );
        _this.$per_page             = _this.$container.find( '.js-ldmla-materials-library-per-page' );
        _this.$content              = _this.$container.find( '.js-ldmla-materials-library-content' );
        _this.$materials            = _this.$container.find( '.js-ldmla-materials-library-materials' );
        _this.$doing_ajax           = $( '<div/>', {
            class: 'ldmla-materials-library__doing-ajax ldmla-materials-library-doing-ajax',
            html: '<div class="ldmla-materials-library-doing-ajax__content">' + ldmla_data.i18n.loading_materials + '</div>'
        });
        _this.doing_ajax        = false;
        _this.loading_delay     = 400;
        _this.search_delay      = null;

        /* Init. */
        _this.init = function() {
            $( _this.$course )
                .ldmla_select( {
                    no_matches: ldmla_data.i18n.no_matches
                } )
                .on( 'ldmla_select:selected', function( e, option ) {
                        _this.$page.val( '1' );
                        _this.do_ajax();
                } );
                
            $( _this.$search )
                .on( 'keyup paste', function( e ) {
                    if ( _this.doing_ajax ) {
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    };

                    clearTimeout( _this.search_delay );

                    _this.search_delay = setTimeout( function() {
                        _this.$page.val( '1' );
                        _this.do_ajax();
                    }, 600 );
                } ).on( 'keydown', function( e ) {
                    if ( _this.doing_ajax ) {
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    };
                } );

            _this.$container.on( 'click', '.js-ldmla-materials-library-pagination a', function( e ) {
                e.preventDefault();
                _this.$page.val( $( this ).data( 'page' ) );
                _this.do_ajax();
            } );
        }

        _this.start_doing_ajax = function( callback ) {
            _this.doing_ajax = true;
            _this.$container.addClass( 'ldmla-doing-ajax' );
            _this.$doing_ajax.appendTo( _this.$content );

            if ( typeof( callback ) == 'function' ) {
                callback();
            }
        }

        _this.stop_doing_ajax = function( callback ) {
            setTimeout( function() {
                _this.$doing_ajax.remove();
                _this.$container.removeClass( 'ldmla-doing-ajax' );
                _this.doing_ajax = false;

                if ( typeof( callback ) == 'function' ) {
                    callback();
                }
            }, _this.loading_delay );
        }

        /* Do ajax. */
        _this.do_ajax = function() {
            $.ajax({
                method      : 'post',
                url         : ldmla_data.ajax_url,
                dataType    : 'json',
                data        : {
                    action  : ldmla_data.ajax_action,
                    nonce   : ldmla_data.ajax_nonce,
                    args    : {
                        course_id           : _this.$course.val(),
                        search              : _this.$search.val().trim(),
                        course_category_id  : _this.$course_category_id.val(),
                        page                : _this.$page.val(),
                        materials_per_page  : _this.$per_page.val()
                    }
                },
                beforeSend: function() {
                    _this.start_doing_ajax();
                },
                success: function( response ) {
                    _this.stop_doing_ajax( function() {
                        _this.$materials.empty();
                        $( response.course_materials ).appendTo( _this.$materials );
                    } );

                },
                error: function( xhr, status, error ) {
                    _this.stop_doing_ajax( function() {
                        var data = JSON.parse( xhr.responseText );
                        alert( data.message );
                    } );
                },
            });
        }

        _this.init();
    }

    var methods = {
        init: function( options ) {
            return this.each(function() {
                new materials_library( this, options );
            });
        }
    };

    $.fn.materials_library = function( method ) {
        if ( methods[ method ] ) {
            return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ) );
        } else if ( typeof method === 'object' || ! method ) {
            return methods.init.apply( this, arguments );
        } else {
            $.error( 'There is no method with name ' +  method );
        }
    };
} );

/* Frontend functions. */
jQuery( function( $ ) {
    $( document ).ready( function() {
        $( '.js-ldmla-materials-library' ).materials_library();
    } );
} );