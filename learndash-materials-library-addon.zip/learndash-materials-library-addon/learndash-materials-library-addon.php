<?php
/**
 * Plugin Name: LearnDash Materials Library Add-on
 * Plugin URI: 
 * Description: Materials Library Add-on for LearnDash
 * Version: 1.0.2
 * Text Domain: learndash-materials-library-addon
 * Author: Wooninjas
 * Author URI: https://wooninjas.com
 * Requires at least: 5.0
 * Tested up to: 5.8
 * Requires PHP: 5.6
 */

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

require_once 'vendor/autoload.php';

if ( ! function_exists( 'get_plugin_data' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$plugin_data = get_plugin_data( __FILE__ );

/* Define constants. */
! defined( 'LDMLA_VERSION' )                   && define( 'LDMLA_VERSION', $plugin_data['Version'] );
! defined( 'LDMLA_NAME' )                      && define( 'LDMLA_NAME', $plugin_data['Name'] );
! defined( 'LDMLA_ASSETS_SUFFIX' )             && define( 'LDMLA_ASSETS_SUFFIX', ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG === true ? '' : '.min' ) );

! defined( 'LDMLA_FILE' )                      && define( 'LDMLA_FILE', __FILE__ );
! defined( 'LDMLA_URL' )                       && define( 'LDMLA_URL', plugins_url( '', LDMLA_FILE ) );
! defined( 'LDMLA_URL_ASSETS' )                && define( 'LDMLA_URL_ASSETS', LDMLA_URL . '/assets' );
! defined( 'LDMLA_URL_ASSETS_CSS' )            && define( 'LDMLA_URL_ASSETS_CSS', LDMLA_URL_ASSETS . '/css' );
! defined( 'LDMLA_URL_ASSETS_JS' )             && define( 'LDMLA_URL_ASSETS_JS', LDMLA_URL_ASSETS . '/js' );
! defined( 'LDMLA_URL_ASSETS_IMAGES' )         && define( 'LDMLA_URL_ASSETS_IMAGES', LDMLA_URL_ASSETS . '/images' );
! defined( 'LDMLA_PATH' )                      && define( 'LDMLA_PATH', dirname( LDMLA_FILE ) );
! defined( 'LDMLA_PATH_ASSETS' )               && define( 'LDMLA_PATH_ASSETS', LDMLA_PATH . '/assets' );
! defined( 'LDMLA_PATH_ASSETS_IMAGES' )        && define( 'LDMLA_PATH_ASSETS_IMAGES', LDMLA_PATH_ASSETS . '/images' );
! defined( 'LDMLA_PATH_INCLUDES' )             && define( 'LDMLA_PATH_INCLUDES', LDMLA_PATH . '/includes' );
! defined( 'LDMLA_PATH_TEMPLATES' )            && define( 'LDMLA_PATH_TEMPLATES', LDMLA_PATH . '/templates' );

if ( ! class_exists( 'LearnDash_Materials_Library_Addon' ) ) {
    class LearnDash_Materials_Library_Addon {
        /**
         * Init plugin.
         *
         * @return void
         */
        public function __construct() {
            new LDMLA\Init;
        }
    }
}

new LearnDash_Materials_Library_Addon;