<?php

namespace LDMLA;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Library;
use LDMLA\Classes\Materials_Accessibility;
use LDMLA\Classes\Data_Helpers;
use LDMLA\Classes\Template;

class Frontend {
    use \LDMLA\Traits\Singleton_Trait;

    /**
     * @var string Ajax action.
     */
    const AJAX_ACTION = 'ldmla_ajax_materials_library';

    /**
     * @var string Rewrite endpoint.
     */
    const REWRITE_ENDPOINT = 'ldmla-download-material';

    /**
     * @var string Shortcode.
     */
    const SHORTCODE = 'ldmla_materials_library';

    /**
     * Constructor
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'init', array( $this, 'register_rewrite_endpoint' ) );
        add_action( 'template_redirect', array( $this, 'download_material' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
        add_shortcode( self::SHORTCODE, array( $this, 'do_shortcode' ) );
        add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'do_ajax' ) );
        add_action( 'wp_ajax_nopriv_' . self::AJAX_ACTION, array( $this, 'do_ajax' ) );
    }

    /**
     * Add rewrite endpoint.
     * 
     * @return void
     */
    public function register_rewrite_endpoint() {
        add_rewrite_endpoint( self::REWRITE_ENDPOINT, EP_ROOT, true );
        flush_rewrite_rules();
    }

    /**
     * Download material.
     * 
     * @return void
     */
    public function download_material() {
        global $wp, $wp_query;

        $is_download = false;

        /* Check if it's a download action. */
        if ( get_option( 'permalink_structure' ) != '' && strtok( $wp->request, '/' ) == self::REWRITE_ENDPOINT ) {
            $is_download = true;
        } elseif ( get_option( 'permalink_structure' ) == '' && strpos( $wp->query_string, self::REWRITE_ENDPOINT ) !== false ) {
            $is_download = true;
        }

        if ( $is_download ) {
            $query_var = get_query_var( self::REWRITE_ENDPOINT );

            /* Check the download args. */
            if ( $query_var ) {
                $download_args      = json_decode( Data_Helpers::decrypt_string( $query_var ), true );
                $attachment_id      = ! empty( $download_args['attachment_id'] ) ? ( int ) $download_args['attachment_id'] : 0;
                $course_id          = ! empty( $download_args['course_id'] ) ? ( int ) $download_args['course_id'] : 0;
                $hash               = ! empty( $download_args['hash'] ) ? $download_args['hash'] : '';
                $data_to_hash       = json_encode( array_diff_key( $download_args, array_flip( array( 'hash' ) ) ) );

                if ( $attachment_id && $course_id && $hash && hash_equals( $hash, Data_Helpers::get_hash_hmac( $data_to_hash ) ) ) {
                    if ( ! Materials_Accessibility::is_course_accessible( $course_id ) ) {
                        wp_die( 
                            __( 'You are not allowed to download this material.', 'learndash-materials-library-addon' ),
                            __( 'Downloading material', 'learndash-materials-library-addon' ),
                            array( 
                                'response'      => 403,
                                'back_link'     => true,
                            )
                        );
                        exit;
                    }

                    $path = get_attached_file( $attachment_id );

                    if ( file_exists( $path ) ) {
                        header( 'Content-Disposition: attachment; filename="' . basename( $path ) . '"' );
                        readfile( $path );
                        exit;
                    }
                }
            }

            $wp_query->set_404();
            status_header( 404 );
            get_template_part( 404 );
            exit;
        }
    }

    /**
     * Enqueue frontend assets.
     * 
     * @return void
     */
    public static function frontend_assets() {
        wp_enqueue_style( 'ldmla-materials-library-font', 'https://fonts.googleapis.com/css2?family=Poppins&display=swap' );
        wp_enqueue_style( 'ldmla-materials-library', LDMLA_URL_ASSETS_CSS . '/materials-library' . LDMLA_ASSETS_SUFFIX . '.css', array( 'ldmla-materials-library-font' ), LDMLA_VERSION );

        wp_enqueue_script( 'ldmla-materials-library', LDMLA_URL_ASSETS_JS .'/materials-library' . LDMLA_ASSETS_SUFFIX . '.js', array( 'jquery' ), LDMLA_VERSION, true );
        wp_localize_script( 'ldmla-materials-library', 'ldmla_data', array(
            'ajax_url'      => admin_url( 'admin-ajax.php' ),
            'ajax_nonce'    => wp_create_nonce( self::AJAX_ACTION ),
            'ajax_action'   => self::AJAX_ACTION,
            'i18n'          => array(
                'no_matches'            => __( 'No matches found', 'learndash-materials-library-addon' ),
                'loading_materials'     => __( 'Loading materials...', 'learndash-materials-library-addon' )
            )
        ) );
    }

    /**
     * Output the materials' form by the shortcode.
     * 
     * @param string $atts Shortcode attributes.
     * 
     * @return string $template_form HTML of the materials' form.
     */
    public function do_shortcode( $atts ) {
        $atts = shortcode_atts( array(
            'course_category_id'    => '',
            'materials_per_page'    => 10
        ), $atts );

        $course_category_id         = ! empty( $atts['course_category_id'] ) ? explode( ',', str_replace( ' ', '', $atts['course_category_id'] ) ) : array();
        $course_category_id         = array_map( 'intval', $course_category_id );
        $materials_per_page         = ( int ) $atts['materials_per_page'];
        $courses                    = Materials_Library::get_courses( compact( 'course_category_id' ) );
        $course_materials           = Materials_Library::get_materials( compact( 'course_category_id' ) );
        $page                       = 1;
        $total_course_materials     = count( $course_materials );
        $pagination                 = $this->get_pagination( $page, $materials_per_page, $total_course_materials );
        $course_materials           = array_slice( $course_materials, 0, $materials_per_page );
        $template_materials         = Template::get( 'form-materials.php', compact( 'course_materials', 'pagination', 'page', 'materials_per_page', 'total_course_materials' ) );
        $template_form              = Template::get( 'form.php', compact( 'courses', 'course_category_id', 'page', 'materials_per_page', 'template_materials' ) );

        return $template_form;
    }

    /**
     * Get pagination by params.
     * 
     * @param string $page Current page.
     * @param string $items_per_page Items per page.
     * @param string $total_items Total items.
     * 
     * @return string HTML of the pagination.
     */
    public function get_pagination( $page, $items_per_page, $total_items ) {
        $pagination = '';

        $args = array(
            'base'          => '%_%',
            'format'        => '#page%#%',
            'type'          => 'array',
            'current'       => max( 1, $page ),
            'total'         => ceil( $total_items / $items_per_page ),
            'end_size'      => 1,
            'mid_size'      => 1,
            'prev_next'     => true,
            'prev_text'     => __( 'Previous page', 'learndash-materials-library-addon' ),
            'next_text'     => __( 'Next page', 'learndash-materials-library-addon' )
        );

        $pagination_items = paginate_links( $args );

        if ( $pagination_items ) {
            foreach ( $pagination_items as $key => &$pagination_item ) {
                $pagination_item = str_replace( 'page-numbers', 'ldmla-materials-library-pagination__item', $pagination_item );
                $pagination_item = preg_replace( '/(<a.+href="#page)([\d]+)(.+?)(>.+<\/a>)/i', '$1$2$3 data-page="$2"$4', $pagination_item );
                $pagination_item = preg_replace( '/(#page[\d]+)/i', '#', $pagination_item );

                if ( substr( $pagination_item, 0, 2 ) == '<a' && ! preg_match( '/data-page/', $pagination_item ) ) {
                    $pagination_item = preg_replace( '/(<a.+?)>(.+<\/a>)/i', '$1 data-page="1">$2', $pagination_item );
                }
            }

            $pagination = implode( '', $pagination_items );
        }

        return $pagination;
    }

    /**
     * Do an ajax request.
     * 
     * @return string Response of an ajax request.
     */
    public function do_ajax() {
        $nonce = isset( $_POST['nonce'] ) ? $_POST['nonce'] : '';

        if ( ! wp_verify_nonce( $nonce, self::AJAX_ACTION ) ) {
            wp_send_json( array( 'message' => __( 'A security error has occurred. Please refresh the page and try again.', 'learndash-materials-library-addon' ) ), 403 );
        }

        $args = isset( $_POST['args'] ) && is_array( $_POST['args'] ) ? $_POST['args'] : array();

        if ( ! $args || ! isset( $args['course_id'] ) || ! isset( $args['search'] ) || ! isset( $args['course_category_id'] ) || ! isset( $args['page'] ) || ! isset( $args['materials_per_page'] ) ) {
            wp_send_json( array( 'message' => __( 'An error has occurred. Missing some data. Please refresh the page and try again.', 'learndash-materials-library-addon' ) ), 404 );
        }

        $course_category_id         = ! empty( $args['course_category_id'] ) ? explode( ',', str_replace( ' ', '', $args['course_category_id'] ) ) : array();
        $course_category_id         = array_map( 'intval', $course_category_id );
        $course_id                  = ( int ) $args['course_id'];
        $search                     = esc_html( $args['search'] );
        $courses                    = Materials_Library::get_courses( compact( 'course_category_id' ) );
        $course_materials           = Materials_Library::get_materials( compact( 'course_category_id', 'course_id', 'search' ) );
        $page                       = ( int ) $args['page'];
        $materials_per_page         = ( int ) $args['materials_per_page'];
        $total_course_materials     = count( $course_materials );
        $pagination                 = $this->get_pagination( $page, $materials_per_page, $total_course_materials );
        $offset                     = ( $page - 1 ) * $materials_per_page;
        $course_materials           = array_slice( $course_materials, $offset, $materials_per_page );
        $template_materials         = Template::get( 'form-materials.php', compact( 'course_materials', 'pagination', 'page', 'materials_per_page', 'total_course_materials' ) );

        $response = array(
            'course_materials' => $template_materials
        );

        wp_send_json( $response, 200 );
    }
}
