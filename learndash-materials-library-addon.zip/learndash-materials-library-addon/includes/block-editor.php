<?php

namespace LDMLA;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Endpoint;
use LDMLA\Frontend;

class Block_Editor {
    use \LDMLA\Traits\Singleton_Trait;

    /**
     * @var string Default course category ID.
     */
    const DEFAULT_COURSE_CATEGORY_ID = array();

    /**
     * @var string Default materials per page.
     */
    const DEFAULT_MATERIALS_PER_PAGE = 10;

    /**
     * @var string Block editor args.
     */
    private $args = array();

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        $this->args = $this->get_args();

        Endpoint::get_instance();

        add_action( 'enqueue_block_editor_assets', array( $this, 'admin_assets' ) );
        add_action( 'enqueue_block_assets', array( $this, 'frontend_assets' ) );
        add_action( 'init', array( $this, 'register_block_editor' ), 12 );
    }

    /**
     * Get the block editor args.
     * 
     * @return array Args of the block editor.
     */
    private function get_args() {
        return array(
            'api_version'       => 2,
            'title'             => 'LearnDash Materials Library [' . Frontend::SHORTCODE . ']',
            'icon'              => 'list-view',
            'category'          => 'learndash-blocks',
            'attributes'        => array(
                'filterByCourseCategories' => array(
                    'type'      => 'string',
                    'default'   => ''
                ),
                'courseCategoryId' => array(
                    'type'      => 'array',
                    'default'   => self::DEFAULT_COURSE_CATEGORY_ID
                ),
                'materialsPerPage' => array(
                    'type'      => 'number',
                    'default'   => self::DEFAULT_MATERIALS_PER_PAGE
                )
            ),
            'example'           => array(
                'attributes'    => array(
                    'courseCategoryId'      => self::DEFAULT_COURSE_CATEGORY_ID,
                    'materialsPerPage'      => self::DEFAULT_MATERIALS_PER_PAGE
                )
            ),
            'render_callback'   => array( $this, 'render_block_editor' )
        );
    }

    /**
     * Enqueue admin assets.
     * 
     * @return void
     */
    public function admin_assets() {
        $asset_file = include( dirname( LDMLA_FILE ) . '/assets/js/gutenberg/build/index.asset.php' );
        $block_data = array_merge( $this->args, array(
            'i18n'                                  => array(
                'description'                       => __( 'This block displays Course materials', 'learndash-materials-library-addon' ),
                'settings'                          => __( 'Settings', 'learndash-materials-library-addon' ),
                'course_category'                   => __( 'Course categories', 'learndash-materials-library-addon' ),
                'filter_by_course_categories'       => __( 'Filter by course categories', 'learndash-materials-library-addon' ),
                'no_course_categories'              => __( 'No course categories', 'learndash-materials-library-addon' ),
                'course_category_help_1'            => __( 'Use Ctrl+click to select/deselect multiple Course categories.', 'learndash-materials-library-addon' ),
                'course_category_help_2'            => __( 'Materials will only be shown in the selected Course categories.', 'learndash-materials-library-addon' ),
                'materials_per_page'                => __( 'Materials per page', 'learndash-materials-library-addon' )
            )
        ) );

        unset( $block_data['render_callback'] );

        wp_enqueue_script( 'ldmla-materials-library-admin', plugins_url( 'assets/js/gutenberg/build/index.js', LDMLA_FILE ), $asset_file['dependencies'], $asset_file['version'], true );
        wp_localize_script( 'ldmla-materials-library-admin', 'ldmlaBlockData', $block_data );
    }

    /**
     * Enqueue frontend assets.
     * 
     * @return void
     */
    public function frontend_assets() {
        Frontend::frontend_assets();
    }

    /**
     * Register block editor.
     * 
     * @return void
     */
    public function register_block_editor() {
        register_block_type( 'ldmla/materials-library', $this->args );
    }

    /**
     * Render block editor.
     * 
     * @return void
     */
    public function render_block_editor( $attributes, $content ) {
        $shortcode = sprintf( '[%s course_category_id="%s" materials_per_page="%s"]', Frontend::SHORTCODE, implode( ',', $attributes['courseCategoryId']  ), $attributes['materialsPerPage'] );

        return do_shortcode( $shortcode );
    }
}