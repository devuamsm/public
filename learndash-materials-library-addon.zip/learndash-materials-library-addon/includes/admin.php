<?php

namespace LDMLA;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Library;
use LDMLA\Classes\Template;
use LDMLA\Block_Editor;
use LDMLA\Frontend;

class Admin {
    use \LDMLA\Traits\Singleton_Trait;

    /**
     * @var string Admin page slug.
     */
    const ADMIN_PAGE_SLUG = 'ldmla-materials-library';

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ), 11 );
        add_filter( 'plugin_action_links', array( $this, 'plugin_action_links' ), 10, 4 );
    }

    /**
     * Add an item to LearnDash admin menu.
     * 
     * @return void
     */
    public function admin_menu() {
        $admin_page = add_submenu_page( 'learndash-lms', 'Materials Library', 'Materials Library', 'manage_options', self::ADMIN_PAGE_SLUG, array( $this, 'render_admin_page' ) );
        add_action( 'load-' . $admin_page, array( $this, 'admin_page_assets' ) );
    }

    /**
     * Enqueue admin page assets.
     * 
     * @return void
     */
    public static function admin_page_assets() {
        wp_enqueue_style( 'ldmla-admin-page', LDMLA_URL_ASSETS_CSS . '/admin-page' . LDMLA_ASSETS_SUFFIX . '.css', LDMLA_VERSION );
        wp_enqueue_script( 'ldmla-admin-page', LDMLA_URL_ASSETS_JS . '/admin-page' . LDMLA_ASSETS_SUFFIX . '.js', array( 'jquery' ), LDMLA_VERSION, true );
    }

    /**
     * Render admin page.
     * 
     * @return void
     */
    public function render_admin_page() {
        $shortcode              = Frontend::SHORTCODE;
        $course_categories      = Materials_Library::get_course_categories();
        $is_disabled            = count( $course_categories ) == 0;
        $materials_per_page     = Block_Editor::DEFAULT_MATERIALS_PER_PAGE;

        if ( $is_disabled ) {
            $course_categories[] = array(
                'id'        => 0,
                'title'     => __( 'No course categories', 'learndash-materials-library-addon' )
            );
        }

        $data = compact( 'shortcode', 'course_categories', 'is_disabled', 'materials_per_page' );

        Template::render( 'admin-page.php', $data );
    }

    /**
     * Add an item to the plugin action links.
     * 
     * @param array $actions Current plugin actions.
     * @return string $plugin_file Current plugin file.
     * @return array $plugin_data Current plugin data.
     * @return string $context Current plugins.php page tab.
     * 
     * @return array $actions Edited plugin actions.
     */
    public function plugin_action_links( $actions, $plugin_file, $plugin_data, $context ) {
        if ( plugin_basename( LDMLA_FILE ) == $plugin_file ) {
            $settings_link = sprintf( '<a href="%s">%s</a>', esc_url( add_query_arg( 'page', self::ADMIN_PAGE_SLUG, admin_url( 'admin.php' ) ) ), __( 'Settings', 'learndash-materials-library-addon' ) );
            array_unshift( $actions, $settings_link );
        }

        return $actions;
    }
}
