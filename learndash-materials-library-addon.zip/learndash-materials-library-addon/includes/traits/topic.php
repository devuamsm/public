<?php

namespace LDMLA\Traits;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

trait Topic_Trait {
    /**
     * @var int Topic ID.
     */
    private $topic_id = 0;

    /**
     * Get topic ID.
     *
     * @return int Topic ID.
     */
    public function get_topic_id() {
        return $this->topic_id;
    }
}