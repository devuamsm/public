<?php

namespace LDMLA\Traits;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

trait Quiz_Trait {
    /**
     * @var int Quiz ID.
     */
    private $quiz_id = 0;

    /**
     * Get quiz ID.
     *
     * @return int Quiz ID.
     */
    public function get_quiz_id() {
        return $this->quiz_id;
    }
}