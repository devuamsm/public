<?php

namespace LDMLA\Traits;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

trait Lesson_Trait {
    /**
     * @var int Lesson ID.
     */
    private $lesson_id = 0;

    /**
     * Get lesson ID.
     *
     * @return int Lesson ID.
     */
    public function get_lesson_id() {
        return $this->lesson_id;
    }
}