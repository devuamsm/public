<?php

namespace LDMLA\Traits;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

trait Course_Trait {
    /**
     * @var int Course ID.
     */
    private $course_id = 0;

    /**
     * Get course ID.
     *
     * @return int Course ID.
     */
    public function get_course_id() {
        return $this->course_id;
    }
}