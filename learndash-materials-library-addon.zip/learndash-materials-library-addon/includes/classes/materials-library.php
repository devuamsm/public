<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Collector;

class Materials_Library {
    /**
     * @var string Taxonomy courses category.
     */
    const TAXONOMY_COURSES_CATEGORY = 'ld_course_category';

    /**
     * Get all courses.
     *
     * @return array Courses.
     */
    public static function get_courses( $args = array() ) {
        $courses_args = array();

        if ( ! empty( $args['course_category_id'] ) ) {
            $courses_args['tax_query'] = array(
                array(
                    'taxonomy'          => self::TAXONOMY_COURSES_CATEGORY,
                    'terms'             => $args['course_category_id'],
                    'include_children'  => true
                )
            );
        }

        if ( ! empty( $args['course_id'] ) ) {
            $courses_args['post__in'] = ( array ) $args['course_id'];
        }


        return self::get_courses_by_args( $courses_args );
    }

    /**
     * Get course categories.
     *
     * @return array Courses categories.
     */
    public static function get_course_categories() {
        $course_categories = array();

        $terms = get_terms( array(
            'taxonomy'      => self::TAXONOMY_COURSES_CATEGORY,
            'fields'        => 'id=>name',
            'hide_empty'    => false
        ) );

        if ( $terms ) {
            foreach ( $terms as $id => $name ) {
                $course_categories[] = array(
                    'id'        => $id,
                    'title'     => $name
                );
            }
        }

        return $course_categories;
    }

    /**
     * Get materials.
     * 
     * @return array Materials.
     */
    public static function get_materials( $args = array() ) {
        $materials_args = wp_parse_args (
            $args,
            array(
                'course_category_id'    => 0,
                'course_id'             => 0,
                'search'                => ''
            )
        );

        $courses    = self::get_courses( $materials_args );
        $search     = $materials_args['search'];
        $materials  =  array();

        foreach ( $courses as $course ) {
            $materials_collector = new Materials_Collector( $course['id'], $search );
            $materials = array_merge( $materials, $materials_collector->get_materials() );
        }

        return $materials;
    }

    /**
     * Get courses by args.
     *
     * @return array Courses.
     */
    private static function get_courses_by_args( $args = array() ) {
        $courses    = array();
        $args       = wp_parse_args(
            array(
                'post_type'         => learndash_get_post_type_slug( 'course' ),
                'post_status'       => 'publish',
                'numberposts'       => -1,
                'orderby'           => 'ID',
                'order'             => 'DESC',
                'suppress_filters'  => true
            ),
            $args
        );

        $posts = get_posts( $args );

        if ( $posts ) {
            foreach ( $posts as $post ) {
                $courses[] = array(
                    'id'    => $post->ID,
                    'title' => $post->post_title
                );
            }
        }

        return $courses;
    }
}