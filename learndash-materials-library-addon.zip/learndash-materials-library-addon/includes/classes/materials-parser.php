<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

abstract class Materials_Parser {
    /**
     * @var string Materials.
     */
    private $materials = array();

    /**
     * Constructor.
     * 
     * @param string $content Source content.
     * 
     * @return void
     */
    public function __construct( $content ) {
        $content = apply_filters( 'ldmla_parser_parse_content', $content, $this->get_parser_type() );

        $this->parse_content( $content );
    }

    /**
     * Parse content.
     * 
     * @param string $content Source content.
     * 
     * @return void
     */
    abstract protected function parse_content( $content );


    /**
     * Get parser type.
     * 
     * @return string Parser type.
     */
    final public function get_parser_type() {
        $class_name = explode( '\\', get_called_class() );

        return array_pop( $class_name );
    }

     /**
      * Add material.
      *
      * @param string $string Parsed string.
      * @param string $title Material title.
      * @param string $url Material URL.
      *
      * @return void
      */
    final protected function add_material( $string, $title, $url ) {
        if ( ! $url ) {
            return;
        }

        $parser_type = $this->get_parser_type();

        $this->materials[] = apply_filters( 'ldmla_parser_add_material', compact( 'parser_type', 'string', 'title', 'url' ) );
    }

    /**
     * Get materials.
     * 
     * @return array Materials.
     */
    final public function get_materials() {
        return apply_filters( 'ldmla_parser_get_materials', $this->materials );
    }
}