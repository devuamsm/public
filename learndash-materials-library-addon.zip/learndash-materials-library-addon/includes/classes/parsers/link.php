<?php

namespace LDMLA\Classes\Parsers;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Parser;

class Link_Parser extends Materials_Parser {
    /**
     * Parse content.
     * 
     * @param string $content Source content.
     * 
     * @return void
     */
    protected function parse_content( $content ) {
        /* Parse all course materials links. */
        preg_match_all( '/(<a*[^>]*>.*?<\/a>)/m', $content, $link_matches );

        /* If course materials links exist. */
        if ( $link_matches[0] ) {
            foreach( $link_matches[0] as $link_match ) {
                /* Parse a course materials link. */
                preg_match( '/<a.*href="(.*?)".*?>(.*)<\/a>/', $link_match, $atts_matches );

                if ( $atts_matches ) {
                    list( $link, $url, $title ) = $atts_matches;

                    $title = trim( wp_strip_all_tags( $title ) );

                    $this->add_material( $link, $title, $url );
                }
            }
        }
    }
}