<?php

namespace LDMLA\Classes\Parsers;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Parser;

class Playlist_Parser extends Materials_Parser {
    protected function parse_content( $content ) {
        /**
         * Parse content.
         * 
         * @param string $content Source content.
         * 
         * @return void
         */
        if ( has_shortcode( $content, 'playlist' ) ) {
            preg_match_all( '/(\[playlist.*\])/m', $content, $shortcode_matches );

            if ( $shortcode_matches[0] ) {
                $url = '';

                foreach( $shortcode_matches[0] as $shortcode_match ) {
                    preg_match( '/\[playlist(.*?)\]((.*?)\[\/playlist\])?/', $shortcode_match, $atts_matches );

                    if ( ! empty( $atts_matches[1] ) ) {
                        $shortcode_atts = shortcode_parse_atts( $atts_matches[1] );

                        if ( ! empty( $shortcode_atts['ids'] ) ) {
                            $attachment_ids = explode(',', str_replace(' ', '', $shortcode_atts['ids'] ) );

                            foreach( $attachment_ids as $attachment_id ) {
                                $this->add_material( $shortcode_match, get_the_title( $attachment_id ), wp_get_attachment_url( $attachment_id ) );
                            }
                        }
                    }
                }
            }
        }
    }
}