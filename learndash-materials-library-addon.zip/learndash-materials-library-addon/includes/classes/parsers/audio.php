<?php

namespace LDMLA\Classes\Parsers;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Parser;

class Audio_Parser extends Materials_Parser {
    /**
     * Parse content.
     * 
     * @param string $content Source content.
     * 
     * @return void
     */
    protected function parse_content( $content ) {
        if ( has_shortcode( $content, 'audio' ) ) {
            preg_match_all( '/(\[audio.*\])/m', $content, $shortcode_matches );

            if ( $shortcode_matches[0] ) {
                $url = '';

                foreach( $shortcode_matches[0] as $shortcode_match ) {
                    preg_match( '/\[audio(.*?)\]((.*?)\[\/audio\])?/', $shortcode_match, $atts_matches );

                    if ( ! empty( $atts_matches[1] ) ) {
                        $shortcode_atts = shortcode_parse_atts( $atts_matches[1] );

                        if ( ! isset( $shortcode_atts['src'] ) ) {
                            $default_audio_extensions   = wp_get_audio_extensions();
                            $audio_atts                 = array_intersect_key( $shortcode_atts, array_flip( $default_audio_extensions ) );

                            if ( $audio_atts ) {
                                $url = current( $audio_atts );
                            }
                        } else {
                            $url = $shortcode_atts['src'];
                        }
                    }

                    $this->add_material( $shortcode_match, '', $url );
                }
            }
        }
    }
}