<?php

namespace LDMLA\Classes\Parsers;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Parser;

class Video_Parser extends Materials_Parser {
    /**
     * Parse content.
     * 
     * @param string $content Source content.
     * 
     * @return void
     */
    protected function parse_content( $content ) {
        if ( has_shortcode( $content, 'video' ) ) {
            preg_match_all( '/(\[video.*\])/m', $content, $shortcode_matches );

            if ( $shortcode_matches[0] ) {
                $url = '';

                foreach( $shortcode_matches[0] as $shortcode_match ) {
                    preg_match( '/\[video(.*?)\]((.*?)\[\/video\])?/', $shortcode_match, $atts_matches );

                    if ( ! empty( $atts_matches[1] ) ) {
                        $shortcode_atts = shortcode_parse_atts( $atts_matches[1] );

                        if ( ! isset( $shortcode_atts['src'] ) ) {
                            $default_video_extensions   = wp_get_video_extensions();
                            $video_atts                 = array_intersect_key( $shortcode_atts, array_flip( $default_video_extensions ) );

                            if ( $video_atts ) {
                                $url = current( $video_atts );
                            }
                        } else {
                            $url = $shortcode_atts['src'];
                        }
                    }

                    $this->add_material( $shortcode_match, '', $url );
                }
            }
        }
    }
}