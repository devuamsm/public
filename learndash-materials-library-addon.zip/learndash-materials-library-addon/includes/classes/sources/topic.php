<?php

namespace LDMLA\Classes\Sources;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Source;

class Topic_Source extends Materials_Source {
    use \LDMLA\Traits\Course_Trait;
    use \LDMLA\Traits\Lesson_Trait;
    use \LDMLA\Traits\Topic_Trait;

    /**
     * Constructor.
     * @param int $course_id Cource ID.
     * @param int $lesson_id Lesson ID.
     * @param int $topic_id Topic ID.
     * @param string $search Search request.
     * 
     * @return void
     */
    public function __construct( $course_id, $lesson_id, $topic_id, $search = '' ) {
        $this->course_id    = $course_id;
        $this->lesson_id    = $lesson_id;
        $this->topic_id     = $topic_id;
        $this->search       = $search;

        parent::__construct();
    }

    /**
     * Get source meta.
     * 
     * @return array Source meta.
     */
    protected function get_source_meta() {
        return array(
            'course_id' => $this->course_id,
            'lesson_id' => $this->lesson_id,
            'topic_id'  => $this->topic_id
        );
    }

    /**
     * Get source content.
     * 
     * @return string Source content.
     */
    protected function get_source_content() {
        $materials_enabled = learndash_get_setting( $this->topic_id, 'topic_materials_enabled' );
        $materials_content = learndash_get_setting( $this->topic_id, 'topic_materials' );

        return $materials_enabled && $materials_content ? $materials_content : '';
    }
}