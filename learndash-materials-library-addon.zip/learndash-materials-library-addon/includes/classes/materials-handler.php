<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Frontend;
use LDMLA\Classes\Data_Helpers;

class Materials_Handler {
    /**
     * @var array Default parsers.
     */
    const DEFAULT_PARSERS = array(
        'link'      => 'LDMLA\\Classes\\Parsers\\Link_Parser',
        'video'     => 'LDMLA\\Classes\\Parsers\\Video_Parser',
        'audio'     => 'LDMLA\\Classes\\Parsers\\Audio_Parser',
        'playlist'  => 'LDMLA\\Classes\\Parsers\\Playlist_Parser'
    );

    /**
     * @var array Source.
     */
    private $source = array();

    /**
     * @var string Source content.
     */
    private $source_content = '';

    /**
     * @var string Search request.
     */
    private $search = '';

    /**
     * @var array Parsers.
     */
    private $parsers = array();

    /**
     * @var array Materials.
     */
    private $materials = array();

     /**
      * Constructor.
      *
      * @param array $source Source.
      * @param string $source_content Source content.
      * @param string $search Search request.
      */
    public function __construct( $source, $source_content, $search ) {
        $this->source               = $source;
        $this->source_content       = $source_content;
        $this->search               = $search;
        $parsers                    = wp_parse_args( apply_filters( 'ldmla_add_materials_parsers', array() ), $this->get_default_parsers() );

        foreach ( $parsers as $type => $parser ) {
            if ( class_exists( $parser ) ) {
                $this->parsers[ $type ] = new $parser( $this->source_content );
            }
        }

        $this->start_parsers();
    }

    /**
     * Get default parsers.
     *
     * @return array Default parsers.
     */
    public function get_default_parsers() {
        return apply_filters( 'ldmla_handler_default_materials_parsers', self::DEFAULT_PARSERS );
    }

    /**
     * Get Source.
     *
     * @return array Source.
     */
    public function get_source() {
        return $this->source;
    }

    /**
     * Get materials search.
     * 
     * @return string Materials search request.
     */
    public function get_materials_search() {
        return $this->search;
    }

    /**
     * Start parsers.
     * 
     * @return void.
     */
    private function start_parsers() {
        foreach ( $this->parsers as $parser ) {
            $parser_materials = $parser->get_materials();

            if ( $parser_materials ) {
                foreach( $parser_materials as $parser_material ) {
                    $material = $this->handle_material( $parser_material );

                    if ( $material ) {
                        $this->materials[] = $material;
                    }
                }
            }
        }
    }

    /**
     * Handle material.
     *
     * @param array $parsed_material Parsed material.
     * 
     * @return array Handled material.
     */
    public function handle_material( $parsed_material ) {
        $title              = $parsed_material['title'];
        $url                = preg_match( '/^(http(s)?:\/\/|\/\/)/', $parsed_material['url'] ) ? $parsed_material['url'] : home_url( $parsed_material['url'] );
        $home_url_info      = parse_url( home_url() );
        $link_url_info      = parse_url( $url );
        $is_external        = $home_url_info[ 'host' ] != $link_url_info[ 'host' ];
        $attachment         = array();

        if ( ! $is_external ) {
            $attachment_id = url_to_postid( $url );

            if ( ! $attachment_id ) {
                $attachment_id = attachment_url_to_postid( $url );
            }

            $attachment_file    = $attachment_id ? get_attached_file( $attachment_id ) : '';
            $title              = empty( $title ) && $attachment_id ? get_the_title( $attachment_id ) : $title;

            if ( $attachment_file ) {
                $attachment_url     = wp_get_attachment_url( $attachment_id );
                $filetype           = wp_check_filetype( $attachment_file );
                $title              = sprintf( '%s (%s)', $title, $filetype['ext'] );
                $source             = array_diff_key( $this->get_source(), array_flip( array( 'source_type' ) ) );
                $data_to_hash       = json_encode( wp_parse_args( compact( 'attachment_id' ), $source ) );
                $hash               = Data_Helpers::get_hash_hmac( $data_to_hash );
                $size               = Data_Helpers::get_filesize( filesize( $attachment_file ) );
                $download_args      = Data_Helpers::encrypt_string( json_encode( wp_parse_args( compact( 'attachment_id', 'hash' ), $source ) ) );

                if ( get_option( 'permalink_structure' ) != '' ) {
                    $download_url = user_trailingslashit( home_url( Frontend::REWRITE_ENDPOINT . '/' . $download_args ) );
                } else {
                    $download_url = add_query_arg( Frontend::REWRITE_ENDPOINT, $download_args, home_url() );
                }

                $attachment = array( 
                    'attachment' => array(
                        'id'            => $attachment_id,
                        'ext'           => $filetype['ext'],
                        'path'          => $attachment_file,
                        'url'           => $attachment_url,
                        'hash'          => $hash,
                        'size'          => $size,
                        'download_url'  => $download_url
                    )
                );
            }
        }

        $title          = ! empty( $title ) ? $title : __( 'Untitled material', 'learndash-materials-library-addon' );
        $is_attachment  = ! empty( $attachment );

        if ( $this->get_materials_search() && stripos( $title, $this->get_materials_search() ) === false ) {
            return array();
        }

        $material   = wp_parse_args( compact( 'title', 'url', 'is_external', 'is_attachment' ), array( 'source' => $this->get_source(), 'parsed' => $parsed_material ) );
        $material   = wp_parse_args( $attachment, $material );

        return apply_filters( 'ldmla_parser_add_material', $material );
    }

    /**
     * Get materials.
     *
     * @return array Materials.
     */
    public function get_materials() {
        return $this->materials;
    }
}