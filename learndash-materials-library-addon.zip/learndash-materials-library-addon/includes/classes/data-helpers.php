<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

class Data_Helpers {
    /**
     * Simple function to encrypt a string. To avoid directly downloading a material from the attachment page using attachment ID.
     * 
     * @param string $string A string to be encrypted.
     * 
     * @return string Encrypted string.
     */
    public static function encrypt_string( $string ) {
        $result = '';

        for ( $i = 0, $k = strlen( $string ); $i < $k; $i++ ) {
            $char       = substr( $string, $i, 1 );
            $key        = 10;
            $keychar    = substr( $key, ( $i % strlen( $key ) ) - 1, 1 );
            $char       = chr( ord( $char ) + ord( $keychar ) );
            $result     .= $char;
        }

        return base64_encode( $result );
    }
    
    /**
     * Simple function to decrypt a string. To avoid directly downloading a material from the attachment page using attachment ID.
     * 
     * @param string $string An encrypted string to be decrypted.
     * 
     * @return string Decrypted string.
     */
    public static function decrypt_string( $string ) {
        $result = '';
        $string = base64_decode( $string );

        for( $i = 0, $k = strlen( $string ); $i < $k; $i++ ) {
            $char       = substr( $string, $i, 1 );
            $key        = 10;
            $keychar    = substr( $key, ( $i % strlen( $key ) ) - 1, 1 );
            $char       = chr( ord( $char ) - ord( $keychar ) );
            $result     .= $char;
        }

        return $result;
    }

    /**
     * Get a formatted file size by its bytes.
     * 
     * @param int $bytes File size in bytes.
     * 
     * @return string Formatted file size.
     */
    public static function get_filesize( $bytes ) {
        $symbol         = array( 'b', 'Kb', 'Mb', 'Gb' );
        $symbol_index   = floor( log( $bytes ) / log( 1024 ) );

        return sprintf( '%.2f %s', ( $bytes / pow ( 1024, floor( $symbol_index ) ) ), $symbol[ $symbol_index ] );
    }

    /**
     * Get hash hmac.
     * 
     * @param string $data Data.
     * 
     * @return string Hash hmac.
     */
    public static function get_hash_hmac( $data ) {
        return hash_hmac( 'sha256', $data, NONCE_KEY );
    }
}