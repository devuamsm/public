<?php

namespace LDMLA\Classes\Notices;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Notice;

class Warning_Notice extends Notice {
    /**
     * Get CSS class.
     *
     * @return string CSS class.
     */
    public function get_css_class() {
        return 'warning';
    }
}