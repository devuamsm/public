<?php

namespace LDMLA\Classes\Notices;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Notice;

class Success_Notice extends Notice {
    /**
     * Get CSS class.
     *
     * @return string CSS class.
     */
    public function get_css_class() {
        return 'success';
    }
}