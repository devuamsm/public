<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Sources\Course_Source;
use LDMLA\Classes\Sources\Course_Quiz_Source;
use LDMLA\Classes\Sources\Lesson_Source;
use LDMLA\Classes\Sources\Lesson_Quiz_Source;
use LDMLA\Classes\Sources\Topic_Source;
use LDMLA\Classes\Sources\Topic_Quiz_Source;

class Materials_Collector {
    /**
     * @var array Collection.
     */
    private $collection = array();

    /**
     * Constructor.
     *
     * @param int $course_id Course ID.
     * @param string $search Search request.
     */
    public function __construct( $course_id, $search = '' ) {
        $user_id = get_current_user_id();

        if ( ! Materials_Accessibility::is_course_accessible( $course_id, $user_id ) ) {
            return;
        }

        $course_source = new Course_Source( $course_id, $search );
        $this->collection[ $course_source->get_source_type() ][ $course_id ] = $course_source;

        $course_quizzes = learndash_get_course_quiz_list( $course_id, $user_id );

        foreach ( $course_quizzes as $course_quiz ) {
            $course_quiz_source = new Course_Quiz_Source( $course_id, $course_quiz['id'], $search );
            $this->collection[ $course_quiz_source->get_source_type() ][ $course_quiz['id'] ] = $course_quiz_source;
        }

        $lessons = learndash_get_course_lessons_list( $course_id, $user_id, array( 'num' => -1 ) );

        if ( $lessons ) {
            foreach ( $lessons as $lesson ) {
                if ( Materials_Accessibility::is_sample_lesson( $lesson['id'] ) ) {
                    continue;
                }

                $lesson_source = new Lesson_Source( $course_id, $lesson['id'], $search );
                $this->collection[ $lesson_source->get_source_type() ][ $lesson['id'] ] = $lesson_source;

                $lesson_quizzes = learndash_get_lesson_quiz_list( $lesson['id'], $user_id, $course_id );

                if ( $lesson_quizzes ) {
                    foreach ( $lesson_quizzes as $lesson_quizz ) {

                        $lesson_quiz_source = new Lesson_Quiz_Source( $course_id, $lesson['id'], $lesson_quizz['id'], $search );
                        $this->collection[ $lesson_quiz_source->get_source_type() ][ $lesson_quizz['id'] ] = $lesson_quiz_source;
                    }
                }

                $topics = learndash_get_topic_list( $lesson['id'], $course_id );

                if ( $topics ) {
                    foreach ( $topics as $topic ) {

                        $topic_source = new Topic_Source( $course_id, $lesson['id'], $topic->ID, $search );
                        $this->collection[ $topic_source->get_source_type() ][ $topic->ID ] = $topic_source;

                        $topic_quizzes = learndash_get_lesson_quiz_list( $topic->ID, null, $course_id );

                        if ( $topic_quizzes ) {
                            foreach ( $topic_quizzes as $topic_quiz ) {

                                $topic_quiz_source = new Topic_Quiz_Source( $course_id, $lesson['id'], $topic->ID, $topic_quiz['id'], $search );
                                $this->collection[ $topic_quiz_source->get_source_type() ][ $topic_quiz['id'] ] = $topic_quiz_source;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Get materials.
     *
     * @param array $filter Filter materials by source.
     * 
     * @return array Materials.
     */
    public function get_materials( $filter = array() ) {
        $materials      = array();
        $collection     = $this->collection;

        if ( $filter && is_array( $filter ) && array_intersect( array_keys( $this->collection ), $filter ) ) {
            $collection = array_intersect_key( $this->collection, array_flip( $filter ) );
        }

        if ( $collection ) {
            foreach ( $collection as $collection_type => $collection_sources ) {
                foreach ( $collection_sources as $source_id => $source ) {
                    $source_materials = apply_filters( 'ldmla_collector_add_source_materials', $source->get_materials(), $source_id, $source, $collection_type );
                    $materials = $materials + $source_materials;
                }
            }
        }

        return $materials;
    }
}