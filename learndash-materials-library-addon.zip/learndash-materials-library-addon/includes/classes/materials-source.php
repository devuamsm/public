<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

abstract class Materials_Source {
    /**
     * @var string Search request.
     */
    protected $search = '';

    /**
     * @var string Materials.
     */
    protected $materials = array();

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        $this->materials = $this->collect_materials();
    }

    /**
     * Get source meta.
     * 
     * @return array Source meta.
     */
    abstract protected function get_source_meta();

    /**
     * Get source content.
     * 
     * @return string Source content.
     */
    abstract protected function get_source_content();

    /**
     * Get source type.
     * 
     * @return string Source type.
     */
    final public function get_source_type() {
        $class_name = explode( '\\', get_called_class() );

        return array_pop( $class_name );
    }

    /**
     * Get materials search.
     * 
     * @return string Materials search request.
     */
    final protected function get_materials_search() {
        return $this->search;
    }

    /**
     * Collect materials.
     * 
     * @return array Collected materials.
     */
    final private function collect_materials() {
        $source     = wp_parse_args( $this->get_source_meta(), array( 'source_type' => $this->get_source_type() ) );
        $handler    = new Materials_Handler( $source, $this->get_source_content(), $this->get_materials_search() );

        return $handler->get_materials();
    }

    /**
     * Get materials.
     * 
     * @return array Materials.
     */
    final public function get_materials() {
        return $this->materials;
    }
}