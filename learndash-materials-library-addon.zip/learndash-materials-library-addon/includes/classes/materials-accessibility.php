<?php

namespace LDMLA\Classes;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

class Materials_Accessibility {
    /**
     * Check if a course is accessible.
     *
     * @param int $course_id Course ID.
     * @param int $user_id User ID.
     * 
     * @return boolean Result of the checking.
     */
    public static function is_course_accessible( $course_id, $user_id = 0 ) {
        $access = false; 

        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        if ( current_user_can( 'administrator' ) ) {
            $access = true;
        } else {
            if ( learndash_get_course_meta_setting( $course_id, 'course_price_type' ) == 'free' ) {
                $access = true;
            } else {
                $user_query = learndash_get_users_for_course( $course_id );
        
                if ( $user_query && ! empty( $user_query->get_results() ) ) {
                    $course_user_ids = array_map( 'intval', $user_query->get_results() );
        
                    $access = in_array( $user_id, $course_user_ids );
                }
            }
        }

        return apply_filters( 'ldmla_accessibility_is_course_accessible', $access, $course_id, $user_id );
    }

    /**
     * Check if a lesson is sample.
     *
     * @param int $lesson_id Lesson ID.
     * 
     * @return boolean Result of the checking.
     */
    public static function is_sample_lesson( $lesson_id ) {
        return apply_filters( 'ldmla_accessibility_is_sample_lesson', learndash_is_sample( $lesson_id ), $lesson_id );
    }
}