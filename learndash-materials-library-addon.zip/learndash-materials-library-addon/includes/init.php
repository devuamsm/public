<?php

namespace LDMLA;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Notices\Error_Notice;

class Init {
    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );

        if ( ! $this->is_learn_dash_active() ) {
            add_action( 'admin_notices', array( $this, 'admin_notices' ) );

            return;
        }

        $this->init();
    }

    /**
     * Plugin localization.
     * 
     * @return void
     */
    public function load_plugin_textdomain() {
        $domain         = 'learndash-materials-library-addon';
        $wp_lang_dir    = untrailingslashit( WP_LANG_DIR );
        $locale         = apply_filters( 'plugin_locale', get_locale(), $domain );
        $exists         = load_textdomain( $domain, $wp_lang_dir . '/plugins/' . $domain . '-' . $locale . '.mo' );

        if ( ! $exists ) {
            load_plugin_textdomain( $domain, FALSE, basename( dirname( LDMLA_FILE ) ) . '/languages/' );
        }
    }

    /**
     * Check if LearDash plugin is active.
     * 
     * @return bool Result of checking.
     */
    private function is_learn_dash_active() {
        require_once ABSPATH . '/wp-admin/includes/plugin.php';

        return is_plugin_active( 'sfwd-lms/sfwd_lms.php' );
    }

    /**
     * Dashboard admin notices.
     * 
     * @return void
     */
    public function admin_notices() {
        $error = new Error_Notice;
        $error->add( 'missing_required_plugin', sprintf( 
            __( '%s plugin requires %s plugin activated.', 'learndash-materials-library-addon' ),
            sprintf( '<strong>%s</strong>', LDMLA_NAME ),
            '<strong>LearnDash LMS</strong>'
        ) );
     }

    public function init() {
        Block_Editor::get_instance();
        Admin::get_instance();
        Frontend::get_instance();
    }
}