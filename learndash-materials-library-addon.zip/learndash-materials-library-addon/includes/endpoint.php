<?php

namespace LDMLA;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LDMLA\Classes\Materials_Library;

class Endpoint {
    use \LDMLA\Traits\Singleton_Trait;

    /**
     * @var string API endpoint namespace.
     */
    const API_ENDPOINT_NAMESPACE = 'ldma/v1';

    /**
     * @var string API endpoint route.
     */
    const API_ENDPOINT_ROUTE = '/course_categories';

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_endpoint' ) );
    }

    /**
     * Register API endpoint.
     * 
     * @return void
     */
    public function register_endpoint() {
        register_rest_route( self::API_ENDPOINT_NAMESPACE, self::API_ENDPOINT_ROUTE, array(
            'methods'               => \WP_REST_Server::READABLE,
            'callback'              => array( $this, 'endpoint_get_course_categories' ),
            'permission_callback'   => false
        ) );
    }

    /**
     * Endpoint get course categories.
     * 
     * @return object Instance of WP_REST_Response.
     */
    public function endpoint_get_course_categories() {
        return new \WP_REST_Response( Materials_Library::get_course_categories(), 200 );
    }
}
