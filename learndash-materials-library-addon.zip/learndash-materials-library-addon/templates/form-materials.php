<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit; ?>

<table class="ldmla-materials-library__table ldmla-materials-library-table">
    <thead class="ldmla-materials-library-table__thead">
        <tr class="ldmla-materials-library-table__row">
            <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--number">#</td>
            <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--title"><?php _e( 'Material name', 'learndash-materials-library-addon' ); ?></td>
            <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--size"><?php _e( 'Size', 'learndash-materials-library-addon' ); ?></td>
            <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--download"><?php _e( 'Links', 'learndash-materials-library-addon' ); ?></td>
        </tr>
    </thead>
    <tbody class="ldmla-materials-library-table__tbody">
        <?php if ( $course_materials ) : 
            $num = ( $page - 1 ) * $materials_per_page + 1;
            foreach( $course_materials as $course_material ) :
                $is_material_external       = $course_material['is_external'];
                $is_material_attachment     = $course_material['is_attachment'];
                $material_title             = $course_material['title'];
                $material_url               = $is_material_attachment ? $course_material['attachment']['download_url'] : $course_material['url'];
                $material_size              = $is_material_attachment ? $course_material['attachment']['size'] : __( 'none', 'learndash-materials-library-addon' );
                ?>
                <tr class="ldmla-materials-library-table__row">
                    <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--number" data-title="#"><?php echo $num++; ?></td>
                    <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--title" data-title="<?php _e( 'Material name', 'learndash-materials-library-addon' ); ?>"><?php echo esc_html( $material_title ); ?></td>
                    <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--size" data-title="<?php _e( 'Size', 'learndash-materials-library-addon' ); ?>"><?php echo $material_size; ?></td>
                    <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--download" data-title="<?php _e( 'Links', 'learndash-materials-library-addon' ); ?>">
                        <a href="<?php echo esc_url( $material_url ); ?>" class="ldmla-materials-library-table__button" target="_blank"<?php echo $is_material_external ? ' rel="nofollow noreferrer noopener"' : ''; ?>><?php echo $is_material_attachment ? __( 'Download', 'learndash-materials-library-addon' ) : __( 'Visit Link', 'learndash-materials-library-addon' ); ?></a>
                    </td>
                </tr>
                <?php
            endforeach;
        else: ?>
            <tr class="ldmla-materials-library-table__row ldmla-materials-library-table__row--no-results">
                <td class="ldmla-materials-library-table__cell ldmla-materials-library-table__cell--no-materials" colspan="4" data-title="<?php _e( 'Materials', 'learndash-materials-library-addon' ); ?>"><?php _e( 'No materials found', 'learndash-materials-library-addon' ); ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php if ( $course_materials ) : ?>
    <div class="ldmla-materials-library__bottom ldmla-materials-library-bottom">
        <div class="ldmla-materials-library-bottom__info ldmla-materials-library-info"><?php printf( __( 'Showed %s from %s', 'learndash-materials-library-addon' ), min( $page * $materials_per_page, $total_course_materials ), sprintf( _n( '%d item', '%d items', $total_course_materials, 'learndash-materials-library-addon' ), $total_course_materials ) ); ?></div>
        <?php if ( $pagination ) : ?>
            <nav class="ldmla-materials-library-bottom__pagination ldmla-materials-library-pagination js-ldmla-materials-library-pagination"><?php echo $pagination; ?></nav>
        <?php endif; ?>
    </div>
<?php endif; ?>