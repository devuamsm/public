<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit; ?>

<div class="ldmla-materials-library js-ldmla-materials-library">
    <div class="ldmla-materials-library__title"><?php _e( 'Materials Library', 'learndash-materials-library-addon' ); ?></div>
    <div class="ldmla-materials-library__content js-ldmla-materials-library-content">
        <div class="ldmla-materials-library__fields ldmla-materials-library-fields">
            <div class="ldmla-materials-library-field ldmla-materials-library-field--course">
                <select class="ldmla-materials-library-field__filter ldmla-materials-library-field__filter--course js-ldmla-materials-library-course">
                    <option value="0"><?php _e( 'All courses', 'learndash-materials-library-addon' ); ?></option>
                    <?php foreach( $courses as $course ) : ?>
                        <option value="<?php echo esc_attr( $course['id'] ); ?>"><?php echo esc_html( $course['title'] ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ldmla-materials-library-field ldmla-materials-library-field--search">
                <input class="ldmla-materials-library-field__filter ldmla-materials-library-field__filter--search js-ldmla-materials-library-search" type="text" placeholder="<?php _e( 'Search', 'learndash-materials-library-addon' ); ?>...">
            </div>
            <input class="js-ldmla-materials-library-course-category-id" type="hidden" value="<?php echo esc_attr( implode( ',', $course_category_id ) ); ?>">
            <input class="js-ldmla-materials-library-page" type="hidden" value="<?php echo esc_attr( $page ); ?>">
            <input class="js-ldmla-materials-library-per-page" type="hidden" value="<?php echo esc_attr( $materials_per_page ); ?>">
        </div>
        <div class="ldmla-materials-library__materials js-ldmla-materials-library-materials"><?php echo $template_materials; ?></div>
    </div>
</div>