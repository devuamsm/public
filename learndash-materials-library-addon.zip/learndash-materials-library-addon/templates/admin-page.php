<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit; ?>

<div class="wrap">
    <h1><?php echo get_admin_page_title(); ?></h1>
    <div class="ldmla-shortcode-settings">
        <div class="ldmla-shortcode-settings__row">
            <div class="ldmla-shortcode-settings__notice">
                <p><?php _e( 'To display the Materials Library, you can use the Materials Library block in the Gutenberg editor, where you can set the settings.', 'learndash-materials-library-addon' ); ?></p>
                <p><?php _e( 'Otherwise use the shortcode', 'learndash-materials-library-addon' ); ?>:</p>
                <p><code class="ldmla-shortcode-settings__shortcode js-ldmla-shortcode" data-shortcode="<?php echo esc_attr( $shortcode ); ?>">[<?php echo esc_attr( $shortcode ); ?>]</code></p>
                <p>
                    <button class="ldmla-shortcode-settings__copy-button js-ldmla-copy-button button button-secondary" type="button"><?php _e( 'Copy', 'learndash-materials-library-addon' ); ?></button>
                    <span class="ldmla-shortcode-settings__copy-notice js-ldmla-copy-notice">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <span><?php _e( 'Copied', 'learndash-materials-library-addon' ); ?></span>
                    </span>
                    <input class="ldmla-shortcode-settings__copy-shortcode js-ldmla-copy-shortcode" type="text" value="[<?php echo esc_attr( $shortcode ); ?>]">
                </p>
            </div>
        </div>
        <div class="ldmla-shortcode-settings__row">
            <h2 class="ldmla-shortcode-settings__heading"><?php _e( 'Shortcode settings', 'learndash-materials-library-addon' );  ?></h2>
        </div>
        <div class="ldmla-shortcode-settings__row">
        <label class="ldmla-toggle">
            <input class="js-ldmla-filter-by-course-categories" type="checkbox">
            <span class="ldmla-toggle-slide"></span>
        </label>
        <span class="ldmla-toggle-title"><?php _e( 'Filter by course categories', 'learndash-materials-library-addon' ); ?></span>
        </div>
        <div class="ldmla-shortcode-settings__row js-ldmla-setting-course-categories hidden">
            <label class="ldmla-shortcode-settings__label">
                <strong><?php _e( 'Course categories', 'learndash-materials-library-addon' ); ?></strong>
            </label>
            <div class="ldmla-shortcode-settings__field">
                <select class="ldmla-shortcode-settings__select ldmla-shortcode-settings__select--course-categories js-ldmla-course-categories" name="course_category_id" multiple <?php disabled( $is_disabled ); ?>>
                    <?php foreach( $course_categories as $course_category ) : ?>
                        <option value="<?php echo esc_attr( $course_category['id'] ); ?>" <?php selected( ! $is_disabled ); ?>><?php echo $course_category['title']; ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="description">
                    <?php _e( 'Use Ctrl+click to select/deselect multiple Course categories.', 'learndash-materials-library-addon' ); ?>
                    <br>
                    <?php _e( 'Materials will only be shown in the selected Course categories.', 'learndash-materials-library-addon' ); ?>
                </p>
            </div>
        </div>
        <div class="ldmla-shortcode-settings__row">
            <label class="ldmla-shortcode-settings__label">
                <strong><?php _e( 'Materials per page', 'learndash-materials-library-addon' ); ?></strong>
            </label>
            <div class="ldmla-shortcode-settings__field">
                <input class="ldmla-shortcode-settings__input ldmla-shortcode-settings__input--materials-per-page js-ldmla-materials-per-page" type="number" min="1" name="materials_per_page" value="<?php echo esc_attr( $materials_per_page ); ?>">
            </div>
        </div>
    </div>
</div>