<?php

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

?>
<!DOCTYPE html>
<html lang="en">
<head></head>
<body style="display:none;">
    <canvas id="ld-cvss-pdf2image-canvas" style="display:none;"></canvas>
    <?php if ( $ld_cvss_pdf2image_data ) : ?>
    <script>var ld_cvss_pdf2image_data = <?php echo json_encode( $ld_cvss_pdf2image_data ); ?>;</script>
    <?php endif; ?>
    <script src="<?php echo home_url( '/wp-includes/js/jquery/jquery' . LD_CVSS_ASSETS_SUFFIX . '.js' ); ?>"></script>
    <script src="<?php echo LD_CVSS_URL_ASSETS_JS . '/pdf' . LD_CVSS_ASSETS_SUFFIX . '.js?ver=' . LD_CVSS_VERSION; ?>"></script>
    <script src="<?php echo LD_CVSS_URL_ASSETS_JS . '/pdf2image' . LD_CVSS_ASSETS_SUFFIX . '.js?ver=' . LD_CVSS_VERSION; ?>"></script>
    <script src="<?php echo LD_CVSS_URL_ASSETS_JS . '/iframe' . LD_CVSS_ASSETS_SUFFIX . '.js?ver=' . LD_CVSS_VERSION; ?>"></script>
</body>
</html>