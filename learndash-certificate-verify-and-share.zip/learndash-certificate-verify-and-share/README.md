# LearnDash Certificate Verify and Share

## Description

This addon allows student to share their course certificates, quiz certificates, group certificates on FaceBook, Twitter, Linkedin, and social media visitors can verify the certificates shared on social media.

## Version 1.0.9

**Prerequisites**

- LearnDash Latest Version

**Features**
- Allow student to share their cour, quiz, group certificate on FB, Twitter, Linkedin.
- Allow social media user to click on the shared certificate and verify it on the associate website.
- Allow admin to setup a page where site user can search or verify the certificates.
- Allow admin to set the verification page template from one of two provided designs.
- Admin the site user to search a specific student course, quiz, group certificate and verify.  
- This addon will support LearnDash both themes 3.0 & legacy.


## Installation

Before installation please make sure you have the latest LearnDash plugin installed.

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.

## FAQ

### On which platforms can users share their certificates?
Users can share their LearnDash certificates to their Facebook, LinkedIn, and Twitter accounts directly.

### Which LearnDash certificates are verifiable and shareable?
LearnDash course, quiz, and group certificates are all verifiable and shareable.

### Why are the certificate verification fields not displayed on the front-end even after adding the shortcode on the page?
Please make sure to select the page containing the shortcode from the dropdown menu on the Verification Page tab from the add-on settings page.

### Will there be a preview of the certificate on the social platforms where the certificates are shared?
Yes, a preview image of the certificate will be displayed on the social media posts if you enable the “Generate Certificate Image for social sharing” option on the general settings page.

### How can I add the description for the certificates if there is no certificate description field included by default in LearnDash LMS?
This add-on provides an additional “Excerpt” field where you can add a description for your certificates. This description will be displayed on the certificate’s verification result page.

### Can we use our own template to display the certificate verification search result?
No, you can only choose between the two templates provided by the add-on.

### Can we provide an interface for direct/normal visitors to search a specific user certificate on our site ?
Yes, you can add the certificate verification page into the site header, footer or any menu, so visitors will see the search form, and they will be able to search a specific student course, quiz, group certificate and the search result will display the certificate with details.

### Can non-logged in visitors see the certificate details on the verification page?
Yes, any site visitor can search for any student’s course, quiz, or group certificates from the Verification Search Page and see their details.

### Is the LearnDash Certificate Builder supported by this add-on?
Yes, version 1.0.1 of the LearnDash Certificate Verify & Share add-on is tested with the latest version of the LearnDash Certificate Builder add-on.

### Are quiz and group certificates also supported?
Yes, this add-on supports all types of LearnDash certificates i.e course, quiz, group certificates.

### can I change the certificate verification page course 'read more' URL for a specific course or certificate type like group, course, quiz?
Yes, version 1.0.6 allows 3rd party developers to modify the course 'read more' URL for a specific course or certificate type by using the following filter-hook.
#### Hook Definition:
```
apply_filters('ld_cvss_verfication_page_course_read_more_url', get_post_permalink($course->ID), $course->ID, $certificate->certificate_type, $certificate, $certificate_post, $student, $instructor  );
```
#### Hook usage example:
The following script will change the course 'read more' link on the verification page when you place this code inside the active theme functions.php file.
```
function update_verfication_page_course_read_more_url(    $course_permalink, $course_id, $certificate_type, $certificate, $certificate_post, $student, $instructor ){
  $course_permalink = 'https://www.google.com;
  return $course_permalink;
}
add_filter('ld_cvss_certificate_verification_page_show_instructor','update_verfication_page_course_read_more_url', 10, 7 );
```


### Can i remove the instructor profile-box from the certificate verification page ?
Yes, The version 1.0.7 provide a filter hook 'ld_cvss_certificate_verification_page_show_instructor' that 3rd party developers can control the instructor visibility on the 
#### Hook Definition:
```
apply_filters('ld_cvss_certificate_verification_page_show_instructor', true, $certificate, $certificate_post, $student, $instructor );
```
#### Hook usage example:
The following script will prevent the instructor visibility on the verification page when you place this code inside the active theme functions.php file.
```
function show_instructor_on_verification_page( $status, $certificate, $certificate_post, $student, $instructor ){
  $status = false;
  return $status;
}
add_filter('ld_cvss_certificate_verification_page_show_instructor','show_instructor_on_verification_page', 10, 5 );
```

## Changelog

[See all version changelogs](CHANGELOG.md)

