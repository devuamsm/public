<?php

namespace LD_CVSS\Classes\Notices;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LD_CVSS\Classes\Notice;

class Info_Notice extends Notice {
    /**
     * Get CSS class.
     *
     * @return string CSS class.
     */
    public function get_css_class() {
        return 'info';
    }
}