<?php

namespace LD_CVSS;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LD_CVSS\Upgrades\Upgrade_108;

/**
 * Used for plugin upgrades.
 */
class Upgrade {
    use \LD_CVSS\Traits\Trait_Singleton;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        Upgrade_108::get_instance();
    }
}