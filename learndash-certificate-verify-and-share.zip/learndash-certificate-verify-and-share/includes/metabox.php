<?php

namespace LD_CVSS;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LD_CVSS\Metaboxes\Certificate_Description;

/**
 * Used for plugin upgrades.
 */
class Metabox {
    use \LD_CVSS\Traits\Trait_Singleton;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        Certificate_Description::get_instance();
    }
}