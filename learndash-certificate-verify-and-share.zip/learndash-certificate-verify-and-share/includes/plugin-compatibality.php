<?php

namespace LD_CVSS;

/* Exit if accessed directly. */
defined( 'ABSPATH' ) || exit;

use LD_CVSS\Plugins_Compatibility\All_In_One_SEO;
use LD_CVSS\Plugins_Compatibility\Rank_Math_SEO;
use LD_CVSS\Plugins_Compatibility\SEO_Press;
use LD_CVSS\Plugins_Compatibility\Yoast_Seo;

/**
 * Used to provide plugin compatibility with 3d party plugins.
 */
class Plugin_Compatibility {
    use \LD_CVSS\Traits\Trait_Singleton;

    /**
     * Constructor.
     * 
     * @return void
     */
    public function __construct() {
        All_In_One_SEO::get_instance();
        Rank_Math_SEO::get_instance();
        SEO_Press::get_instance();
        Yoast_Seo::get_instance();
    }
}