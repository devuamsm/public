jQuery( function( $ ) {
    $( document ).on( 'ld_cvss.pdf2image.rendered', function( e, data ) {
        $( '.ld-cvss-certificate-img' ).removeClass( 'ld-cvss-certificate-loading' );

        if ( data.is_purchased !== 'true' ) {
            setTimeout( function() {
                $( '.ld-cvss-certificate-img' ).addClass( 'ld-cvss-certificate-not-purchased' );
            }, 500 );
        }
    } );

    $( '.ld-cvss-certificate-img' ).on( 'contextmenu', function( e ) {
        e.preventDefault();
        return false;
    });

    if ( 'undefined' === typeof ld_cvss_search_form ) {
        return false;
    }

    NProgress.configure( {
        parent: '#ld-cvss-search-form',
        showSpinner: false,
        trickleSpeed: 500
    } );

    $( '#ld-cvss-search-form' ).on( 'ld_cvss.search_form.init', function() {
        var $form       = $( this ),
            $input      = $form.find( '.ld-cvss-search-form-input' );

        $input.on( 'input paste', function() {
            setTimeout( function() {
                var csuid = $input.val().toUpperCase();

                $input.val( csuid );
            }, 1 );
        } );

        $form.on( 'submit', function( e ) {
            e.preventDefault();
                var $results    = $form.find( '.ld-cvss-search-form-results' ),
                    csuid       = $input.val();

            $.ajax( {
                method      : 'post',
                url         : ld_cvss_search_form.ajax_url,
                dataType    : 'json',
                data        : {
                    action  : ld_cvss_search_form.ajax_action,
                    nonce   : ld_cvss_search_form.ajax_nonce,
                    csuid   : csuid
                },
                beforeSend: function( xhr ) {
                    xhr.setRequestHeader( 'X-WP-Nonce', ld_cvss_search_form.ajax_nonce );
                    $results.remove();
                    $form.addClass( 'ld-cvss-search-form-ajax' );
                    NProgress.start();
                },
                success: function( response ) {
                    $( response.search_result ).appendTo( $form );
                },
                error: function( xhr, status, error ) {
                    var data = JSON.parse( xhr.responseText );
                    alert( data.message );
                },
                complete: function() {
                    $form.removeClass( 'ld-cvss-search-form-ajax' );
                    NProgress.done();
                }
            } );
        } );
    } ).trigger( 'ld_cvss.search_form.init' );
} );