## 1.0.9
- New: The shortcode for generating certificate QR Codes is added.
- New: Compatibility with the LearnDash Pay for Quiz & Certificate plugin is added.

## 1.0.8
- New: The new method for displaying/downloading certificate PDFs is added.
- New: Added certificate ID to the certificate verification page.
- New: The certificate search form is changed to search by certificate ID.
- New: The settings page layout is changed.
- New: The new shortcode to display certificate ID inside PDFs is added.
- Fix: The issue related to website slowdown is fixed.
- Fix: Displaying certificate image on the certificate verification page is fixed.
- Fix: Displaying certificate image built with the LearnDash Certificate Builder on the certificate verification page is fixed.

## 1.0.7
- New: The 3rd party developer can hide the instructor from the verification page by using the filter hook "ld_cvss_certificate_verification_page_show_instructor".
- Fix: The social sharing meta tags conflict has been resolved for these SEO plugins 'Yoast SEO', 'All In One SEO', 'SEO Press', 'Rank Math SEO'.  
- Fix: The BuddyPress forum file upload issue has been fixed.
- Fix: The All-in-One-SEO plugin conflict with the verification page shortcode has been resolved.
- Fix: The certificate verification page "issue date" translation issue has been fixed. 

## 1.0.6
- New: The certificate verification page course 'read more' url is allowed to be populated by using filter-hook "ld_cvss_verfication_page_course_read_more_url".  
- Improvement: The admin settings verification page dropdown now lists all published pages instead of 10.
- Improvement: The certificate search box user dropdown search input is limited to 3 characters.
- Fix: The plugin activation errors are fixed.
- Fix: The plugin admin settings layout issues are fixed.
- Fix: The certificate search box issues are fixed.
- Fix: The group verification page issues are fixed.

## 1.0.5
- Fix: The social buttons layout fixed.
- Fix: The certification page layout fixed.

## 1.0.4
- Fix: The Builder Certificate to Legacy Switch issue fixed.
- Fix: The PHP Fatal Errors regarding site server image processing.

## 1.0.3
- New: The multilingual translation support.
- New: The certificate image processing at wooninjas remote server.
- New: The quiz certificate sharing icon on the course listing page. 
- Fix: The linkedin profile sharing issuing organization title issue.
- Fix; The compatibility issue with LD Certificate builder 1.0.3.
- Fix: The Wordpres 5.8 compatibility issues.

## 1.0.2
- Fix: The Certificate Verification Page Issue Date correction.
- Fix: The Divi builder js conflict issue.
- Fix: FB Social Sharing Typo
- Fix: The Quiz result not generating if the quiz doesn't have a certificate attached.
- Fix: Badgeos conflict.
- Fix: Search Box Users List issue.

##  1.0.1
- New: The LearnDash Certificate Builder Add-on is now supported.
- New: The certificate description field on the certificate edit screen replaced with the Classic editor.
- Fix: Search loading icon issue on the Front-End.

## 1.0
- Initial release
