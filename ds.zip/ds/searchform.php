<?php
/**
 * The template for search form.
 *
 * @package DS
 */
?>

<form class="search-form" method="get" action="<?php echo esc_url( user_trailingslashit( ( '/' ) ) ); ?>" role="search">
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input class="search-field" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr( __( 'Search', 'ds' ) ); ?>">
	</label>
</form>