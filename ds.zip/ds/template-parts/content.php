<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package DS
 */

?>

<article id="post-<?php the_ID(); ?>" <?php ds_post_class(); ?>>
	<?php if ( ds_display_entry_header() ) : ?>
		<header class="entry-header">
			<?php ds_post_thumbnail(); ?>
			
			<?php
			if ( is_singular() ) :
				the_title( '<h1 class="entry-title">', '</h1>' );
			else :
				the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
			endif; ?>
		</header><!-- .entry-header -->
	<?php endif; ?>
	<div class="entry-inner">
		<div class="entry-body">
			<div class="entry-content">
				<?php 
				if ( is_singular() ) {
					the_content(
						sprintf(
							wp_kses(
								__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'ds' ),
								array(
									'span' => array(
										'class' => array(),
									),
								)
							),
							wp_kses_post( get_the_title() )
						)
					);

					wp_link_pages(
						array(
							'before' => '<div class="page-links">' . __( 'Pages', 'ds' ) . ':',
							'after'  => '</div>',
						)
					);
				} else {
					the_excerpt(); ?>
					<div class="read-more">
						<a href="<?php echo esc_url( get_permalink() ); ?>"><?php _e( 'Read more', 'ds' ); ?> &rarr;</a>
					</div>
				<?php } ?>
			</div><!-- .entry-content -->
			<?php if ( ds_has_entry_links() ) : ?>
				<div class="entry-links">
					<?php ds_entry_links(); ?>
				</div><!-- .entry-links -->
			<?php endif; ?>
		</div><!-- .entry-body -->
		<?php
		if ( ( ! is_singular() && get_theme_mod( 'ds_post_meta_in_list', ds_get_default_theme_mod( 'ds_post_meta_in_list' ) ) ) || ( is_singular() && get_theme_mod( 'ds_post_meta_in_post', ds_get_default_theme_mod( 'ds_post_meta_in_post' ) ) ) ) : ?>
			<div class="entry-side">
				<?php 
				if ( 'post' === get_post_type() ) {
					ds_post_meta();
				} ?>
			</div><!-- .entry-side -->
		<?php endif; ?>
	</div><!-- .entry-inner -->
</article><!-- #post-<?php the_ID(); ?> -->
