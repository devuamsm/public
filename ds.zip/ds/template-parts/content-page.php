<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package DS
 */

?>

<article id="post-<?php the_ID(); ?>" <?php ds_post_class(); ?>>
	<?php if ( ds_display_entry_header() ) : ?>
		<header class="entry-header">
			<?php ds_post_thumbnail(); ?>

			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</header><!-- .entry-header -->
	<?php endif; ?>
	<div class="entry-inner">
		<div class="entry-body">
			<div class="entry-content">
				<?php
				the_content();

				wp_link_pages(
					array(
						'before' => '<div class="page-links">' . __( 'Pages', 'ds' ) . ':',
						'after'  => '</div>',
					)
				);
				?>
			</div><!-- .entry-content -->
			<?php if ( ds_has_entry_links() ) : ?>
				<div class="entry-links">
					<?php ds_entry_links(); ?>
				</div><!-- .entry-links -->
			<?php endif; ?>
		</div><!-- .entry-body -->
	</div><!-- .entry-inner -->
</article><!-- #post-<?php the_ID(); ?> -->
