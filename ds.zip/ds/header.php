<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package DS
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php _e( 'Skip to content', 'ds' ); ?></a>
	<?php if ( get_theme_mod( 'ds_header_text_left' ) || get_theme_mod( 'ds_header_text_right' ) ) : ?>
		<div id="topbar">
			<?php if ( get_theme_mod( 'ds_header_text_left' ) ) : ?>
				<div class="topbar-left"><?php echo get_theme_mod( 'ds_header_text_left' ); ?></div>
			<?php endif;
			if ( get_theme_mod( 'ds_header_text_right' ) ) : ?>
				<div class="topbar-right"><?php echo get_theme_mod( 'ds_header_text_right' ); ?></div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<header id="masthead" class="site-header">
		<div class="inner">
			<div class="site-branding site-branding-<?php echo has_custom_logo() ? 'logo' : 'text'; ?>">
				<?php if ( has_custom_logo() ) :
					the_custom_logo();
				else : ?>
					<p class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
					</p>

					<?php $ds_description = get_bloginfo( 'description', 'display' );

					if ( $ds_description || is_customize_preview() ) : ?>
						<p class="site-description"><?php echo $ds_description; ?></p>
					<?php endif;
				endif; ?>
			</div><!-- .site-branding -->
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
				<span class="line"></span>
				<span class="line"></span>
				<span class="line"></span>
			</button>
			<nav id="site-navigation" class="main-navigation">
				<?php wp_nav_menu(
					array(
						'theme_location' => 'header-menu',
						'menu_id'        => 'primary-menu'
					)
				); ?>
			</nav><!-- #site-navigation -->
		</div><!-- .inner -->
	</header><!-- #masthead -->
	<div class="wrapper">
