<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package DS
 */

if ( ! function_exists( 'ds_body_classes' ) ) {
	/**
	 * Adds custom classes to the body.
	 */
	function ds_body_classes( $classes ) {
		/* Add a class of hfeed to non-singular pages. */
		if ( ! is_singular() ) {
			$classes[] = 'hfeed';
		}

		/* Add a class of no-sidebar when there is no sidebar present. */
		if ( ! ds_is_active_sidebar( 'sidebar-1' ) || is_404() ) {
			$classes[] = 'no-sidebar';
		}

		/* Add a class of homepage. */
		if ( ! is_home() && is_front_page() ) {
			$classes[] = 'homepage';
		}

		return $classes;
	}
}
add_filter( 'body_class', 'ds_body_classes' );

if ( ! function_exists( 'ds_pingback_header' ) ) {
	/**
	 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
	 */
	function ds_pingback_header() {
		if ( is_singular() && pings_open() ) {
			printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
		}
	}
}
add_action( 'wp_head', 'ds_pingback_header' );

if ( ! function_exists( 'ds_add_meta_boxes' ) ) {
	/**
	 * Add custom metaboxes.
	 */
	function ds_add_meta_boxes() {
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			add_meta_box( 'ds_metabox_hide_sidebar', __( 'Sidebar' ), 'ds_render_metabox_hide_sidebar', ds_get_hide_sidebar_post_types(), 'side', 'core' );
		}
	}
}
add_action( 'add_meta_boxes', 'ds_add_meta_boxes' );

if ( ! function_exists( 'ds_save_post' ) ) {
	/**
	 * Actions when saving posts.
	 */
	function ds_save_post( $post_id, $post, $update ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! in_array( get_post_type( $post_id ), ds_get_hide_sidebar_post_types() ) ) {
			return;
		}

		if ( ! isset( $_POST['ds_cb_hide_sidebar'] ) && ! in_array( $_POST['ds_cb_hide_sidebar'], array( 'true', 'false' ) ) ) {
			return;
		}

		$is_hidden_sidebar = esc_html( $_POST['ds_cb_hide_sidebar'] );

		if ( ! add_post_meta( $post_id, '_ds_hide_sidebar', $is_hidden_sidebar, true ) ) {
			update_post_meta( $post_id, '_ds_hide_sidebar', $is_hidden_sidebar );
		}
	}
}
add_action( 'save_post', 'ds_save_post', 10, 3 );

if ( ! function_exists( 'ds_excerpt_more' ) ) {
	/**
	 * Output for the excerpt more.
	 */
	function ds_excerpt_more( $more ) {
		return '...';
	}
}
add_filter( 'excerpt_more', 'ds_excerpt_more' );

if ( ! function_exists( 'ds_comment_form_fields' ) ) {
	/**
	 * Order fields in the comment form.
	 */
	function ds_comment_form_fields( $fields ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );
		$fields['comment'] = $comment_field;

		return $fields;
	}
}
add_filter( 'comment_form_fields', 'ds_comment_form_fields' );

if ( ! function_exists( 'ds_comment_form_defaults' ) ) {
	/**
	 * Remove title from the comment form.
	 */
	function ds_comment_form_defaults( $fields ) {
		$fields['title_reply'] = '';

		return $fields;
	}
}
add_filter( 'comment_form_defaults', 'ds_comment_form_defaults' );

if ( ! function_exists( 'ds_homepage_hide_entry_header' ) ) {
	/**
	 * Hide post header for the homepge.
	 */
	function ds_homepage_hide_entry_header( $bool ) {
		if ( ! is_home() && is_front_page() ) {
			$bool = false;
		}

		return $bool;
	}
}
add_filter( 'ds_display_entry_header', 'ds_homepage_hide_entry_header' );

if ( ! function_exists( 'ds_homepage_blocks' ) ) {
	/**
	 * The shortcode for displaying the homepage's blocks.
	 */
	function ds_homepage_blocks( $atts ) {
		$content = '';

		if ( ! ds_is_acf_active() ) {
			return $content;
		}

		$atts = shortcode_atts( array(), $atts );

		$field_ids 	= array( 'gallery', 'title', 'content' );
		$fields 	= get_fields();

		if ( $fields ) {
			$content .= '<div class="ds-blocks">';

			for ( $i = 1; $i < 5; $i++ ) {
				$block_items = array();

				foreach ( $field_ids as $field_id ) {
					if ( $fields[ $field_id . '_' . $i ] ) {
						$block_items[] = $field_id;
					}
				}

				if ( $block_items != $field_ids ) {
					continue;
				}

				$content .= '<div class="ds-block">';

				foreach ( $field_ids as $field_id ) {
					$field_data 	= $fields[ $field_id . '_' . $i ];
					$field_content 	= '';

					switch ( $field_id ) {
						case 'gallery':
							$gallery_content = '';

							if ( $field_data ) {
								foreach ( $field_data as $image_key => $image_id ) {
									$gallery_content .= sprintf( 
										'<a class="ds-gallery-item%s" href="%s" data-fancybox="gallery_%s" data-options=\'{"loop":true,"buttons":["close"]}\'>%s</a>', 
										( $image_key > 0 ? ' hide' : '' ), 
										esc_url( wp_get_attachment_image_url( $image_id, 'full' ) ), 
										$i, 
										wp_get_attachment_image( $image_id, 'homepage-block', false, 
											array( 
												'class' => 'ds-gallery-image',
												'alt'	=> get_the_title( $image_id )
											) 
										) 
									);
								}
							}

							$field_content = $gallery_content;
							break;
						case 'content':
							$field_content = apply_filters( 'the_content', $field_data );
							break;
						default:
							$field_content = $field_data;
					}

					$content .= sprintf( '<div class="ds-%s">%s</div>', $field_id, $field_content );
				}

				$content .= '</div>';
			}

			$content .= '</div>';
		}

		return $content;
	}
}
add_shortcode( 'ds_homepage_blocks', 'ds_homepage_blocks' );

if ( ! function_exists( 'ds_homepage_blocks_shortcode_notice' ) ) {
	/**
	 * Display notice for the shortcode.
	 */
	function ds_homepage_blocks_shortcode_notice( $post ) {
		if ( ds_is_acf_active() && get_option( 'show_on_front' ) == 'page' && $post->ID == get_option( 'page_on_front' ) ) : ?>
			<div class="postbox ds-postbox">
				<div class="inside"><?php printf( __( 'Use the shortcode %s to display the homepage blocks.', 'ds' ), '<code>[ds_homepage_blocks]</code>' ); ?></div>
			</div>
		<?php endif;
	}
}
add_action( 'edit_form_after_title', 'ds_homepage_blocks_shortcode_notice' );