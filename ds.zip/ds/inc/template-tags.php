<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package DS
 */

if ( ! function_exists( 'ds_assets_js' ) ) {
	/**
	 * Include JS files.
	 */
	function ds_assets_js( $path ) {
		return DS_URL_ASSETS_JS . '/' . $path . ( apply_filters( 'ds_minify_js', DS_MINIFY_JS_CSS, 'js' ) ? '.min.js' : '.js' );
	}
}

if ( ! function_exists( 'ds_assets_css' ) ) {
	/**
	 * Include CSS files.
	 */
	function ds_assets_css( $path ) {
		return DS_URL_ASSETS_CSS . '/' . $path . ( apply_filters( 'ds_minify_css', DS_MINIFY_JS_CSS, 'css' ) ? '.min.css' : '.css' );
	}
}

if ( ! function_exists( 'ds_get_default_theme_mod' ) ) {
	/**
	 * Set default theme mods.
	 */
	function ds_get_default_theme_mod( $mod ) {
		$default_mods = array(
			'ds_header_text_left'	=> '',
			'ds_header_text_right'	=> '',
			'ds_footer_text' 		=> sprintf( '&copy; %s %s', date_i18n( 'Y' ), get_bloginfo( 'name' ) ),
			'ds_post_meta_in_list'	=> true,
			'ds_post_meta_in_post'	=> true,
			'ds_post_nav'			=> true
		);

		return array_key_exists( $mod, $default_mods ) ? $default_mods[ $mod ] : '';
	}
}

if ( ! function_exists( 'ds_post_class' ) ) {
	/**
	 * Set entry classes.
	 */
	function ds_post_class() {
		$classes = apply_filters( 'ds_post_classes', array( 'entry' ) );

		echo post_class( $classes );
	}
}

if ( ! function_exists( 'ds_post_meta' ) ) {
	/**
	 * Display HTML with meta information for the current post.
	 */
	function ds_post_meta() {
		echo '<ul class="entry-meta">';
		printf( '<li class="posted-on">%s: %s</li>', __( 'Posted on', 'ds' ), ds_post_date() );
		printf( '<li class="author vcard">%s: %s</li>', __( 'Author', 'ds' ), ds_post_author() );

		$post_cat = ds_post_cat();

		if ( $post_cat ) {
			printf( '<li class="cat-links">%s: %s</li>', __( 'Category', 'ds' ), $post_cat );
		}

		$post_tag = ds_post_tag();

		if ( $post_tag ) {
			printf( '<li class="tag-links">%s: %s</li>', __( 'Tag', 'ds' ), $post_tag );
		}
		
		echo '</ul>';
	}
}

if ( ! function_exists( 'ds_post_date' ) ) {
	/**
	 * Get post date/time.
	 */
	function ds_post_date() {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		return sprintf( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>' );
	}
}

if ( ! function_exists( 'ds_post_author' ) ) {
	/**
	 * Get post author.
	 */
	function ds_post_author() {
		return '<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>';
	}
}


if ( ! function_exists( 'ds_post_cat' ) ) {
	/**
	 * Get post categories.
	 */
	function ds_post_cat() {
		/* Hide categories for pages. */
		if ( 'post' === get_post_type() ) {
			$categories_list = get_the_category_list( ', ' );
			if ( $categories_list ) {
				return $categories_list;
			}
		}

		return '';
	}
}

if ( ! function_exists( 'ds_post_tag' ) ) {
	/**
	 * Get post tags.
	 */
	function ds_post_tag() {
		/* Hide tags for pages. */
		if ( 'post' === get_post_type() ) {
			$tags_list = get_the_tag_list( '', ', ' );
			if ( $tags_list ) {
				return $tags_list;
			}
		}

		return '';
	}
}

if ( ! function_exists( 'ds_has_entry_links' ) ) {
	/**
	 * Check if post has comment/edit links.
	 */
	function ds_has_entry_links() {
		return ( ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) || get_edit_post_link() );
	}
}

if ( ! function_exists( 'ds_entry_links' ) ) {
	/**
	 * Display post comment/edit links.
	 */
	function ds_entry_links() {
		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			comments_popup_link(
				sprintf(
					wp_kses(
						__( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'ds' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				)
			);
			echo '</span>';
		}

		if ( get_edit_post_link() ) {
			edit_post_link(
				sprintf(
					wp_kses(
						__( 'Edit <span class="screen-reader-text">%s</span>', 'ds' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				),
				'<span class="edit-link">',
				'</span>'
			);
		}
	}
}

if ( ! function_exists( 'ds_post_thumbnail' ) ) {
	/**
	 * Display post thumbnail/slider.
	 */
	function ds_post_thumbnail() {
		$thumbnail 		= '';
		$thumbnail_size = ds_is_active_sidebar( 'sidebar-1' ) ? 'post-thumbnail-small' : 'post-thumbnail-big';

		if ( has_post_thumbnail() ) {
			$thumbnail = sprintf( '<div class="post-thumbnail entry-thumbnail">%s</div>', get_the_post_thumbnail( get_the_ID(), $thumbnail_size ) );
		}
		
		if ( get_post_type() == 'post' && ds_is_acf_active() ) {
			$fields = get_fields();

			if ( ! empty( $fields['slider'] ) ) {
				$thumbnail = '<div class="post-thumbnail entry-thumbnail"><ul class="post-thumbnail-slider not-loaded">';

				foreach ( $fields['slider'] as $image_key => $image_id ) {
					$thumbnail .= sprintf( '<li%s>%s</li>', 
						( $image_key == 0 ? ' class="show"' : '' ),
						wp_get_attachment_image( $image_id, $thumbnail_size, false, 
							array( 
								'alt'	=> get_the_title( $image_id )
							) 
						)
					);
				}

				$thumbnail .= '</ul></div>';
			}
		}
		
		if ( post_password_required() || is_attachment() || ! $thumbnail ) {
			return;
		} 

		echo $thumbnail;
	}
}

if ( ! function_exists( 'wp_body_open' ) ) {
	/**
	 * Shim for sites older than 5.2.
	 *
	 * @link https://core.trac.wordpress.org/ticket/12563
	 */
	function wp_body_open() {
		do_action( 'wp_body_open' );
	}
}

if ( ! function_exists( 'ds_display_entry_header' ) ) {
	/**
	 * Display post header.
	 */
	function ds_display_entry_header() {
		return apply_filters( 'ds_display_entry_header', true );
	}
}

if ( ! function_exists( 'ds_is_active_sidebar' ) ) {
	/**
	 * Check if the sidebar is active.
	 */
	function ds_is_active_sidebar( $sidebar ) {
		return is_active_sidebar( $sidebar ) && ! ds_hide_sidebar();
	}
}

if ( ! function_exists( 'ds_get_hide_sidebar_post_types' ) ) {
	/**
	 * Get supported post types for the sidebar.
	 */
	function ds_get_hide_sidebar_post_types() {
		return apply_filters( 'ds_hide_sidebar_post_types', array( 'post', 'page' ) );
	}
}

if ( ! function_exists( 'ds_is_hidden_sidebar' ) ) {
	/**
	 * Check if the sidebar is hidden.
	 */
	function ds_is_hidden_sidebar( $post_id ) {
		return get_post_meta( $post_id, '_ds_hide_sidebar', true ) == 'true';
	}
}

if ( ! function_exists( 'ds_render_metabox_hide_sidebar' ) ) {
	/**
	 * Display metabox for the sidebar control.
	 */
	function ds_render_metabox_hide_sidebar( $post, $meta ) {
		$is_hidden_sidebar = ds_is_hidden_sidebar( $post->ID );

		printf( '<label><label class="ds-toggle"><input type="hidden" name="ds_cb_hide_sidebar" value="false"><input id="ds-cb-hide-sidebar" class="ds-toggle-slide" type="checkbox" name="ds_cb_hide_sidebar" value="true" %s><span class="ds-toggle-slide"></span></label> <b style="vertical-align:middle;">%s</b></label>', checked( $is_hidden_sidebar, true, false ), __( 'Hide sidebar', 'ds' ) );
	}
}

if ( ! function_exists( 'ds_hide_sidebar' ) ) {
	/**
	 * Hide the sidebar.
	 */
	function ds_hide_sidebar() {
		$bool = false;

		$post_types = ds_get_hide_sidebar_post_types();

		if ( is_singular( $post_types ) && ds_is_hidden_sidebar( get_the_ID() ) ) {
			$bool = true;
		}

		return apply_filters( 'ds_hide_sidebar', $bool );
	}
}

if ( ! function_exists( 'ds_is_acf_active' ) ) {
	/**
	 * Check if the plugin ACF is active.
	 */
	function ds_is_acf_active() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( 'advanced-custom-fields-pro/acf.php' );
	}
}