<?php
/**
 * DS Theme Customizer
 *
 * @package DS
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
if ( ! function_exists( 'ds_customize_register' ) ) {
	function ds_customize_register( $wp_customize ) {
		$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
		$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
		$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

		if ( isset( $wp_customize->selective_refresh ) ) {
			$wp_customize->selective_refresh->add_partial(
				'blogname',
				array(
					'selector'        => '.site-title a',
					'render_callback' => 'ds_customize_partial_blogname',
				)
			);
			$wp_customize->selective_refresh->add_partial(
				'blogdescription',
				array(
					'selector'        => '.site-description',
					'render_callback' => 'ds_customize_partial_blogdescription',
				)
			);
		}
	}
}
add_action( 'customize_register', 'ds_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
if ( ! function_exists( 'ds_customize_partial_blogname' ) ) {
	function ds_customize_partial_blogname() {
		bloginfo( 'name' );
	}
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
if ( ! function_exists( 'ds_customize_partial_blogdescription' ) ) {
	function ds_customize_partial_blogdescription() {
		bloginfo( 'description' );
	}
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
if ( ! function_exists( 'ds_customize_preview_js' ) ) {
	function ds_customize_preview_js() {
		wp_enqueue_script( 'ds-customizer', ds_assets_js( 'customizer' ), array( 'customize-preview' ), DS_VERSION, true );
	}
}
add_action( 'customize_preview_init', 'ds_customize_preview_js' );

if ( ! function_exists( 'ds_customize_text_header' ) ) {
	function ds_customize_text_header( $wp_customize ) {
		$wp_customize->add_section( 'ds_header_text' , array(
			'title'      => __( 'Header Text', 'ds' ),
			'priority'   => 40,
		));

		$wp_customize->add_setting( 'ds_header_text_left', array() );

		$wp_customize->selective_refresh->add_partial( 'ds_header_text_left', array(
			'selector' => '.topbar-left'
		) );

		$wp_customize->add_control( new WP_Customize_Control(
			$wp_customize,
			'ds_control_header_text_left',
				array(
					'label'      => __( 'Text left', 'ds' ),
					'section'    => 'ds_header_text',
					'settings'   => 'ds_header_text_left',
					'priority'   => 1
				)
			)
		);

		$wp_customize->add_setting( 'ds_header_text_right', array() );

		$wp_customize->selective_refresh->add_partial( 'ds_header_text_right', array(
			'selector' => '.topbar-right'
		) );

		$wp_customize->add_control( new WP_Customize_Control(
			$wp_customize,
			'ds_control_header_text_right',
				array(
					'label'      => __( 'Text right', 'ds' ),
					'section'    => 'ds_header_text',
					'settings'   => 'ds_header_text_right',
					'priority'   => 1
				)
			)
		);

		$wp_customize->add_section( 'ds_footer_text' , array(
			'title'      => __( 'Footer Text', 'ds' ),
			'priority'   => 40,
		));

		$wp_customize->add_setting( 'ds_footer_text', 
			array(
				'default' => ds_get_default_theme_mod( 'ds_footer_text' ),
			)
		);

		$wp_customize->selective_refresh->add_partial( 'ds_footer_text', array(
			'selector' => '.site-info'
		) );

		$wp_customize->add_control( new WP_Customize_Control(
			$wp_customize,
			'ds_control_footer_text',
				array(
					'label'      => __( 'Text', 'ds' ),
					'section'    => 'ds_footer_text',
					'settings'   => 'ds_footer_text',
					'priority'   => 1
				)
			)
		);

		$wp_customize->add_section( 'ds_post' , array(
			'title'      => __( 'Post', 'ds' ),
			'priority'   => 40,
		));

		$wp_customize->add_setting( 'ds_post_meta_in_list', 
			array(
				'default' 	=> ds_get_default_theme_mod( 'ds_post_meta_in_list' ),
			)
		);

		$wp_customize->add_control( new WP_Customize_Control(
			$wp_customize,
			'ds_control_post_meta_in_list',
				array(
					'label'      => __( 'Display meta in list', 'ds' ),
					'type'       => 'checkbox',
					'section'    => 'ds_post',
					'settings'   => 'ds_post_meta_in_list',
					'priority'   => 1
				)
			)
		);

		$wp_customize->add_setting( 'ds_post_meta_in_post', 
			array(
				'default' 	=> ds_get_default_theme_mod( 'ds_post_meta_in_post' ),
			)
		);

		$wp_customize->add_control( new WP_Customize_Control(
			$wp_customize,
			'ds_control_post_meta_in_post',
				array(
					'label'      => __( 'Display meta in post', 'ds' ),
					'type'       => 'checkbox',
					'section'    => 'ds_post',
					'settings'   => 'ds_post_meta_in_post',
					'priority'   => 1
				)
			)
		);

		$wp_customize->add_setting( 'ds_post_nav', 
			array(
				'default' 	=> ds_get_default_theme_mod( 'ds_post_nav' ),
			)
		);

		$wp_customize->add_control( new WP_Customize_Control(
			$wp_customize,
			'ds_control_post_nav',
				array(
					'label'      => __( 'Display post nav', 'ds' ),
					'type'       => 'checkbox',
					'section'    => 'ds_post',
					'settings'   => 'ds_post_nav',
					'priority'   => 1
				)
			)
		);
	}
}
add_action( 'customize_register', 'ds_customize_text_header' );

if ( ! function_exists( 'ds_customize_remove_sections' ) ) {
	function ds_customize_remove_sections( $wp_customize ) {
		$wp_customize->remove_section( 'header_image' );
		$wp_customize->remove_control( 'header_textcolor' );
	}
}
add_action( 'customize_register', 'ds_customize_remove_sections', 50 );