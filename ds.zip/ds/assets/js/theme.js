( function( $ ) {
	$( document ).on( 'ready', function() {
		var $menu_toggle        = $( '.menu-toggle' ),
			$site_navigation    = $( '#site-navigation' );

		$menu_toggle.on( 'click', function() {
			var is_toggled = $site_navigation.hasClass( 'toggled' );

			$menu_toggle.attr( 'aria-expanded', ! is_toggled );
			$site_navigation.toggleClass( 'toggled', ! is_toggled );
		} );

		$( '.post-thumbnail-slider' ).each( function() {
			var $slippry = $( this ).slippry({
				captions: false,
				pager: false,
				auto: false
			});

			$slippry.removeClass( 'not-loaded' );
		} );
	} );
} )( jQuery );