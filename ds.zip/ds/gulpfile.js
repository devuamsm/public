var gulp = require('gulp'),
    sass = require('gulp-sass'),
    rename = require('gulp-rename'),
    jsmin = require('gulp-jsmin'),
    removeEmptyLines = require('gulp-remove-empty-lines'),
    zip = require('gulp-zip'),
    clean = require('gulp-clean'),
    fs = require('fs'),
    tempDir = '__temp__';

gulp.task('css-theme', function() {
    return gulp.src('assets/css/sass/*.scss')
        .pipe(sass({
            outputStyle: 'expanded'
        }).on('error', sass.logError))
        .pipe(gulp.dest('assets/css'))
});

gulp.task('css-theme-minified', function() {
    return gulp.src('assets/css/sass/*.scss')
        .pipe(sass({
            outputStyle: 'compressed'
        }).on('error', sass.logError))
        .pipe(removeEmptyLines())
        .pipe(rename({ suffix: '.min' }))
        .pipe(gulp.dest('assets/css'))
});

gulp.task('js-theme-minified', function() {
    return gulp.src('assets/js/!(*.min).js')
        .pipe(jsmin())
        .pipe(removeEmptyLines())
        .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest('assets/js'))
});

gulp.task('watch', function() {
    gulp.watch('assets/css/sass/*.scss', gulp.series(['css-theme', 'css-theme-minified']));
    gulp.watch('assets/js/!(*.min).js', gulp.series('js-theme-minified'));
});

/* Build Theme */

gulp.task('temp', function() {
    return gulp.src([
        "./**/*.*",
        "!composer.json",
        "!composer.lock",
        "!package.json",
        "!package-lock.json",
        "!gulpfile.js",
        "!.gitignore",
        "!.vscode",
        "!node_modules/**",
        "!./**/{sass,sass/**/*}",
        "!build/**"
    ])
    .pipe(gulp.dest('./' + tempDir + '/ds'));
});

gulp.task('zip', function() {
    var content = fs.readFileSync("style.css", "utf8"),
        regexp = /Version.+/ig,
        matches = regexp.exec(content),
        file = 'ds';

    if (matches) {
        file += '-' + matches[0].split(' ')[1];
    }

    return gulp.src('./' + tempDir + '/**/*.*')
        .pipe(zip(file + '.zip'))
        .pipe(gulp.dest('./'));
});

gulp.task('clean', function() {
    return gulp.src('./' + tempDir, {read: false})
        .pipe(clean())
});

gulp.task('build', gulp.series(['temp', 'zip', 'clean']));