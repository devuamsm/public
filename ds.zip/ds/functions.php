<?php
/**
 * DS functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package DS
 */

! defined( 'DS_VERSION' )           && define( 'DS_VERSION', wp_get_theme()->get( 'Version' ) );
! defined( 'DS_MINIFY_JS_CSS' )     && define( 'DS_MINIFY_JS_CSS', ( ! defined( 'SCRIPT_DEBUG' ) || SCRIPT_DEBUG !== true ) );
! defined( 'DS_FILE' )              && define( 'DS_FILE', __FILE__ );
! defined( 'DS_PATH' )              && define( 'DS_PATH', get_template_directory() );
! defined( 'DS_PATH_INC' )          && define( 'DS_PATH_INC', DS_PATH . '/inc' );
! defined( 'DS_URL' )               && define( 'DS_URL', get_template_directory_uri() );
! defined( 'DS_URL_ASSETS' )        && define( 'DS_URL_ASSETS', DS_URL . '/assets' );
! defined( 'DS_URL_ASSETS_JS' )     && define( 'DS_URL_ASSETS_JS', DS_URL_ASSETS . '/js' );
! defined( 'DS_URL_ASSETS_CSS' )    && define( 'DS_URL_ASSETS_CSS', DS_URL_ASSETS . '/css' );

/* Custom template tags for this theme. */
require DS_PATH_INC . '/template-tags.php';

/* Functions which enhance the theme by hooking into WordPress. */
require DS_PATH_INC . '/template-functions.php';

/* Implement the Custom Header feature. */
require DS_PATH_INC . '/custom-header.php';

/* Customizer additions. */
require DS_PATH_INC . '/customizer.php';

if ( ! function_exists( 'ds_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function ds_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on DS, use a find and replace
		 * to change 'ds' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'ds', get_template_directory() . '/languages' );

		/* Add default posts and comments RSS feed links to head. */
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		/*
		 * Set post thumbnail custom sizes.
		 */
		add_image_size( 'post-thumbnail-small', 999, 9999 );
		add_image_size( 'post-thumbnail-big', 1240, 9999 );

		/*
		 * Set image custom sizes.
		 */
		add_image_size( 'homepage-block', 298, 650, true );

		/* This theme uses wp_nav_menu() in one location. */
		register_nav_menus(
			array(
				'header-menu' => __( 'Header', 'ds' ),
			)
		);

		register_nav_menus(
			array(
				'footer-menu' => __( 'Footer', 'ds' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		/* Set up the WordPress core custom background feature. */
		add_theme_support(
			'custom-background',
			apply_filters(
				'ds_custom_background_args',
				array(
					'default-color' => 'f9f9f9',
					'default-image' => '',
				)
			)
		);

		/* Add theme support for selective refresh for widgets. */
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 150,
				'width'       => 150,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
}
add_action( 'after_setup_theme', 'ds_setup' );

if ( ! function_exists( 'ds_content_width' ) ) {
	/**
	 * Set the content width in pixels, based on the theme's design and stylesheet.
	 *
	 * Priority 0 to make it available to lower priority callbacks.
	 *
	 * @global int $content_width
	 */
	function ds_content_width() {
		$GLOBALS['content_width'] = apply_filters( 'ds_content_width', ds_is_active_sidebar( 'sidebar-1' ) ? 999 : 1240 );
	}
}
add_action( 'after_setup_theme', 'ds_content_width', 0 );

if ( ! function_exists( 'ds_widgets_init' ) ) {
	/**
	 * Register widget area.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
	 */
	function ds_widgets_init() {
		register_sidebar(
			array(
				'name'          => __( 'Sidebar', 'ds' ),
				'id'            => 'sidebar-1',
				'description'   => __( 'Add widgets here.', 'ds' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
}
add_action( 'widgets_init', 'ds_widgets_init' );

if ( ! function_exists( 'ds_scripts' ) ) {
	/**
	 * Enqueue theme scripts and styles.
	 */
	function ds_scripts() {
		if ( ! is_home() && is_front_page() ) {
			wp_enqueue_style( 'ds-fancybox', ds_assets_css( 'fancybox' ), array(), DS_VERSION );
			wp_enqueue_script( 'ds-fancybox', ds_assets_js( 'fancybox' ), array( 'jquery' ), DS_VERSION, true );
		}

		wp_enqueue_style( 'ds-slippry', ds_assets_css( 'slippry' ), array(), DS_VERSION );
		wp_enqueue_style( 'ds-theme', ds_assets_css( 'theme' ), array( 'ds-slippry' ), DS_VERSION );

		wp_enqueue_script( 'ds-slippry', ds_assets_js( 'slippry' ), array( 'jquery' ), DS_VERSION, true );
		wp_enqueue_script( 'ds-theme', ds_assets_js( 'theme' ), array( 'jquery', 'ds-slippry' ), DS_VERSION, true );

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'ds_scripts' );

if ( ! function_exists( 'ds_admin_scripts' ) ) {
	/**
	 * Enqueue admin scripts and styles.
	 */
	function ds_admin_scripts() {
		wp_enqueue_style( 'ds-admin', ds_assets_css( 'admin' ), array(), DS_VERSION );
	}
}
add_action( 'admin_enqueue_scripts', 'ds_admin_scripts' );